from ml_lib.model.data_schema import DatasetConvertor


def test_domain_object_to_df():
    domain_objects_list = [
        {
            "node_type": "document",
            "_XpmsObjectMixin__type": "DocumentDomain",
            "children": [
                {
                    "children": [
                        {
                            "children": [
                                {
                                    "value": "$364.53",
                                    "node_type": "attribute",
                                    "name": "invoiceamount",
                                    "_XpmsObjectMixin__type": "Attribute"
                                },
                                {
                                    "value": "1",
                                    "node_type": "attribute",
                                    "name": "invoicenumber",
                                    "_XpmsObjectMixin__type": "Attribute"
                                },
                                {
                                    "value": "test_invoice",
                                    "node_type": "attribute",
                                    "name": "invoicename",
                                    "_XpmsObjectMixin__type": "Attribute"
                                },
                                {"name": "invoivesubentity",
                                 "children": [{
                                     "name": "sub1",
                                     "value": "as"
                                 }, {"name": "sub2",
                                     "value": "df"}]},
                                {
                                    "value": "test_invoice",
                                    "node_type": "attribute",
                                    "name": "invoicetest",
                                    "_XpmsObjectMixin__type": "Attribute"
                                }
                            ],
                            "node_type": "entity",
                            "_XpmsObjectMixin__type": "Entity",
                            "name": "invoiceentity",
                        },
                        {
                            "children": [
                                {
                                    "value": "test1",
                                    "node_type": "attribute",
                                    "name": "metadata1",
                                    "_XpmsObjectMixin__type": "Attribute"
                                },
                                {
                                    "value": "test2",
                                    "node_type": "attribute",
                                    "name": "metadata2",
                                    "_XpmsObjectMixin__type": "Attribute"
                                },
                                {
                                    "value": "test3",
                                    "node_type": "attribute",
                                    "name": "metadata3",
                                    "_XpmsObjectMixin__type": "Attribute"
                                }
                            ],
                            "node_type": "entity",
                            "_XpmsObjectMixin__type": "Entity",
                            "name": "invoicemetadata",
                        }
                    ],
                    "node_type": "domain",
                    "_XpmsObjectMixin__type": "DomainObject",
                    "name": "invoice",
                }
            ],
            "name": "document",
            "type": "",
        },
        {
            "node_type": "document",
            "_XpmsObjectMixin__type": "DocumentDomain",
            "children": [
                {
                    "children": [
                        {
                            "children": [
                                {
                                    "value": "test1",
                                    "node_type": "attribute",
                                    "name": "metadata1",
                                    "_XpmsObjectMixin__type": "Attribute"
                                },
                                {
                                    "value": "test2",
                                    "node_type": "attribute",
                                    "name": "metadata2",
                                    "_XpmsObjectMixin__type": "Attribute"
                                }
                            ],
                            "node_type": "entity",
                            "_XpmsObjectMixin__type": "Entity",
                            "name": "invoicemetadata",
                        }
                    ],
                    "node_type": "domain",
                    "_XpmsObjectMixin__type": "DomainObject",
                    "name": "invoice",
                }
            ],
            "name": "document",
            "type": "",
        }
    ]

    converted_df = DatasetConvertor.domain_object_to_df(source_dataset={"value": domain_objects_list},
                                                        data_schema="test")
    assert converted_df['value'].size == 18
