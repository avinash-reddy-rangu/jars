import os
import json
from ml_lib.resources.task_templates.regression_knn import register_task


def pytest_generate_tests(metafunc):
    file_name = os.path.basename(__file__)
    abspath = os.path.abspath(__file__)
    dir_name = os.path.dirname(abspath)
    dir_name = dir_name + "/test_cases/"
    test_path = dir_name + file_name
    test_path_parts = test_path.split(".")
    for parameter_name in ["test_register_task_input"]:
        if parameter_name in metafunc.funcargnames:
            tests_file = test_path_parts[0] + "/" + parameter_name + ".json"

            with open(tests_file) as data_file:
                data = json.load(data_file)
                metafunc.parametrize(parameter_name, data["test_cases"])


def test_register_task(test_register_task_input):
    task_dict = test_register_task_input['expected_task_dict']
    actual_task_dict = register_task()
    assert task_dict['name'] == actual_task_dict['name'], 'Name Incorrect'
    assert task_dict['category'] == actual_task_dict['category'], 'Incorrect category'
    assert task_dict['solution_id'] == actual_task_dict['solution_id'], 'Incorrect Solution ID'
    assert task_dict['task_class'] == actual_task_dict['task_class'], 'Incorrect Task Class'
    extras = test_register_task_input['expected_task_dict']['extras']
    assert extras['ui_index'] == actual_task_dict['extras']['ui_index'], 'Incorrect UI Index'
    config = test_register_task_input['expected_task_dict']['config']
    assert config['source_type'] == actual_task_dict['config']['source_type'], 'Incorrect Source type'
    algorithm = test_register_task_input['expected_task_dict']['config']['algorithm']
    assert algorithm['class'] == actual_task_dict['config']['algorithm']['class'], 'Incorrect Class'
