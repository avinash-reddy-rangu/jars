import os
import json
import pandas as pd
from xpms_file_storage.file_handler import XpmsResourceFactory, LocalResource
from ml_lib.resources.task_scripts.regression_algo_skl_model_runner import run, train, evaluate


def pytest_generate_tests(metafunc):
    file_name = os.path.basename(__file__)
    abspath = os.path.abspath(__file__)
    dir_name = os.path.dirname(abspath)
    dir_name = dir_name + "/test_cases/"
    test_path = dir_name + file_name
    test_path_parts = test_path.split(".")
    for parameter_name in ["test_train_input","test_run_input","test_evaluate_input"]:
        if parameter_name in metafunc.funcargnames:
            tests_file = test_path_parts[0] + "/" + parameter_name + ".json"

            with open(tests_file) as data_file:
                data = json.load(data_file)
                metafunc.parametrize(parameter_name, data["test_cases"])


def test_train(test_train_input):
    datasets = test_train_input['datasets']
    dataset = next(iter(datasets.values()))
    if dataset['data_format'] =="data_frame":
        dataset['value'] = pd.DataFrame(dataset['value'])
    config = test_train_input['config']
    train_info ,result = train(datasets,config)
    assert len(result['value'])==len(dataset['value'])
    assert train_info
    assert LocalResource(key="{0}/model.pkl".format(config['src_dir'])).exists()

def test_run(test_run_input):
    datasets = test_run_input['datasets']
    dataset = next(iter(datasets.values()))
    if dataset['data_format'] =="data_frame":
        dataset['value'] = pd.DataFrame(dataset['value'])
    config = test_run_input['config']
    result = run(datasets,config)
    assert len(result['value'])==len(dataset['value'])


def test_evaluate(test_evaluate_input):
    datasets = test_evaluate_input['datasets']
    dataset = next(iter(datasets.values()))
    if dataset['data_format'] == "data_frame":
        dataset['value'] = pd.DataFrame(dataset['value'])
    config = test_evaluate_input['config']
    metrics,result = evaluate(datasets, config)
    assert len(result['value']) == len(dataset['value'])
    assert config['scorers'] in metrics['scores'].keys()
