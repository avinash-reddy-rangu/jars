#! /usr/bin/env python

lib_name = 'xpms-lib-ml'
lib_version = '9.0.11'

description = 'ml package for XPMS'

if __name__ == "__main__":
    from setuptools import setup

    setup(
        name=lib_name,
        version=lib_version,
        description=description,
        author='XPMS',
        author_email='mayankt@xpms.io',
        url='https://bitbucket.org/xpms/ml/',
        packages=["ml_lib", "ml_lib.resources.task_templates", "ml_lib.model.dag_tasks", "ml_lib.model",
                  "ml_lib.resources.task_scripts",
                  "ml_lib.model.dag_tasks"],
        license='na',
        install_requires=['scipy==1.3.3', 'scikit-learn==0.22', 'xgboost==0.71', 'xpms-lib-helper==9.0.1', 'xpms-objects==9.0.0', 'xpms-storage-mongo==9.0.0', 'xpms-lib-dag==9.0.0', 'xpms-common==9.0.0', 'numpy==1.17.4', 'pandas==0.25.3', 'xpms-file-storage==9.0.0', 'xmltodict==0.12.0', 'lxml==4.2.5', 'tensorflow==2.0.0', 'Keras==2.3.1']
    )
