import json
from datetime import datetime
import random
import os
import pandas as pd
from xpms_file_storage.file_handler import XpmsResource, XpmsResourceFactory, LocalResource
from ml_lib import constants
from uuid import uuid4


def df_from_csv_resource(resource):
    file_object = XpmsResourceFactory.create_resource(urn=resource)
    df = pd.read_csv(file_object.open(mode='r')
                     , nrows=constants.MAX_DATAFRAME_ROWS)
    return df


def load_json(resource: XpmsResource):
    with resource.open(mode="r") as f:
        result = json.load(f)
    return result


def save_json(resource: XpmsResource, content):
    with resource.open(mode="w") as f:
        json.dump(content, f)


def get_unique_short():
    return "{0:%H_%m_%S_}".format(datetime.utcnow()) + str(random.randint(0, 1000))


def random_local_path():
    path = os.path.join("/tmp", get_unique_short())
    path = LocalResource(key=path)
    return path


def copy_res_to_local(res_urn, local_path=None):
    res = XpmsResourceFactory.create_resource(urn=res_urn)
    if local_path is None:
        local_path = "/tmp/{0}".format(str(uuid4()))
    local_res = LocalResource(fullpath=local_path)
    res.copy(local_res)
    return local_res.fullpath
