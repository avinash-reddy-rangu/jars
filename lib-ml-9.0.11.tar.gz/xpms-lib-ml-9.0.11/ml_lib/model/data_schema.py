from copy import deepcopy

import pandas as pd
from enum import Enum
from ml_lib.file_utilities import df_from_csv_resource, copy_res_to_local
import os
from xpms_file_storage.file_handler import LocalResource, XpmsResource
import zipfile
import json
import random
from datetime import datetime
from xpms_objects.models.ml import DatasetFormat
import numpy as np


# class DatasetFactory():
#     raise NotImplementedError()
#
class Dataset():
    name = ""
    value = []
    format = ""
    schema = ""

    def __init__(self, **kwargs):
        self.name = kwargs["name"]
        self.value = kwargs["value"]
        self.format = kwargs["format"]
        self.data_schema = kwargs["data_schema"]


# class DFDataset(Dataset):
#     raise NotImplementedError()


class ExtendedEnum(Enum):
    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))


def convert_to_bool(string):
    if string in ["false", "False"]:
        return False
    return bool(string.lower())


data_type_cls_map = {
    "integer": int,
    "float": float,
    "boolean": convert_to_bool,
    "string": str
}


class DatasetConvertor(object):

    @staticmethod
    def convert(source_dataset, output_format: DatasetFormat, data_schema):
        func = dc_func_map["{0}.{1}".format(source_dataset["data_format"], output_format.value)]
        return func(source_dataset, data_schema)

    @staticmethod
    def list_to_df(source_dataset, data_schema):
        columns = source_dataset["value"][0]
        data = source_dataset["value"][1:]
        df = pd.DataFrame(data=data, columns=columns)
        new_dataset = {"data_format": "data_frame", "value": df}
        return new_dataset

    @staticmethod
    def file_to_df(source_dataset, data_schema):
        label = source_dataset.get('label', '')
        file_name = source_dataset['value'].split("/")[-1].split(".")[0]
        file_data = [["file_name", "file_path", "label"]]
        file_data.append([file_name, source_dataset['value'], label])
        df = pd.DataFrame(data=file_data[1:], columns=file_data[0])
        new_dataset = {"data_format": "data_frame", "data_schema": data_schema, "value": df,
                       "labels": list(df['label'])}
        return new_dataset

    @staticmethod
    def folder_to_df(source_dataset, data_schema):
        raise NotImplementedError

    @staticmethod
    def entities_to_df(source_dataset, data_schema):

        if data_schema["additionalProperties"]:
            return DatasetConvertor.loose_attr_mapper(source_dataset, data_schema)
        else:
            return DatasetConvertor.strict_attr_mapper(source_dataset, data_schema)

    @staticmethod
    def strict_attr_mapper(source_dataset, data_schema):
        data = []
        columns = list(data_schema["properties"].keys())
        for row in source_dataset["value"]:
            row_data = list()
            for entity in row:
                for prop in entity["data"]:
                    if prop in data_schema["properties"]:
                        raw_val = entity["data"][prop][-1][0]
                        try:
                            val = data_type_cls_map[data_schema["properties"][prop]["type"]](raw_val)
                        except Exception as e:
                            val = None
                        row_data.append(val)
            data.append(row_data)
        df = pd.DataFrame(data=data, columns=columns)
        new_dataset = {"data_format": "data_frame", "data_schema": data_schema, "value": df}
        return new_dataset

    @staticmethod
    def loose_attr_mapper(source_dataset, data_schema):
        # todo , do we handle it using csr?

        raw_data = []
        columns = list(data_schema["properties"])
        for row in source_dataset["value"]:
            row_data = dict()
            for entity in row:
                for prop in entity["data"]:
                    if prop in data_schema["properties"]:
                        raw_val = entity["data"][prop][-1][0]
                        try:
                            val = data_type_cls_map[data_schema["properties"][prop]["type"]](raw_val)
                        except Exception as e:
                            val = None
                    else:
                        val = entity["data"][prop][-1][0]
                        columns.append(prop)
                    row_data[prop] = val
            raw_data.append(row_data)

        data = []
        for row_rdata in raw_data:
            row_data = [None] * len(columns)
            for index in range(0, len(columns)):
                if columns[index] in row_rdata:
                    row_data[index] = row_rdata[columns[index]]
            data.append(row_data)
        df = pd.DataFrame(data=data, columns=columns)
        new_dataset = {"data_format": "data_frame", "data_schema": data_schema, "value": df}
        return new_dataset

    @staticmethod
    def zip_to_df(source_dataset, data_schema):

        # get list of folders in the zip
        file_names = []
        file_value = source_dataset["value"]

        file_path = file_value
        # load to local
        file_path = copy_res_to_local(file_path)
        # if not zipfile.is_zipfile(file_path):
        #     raise Exception("passed file is not a valid zip file")
        zf = zipfile.ZipFile(file_path, 'r')
        zip_data = [["file_name", "file_path", "label"]]
        zip_name = os.path.splitext(os.path.basename(file_path))[0]
        new_file_path = source_dataset["name"] if "name" in source_dataset else zip_name + str(
            random.randrange(0, 1000))
        # new_file_path = learn_utils.get_file_path(message, learn_utils.constants.RAW_DATASET_PATH, new_file_path)
        # new_file_path = learn_utils._get_xpmsresource(rel_path=new_file_path, exists=False)
        # new_file_path = learn_utils.get_complete_file_path(new_file_path)
        # os.makedirs(new_file_path, exist_ok=True)
        new_tmp_file_path = random_local_path().fullpath
        zf.extractall(path=new_tmp_file_path)
        if not os.listdir(new_tmp_file_path):
            raise Exception("Empty zip provided. Dataset_info: {}".format(json.dumps(source_dataset)))

        if len(os.listdir(new_tmp_file_path)) == 1:
            tgt_dir_path = os.path.join(new_tmp_file_path, os.listdir(new_tmp_file_path)[0])
            if os.path.isdir(tgt_dir_path):
                new_tmp_file_path = tgt_dir_path

        for content in os.listdir(new_tmp_file_path):
            if os.path.isfile(os.path.join(new_tmp_file_path, content)):
                if content.startswith("__"):
                    continue
                if content.endswith("/"):
                    continue
                if content.endswith(".DS_Store"):
                    continue
                zip_data.append([content, os.path.join(new_file_path, content), "unknown"])
            elif os.path.isdir(os.path.join(new_tmp_file_path, content)):
                for dir_content in os.listdir(os.path.join(new_tmp_file_path, content)):
                    if os.path.isfile(os.path.join(new_tmp_file_path, content, dir_content)):
                        if dir_content.startswith("__"):
                            continue
                        if dir_content.endswith("/"):
                            continue
                        if dir_content.endswith(".DS_Store"):
                            continue
                        zip_data.append([dir_content,
                                         os.path.join(new_tmp_file_path, content, dir_content)
                                            , content])
        df = pd.DataFrame(zip_data[1:], columns=zip_data[0])
        new_dataset = {"data_format": "data_frame", "data_schema": data_schema, "value": df,
                       "labels": list(df['label'])}
        return new_dataset

    @staticmethod
    def gan_zip_to_df(source_dataset, data_schema):
        file_value = source_dataset["value"]
        file_path = copy_res_to_local(file_value)
        zf = zipfile.ZipFile(file_path, 'r')
        zip_name = os.path.splitext(os.path.basename(file_path))[0]
        new_file_path = source_dataset["name"] if "name" in source_dataset else zip_name + str(
            random.randrange(0, 1000))
        new_tmp_file_path = random_local_path().fullpath
        zf.extractall(path=new_tmp_file_path)
        local_zip_folder = LocalResource(key=new_tmp_file_path)
        LocalResource(key=file_path).delete()
        if len(local_zip_folder.list()) == 1:
            return DatasetConvertor.generate_run_dataset(target_folder=local_zip_folder.list()[0], source_dataset=source_dataset)
        elif len(local_zip_folder.list()) == 2:
            return DatasetConvertor.generate_eval_dataset(zip_folder=local_zip_folder, source_dataset=source_dataset)

    @staticmethod
    def generate_run_dataset(target_folder, source_dataset):
        image_paths = []
        for image_res in target_folder.list():
            res_path = "{0}/{1}/{2}/{3}".format(source_dataset['solution_id'], "ml", "tables_images",
                                                image_res.filename)
            remote_res = XpmsResource.get(key=res_path)
            image_res.copy(remote_res)
            image_paths.append(remote_res.urn)
        gan_df = pd.DataFrame(data=image_paths, columns=[target_folder.filename])
        target_folder.delete_tree()
        new_dataset = {"data_format": "data_frame", "value": gan_df}
        return new_dataset

    @staticmethod
    def generate_eval_dataset(zip_folder, source_dataset):
        input_folder_res = [folder for folder in zip_folder.list() if folder.filename == "input"][0]
        output_folder_res = [folder for folder in zip_folder.list() if folder.filename == "output"][0]
        input_data = []
        for input_file in input_folder_res.list():
            res_path = "{0}/{1}/{2}/{3}/{4}".format(source_dataset['solution_id'], "ml", "tables_images",
                                                    "input_images", input_file.filename)
            remote_res = XpmsResource.get(key=res_path)
            input_file.copy(remote_res)
            input_image_data = [remote_res.urn, remote_res.filename_without_extension]
            input_data.append(input_image_data)
        gan_df = pd.DataFrame(data=input_data, columns=['input', 'input_file_name'])
        gan_df['output'] = np.nan
        for output_file in output_folder_res.list():
            res_path = "{0}/{1}/{2}/{3}/{4}".format(source_dataset['solution_id'], "ml", "tables_images",
                                                    "output_images", output_file.filename)
            remote_res = XpmsResource.get(key=res_path)
            output_file.copy(remote_res)
            if len(gan_df.loc[gan_df['input_file_name'] == remote_res.filename_without_extension,]) > 1:
                raise Exception(
                    "Multiple ground truths found for the file {0}".format(remote_res.filename_without_extension))
            elif len(gan_df.loc[gan_df['input_file_name'] == remote_res.filename_without_extension,]) == 0:
                gan_df = gan_df.append({"output": remote_res.urn}, ignore_index=True)
            else:
                gan_df.loc[
                    gan_df['input_file_name'] == remote_res.filename_without_extension, 'output'] = remote_res.urn
        gan_df = gan_df.drop(['input_file_name'], axis=1)
        zip_folder.delete_tree()
        new_dataset = {"data_format": "data_frame", "value": gan_df}
        return new_dataset

    @staticmethod
    def files_to_df(source_dataset, data_schema):
        file_data = [["file_name", "file_path", "label"]]
        for files in source_dataset['value']:
            file_path = files[0]
            label = files[1]
            file_path = copy_res_to_local(file_path)
            file_name = os.path.splitext(os.path.basename(file_path))[0]
            file_data.append([file_name, file_path, label])
        df = pd.DataFrame(data=file_data[1:], columns=file_data[0])
        new_dataset = {"data_format": "data_frame", "data_schema": data_schema, "value": df,
                       "labels": list(df['label'])}
        return new_dataset

    @staticmethod
    def csv_to_df(source_dataset, data_schema):
        file_value = source_dataset["value"]
        df = df_from_csv_resource(file_value)
        new_dataset = {"data_format": "data_frame", "data_schema": data_schema, "value": df}
        return new_dataset

    @staticmethod
    def df_to_csv(source_dataset, data_schema):
        raise NotImplementedError

    @staticmethod
    def json_to_df(source_dataset, data_schema):
        # todo - reevalue, looks wrong
        columns = []
        data = []
        value = source_dataset["value"]
        for k in value:
            columns.append(k)
            data.append(value[k])
        df = pd.DataFrame(columns=columns, data=[data])
        new_dataset = {"data_format": "data_frame", "data_schema": data_schema, "value": df}
        return new_dataset

    @staticmethod
    def domain_object_to_df(source_dataset, data_schema):
        columns = []
        rows = []
        for domain in source_dataset['value']:
            row_value = {}
            if 'children' in domain and domain['children']:
                for d_object in domain['children']:
                    for entity in d_object['children']:
                        attribute_path_list = [d_object['name'], entity['name']]
                        DatasetConvertor.construct_key_path(entity, attribute_path_list, columns, row_value)
                    rows.append(row_value)

        df = pd.DataFrame(data=rows, columns=columns)
        new_dataset = {"data_format": "data_frame", "value": df}
        return new_dataset

    @staticmethod
    def construct_key_path(data, attribute_path_list, columns, values):
        for attribute in data['children']:
            sub_items = deepcopy(attribute_path_list)
            sub_items.append(attribute['name'])
            if 'children' in attribute and attribute['children']:
                DatasetConvertor.construct_key_path(attribute, sub_items, columns, values)
            else:
                key_path = ".".join(sub_items)
                if key_path not in columns:
                    columns.append(key_path)
                values[key_path] = attribute['value']


dc_func_map = {
    "{0}.{1}".format(DatasetFormat.CSV.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.csv_to_df,
    "{0}.{1}".format(DatasetFormat.JSON.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.json_to_df,
    "{0}.{1}".format(DatasetFormat.FILE.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.file_to_df,
    "{0}.{1}".format(DatasetFormat.TXT.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.file_to_df,
    "{0}.{1}".format(DatasetFormat.FOLDER.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.folder_to_df,
    "{0}.{1}".format(DatasetFormat.GAN_ZIP.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.gan_zip_to_df,
    "{0}.{1}".format(DatasetFormat.ZIP.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.zip_to_df,
    "{0}.{1}".format(DatasetFormat.ENTITY.value,
                     DatasetFormat.DATA_FRAME.value): DatasetConvertor.entities_to_df,
    "{0}.{1}".format(DatasetFormat.DATA_FRAME.value, DatasetFormat.CSV.value): DatasetConvertor.df_to_csv,
    "{0}.{1}".format(DatasetFormat.LIST.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.list_to_df,
    "{0}.{1}".format(DatasetFormat.FILES.value, DatasetFormat.DATA_FRAME.value): DatasetConvertor.files_to_df,
    "{0}.{1}".format(DatasetFormat.DOMAIN_OBJECT.value,
                     DatasetFormat.DATA_FRAME.value): DatasetConvertor.domain_object_to_df
}


class DatasetValidator():
    @staticmethod
    def validate_df(schema, df):
        if schema is None:
            return True
        columns = df.columns.values
        for k in schema["properties"]:
            if k in columns:
                column_schema = schema["properties"][k]
                if "enum" in column_schema:
                    if not DatasetValidator._df_check_category(column_schema, df, k):
                        raise Exception("dataset values found invalid for column {0}".format(k))
                        # todo validate dataframe for categorical values
                elif column_schema["type"] == "boolean":
                    if not df[k].all():
                        raise Exception("dataset values found invalid for column {0}".format(k))
                elif column_schema["type"] in ["integer", "float"]:
                    if not DatasetValidator._df_check_between(column_schema, df, k):
                        raise Exception("dataset values found invalid for column {0}".format(k))
                elif column_schema["type"] == "date_time":
                    # todo add check for datetime
                    df[k] = df[k].astype('datetime')
                elif column_schema["type"] == "string":
                    df[k] = df[k].as_type('object')

    @staticmethod
    def _df_check_category(column_schema, dataset, column):
        return dataset[column].isin(column_schema["enum"]).all()

    @staticmethod
    def _df_check_between(column_schema, dataset, column):
        closure = []
        min_val = 0
        max_val = 0
        if "minimum" in column_schema:
            min_val = column_schema["minimum"]
            closure.append("closed")
        elif "exclusiveMinimum" in column_schema:
            min_val = column_schema["exclusiveMinimum"]
            closure.append("open")
        else:
            closure.append("")
        if "maximum" in column_schema:
            max_val = column_schema["maximum"]
            closure.append("closed")
        elif "exclusiveMaximum" in column_schema:
            max_val = column_schema["exclusiveMaximum"]
            closure.append("open")
        else:
            closure.append("")

        if closure[0] == "close":
            return (dataset[column] >= min_val).all()
        elif closure[0] == "open":
            return (dataset[column] > min_val).all()
        elif closure[1] == "close":
            return (dataset[column] <= max_val).all()
        elif closure[1] == "open":
            return (dataset[column] < max_val).all()
        return True


def get_unique_short():
    return "{0:%H_%m_%S_}".format(datetime.utcnow()) + str(random.randint(0, 1000))


def random_local_path():
    path = os.path.join("/tmp", get_unique_short())
    path = LocalResource(key=path)
    return path
