from xpms_lib_dag.constants import Status, ExecType, TASK_DIR
from xpms_lib_dag.tasks.task import Task
from xpms_lib_dag.constants import _globals
from xpms_lib_dag.utils import get_timestamp, deserialize_content, serialize_content
from xpms_file_storage.file_handler import XpmsResourceFactory
import os
import sys
from copy import deepcopy
from pydoc import locate
import pandas as pd
import numpy as np
from xpms_file_storage.file_handler import XpmsResource, LocalResource
from xpms_lib_dag import constants as dag_constants
from scipy.sparse import csr_matrix
from xpms_helper.lru_cache import lru_cache, CacheSize
import importlib.util
from datetime import datetime
from ml_lib.log_memory import log_memory


class MLTask(Task):
    exec_type = ExecType.SYNC.value

    def __init__(self, **kwargs):
        super(MLTask, self).__init__()
        self.__dict__.update(kwargs)

    def as_json(self, serialize=False):
        result_json = deepcopy(self.__dict__)
        if "inputs" in result_json.keys():
            for idx, instance_input in enumerate(result_json["inputs"]):
                for key, val in instance_input.items():
                    if "dataset" not in val:
                        continue
                    if isinstance(val["dataset"], pd.DataFrame):
                        result_json["inputs"][idx][key] = val["dataset"].to_json(orient='split')
                    elif isinstance(val["dataset"], np.ndarray):
                        result_json["inputs"][idx][key] = val["dataset"].tolist()
        if "outputs" in result_json.keys():
            for idx, val in enumerate(result_json["outputs"]):
                if "dataset" not in val:
                    continue
                if isinstance(val["dataset"], pd.DataFrame):
                    result_json["outputs"][idx] = val["dataset"].to_json(orient='split')
                elif isinstance(val["dataset"], np.ndarray):
                    result_json["outputs"][idx] = val["dataset"].tolist()
        return result_json

    def on_complete(self, outputs):
        if self.status != Status.FAILED.value:
            self.status = Status.PROCESSED.value
        self.end_ts = datetime.utcnow()
        for output in outputs:
            if isinstance(output, dict) and "_exception_" in output:
                self.status = Status.FAILED.value
                break
        self.outputs = outputs

    def run(self, inputs, caching=False):
        try:

            log_memory("0 starting ml task execution")
            deserialized_inputs = dict()
            inputs = deepcopy(inputs)
            for key in inputs:
                deserialized_inputs[key] = self.deserialize_content([inputs[key]])[0]
            inputs = deserialized_inputs
            ordered_keys = sorted([key for key in inputs.keys()])
            task_data = [inputs[key] for key in ordered_keys]
            datasets = dict()
            for key in ordered_keys:
                datasets[key] = inputs[key]["data"]["dataset"]
            task_data = task_data[0]
            if self.category == "ml_function":
                datasets = next(iter(datasets.values()))

            if "additional_params" in task_data["data"]:
                self.config["additional_params"] = task_data["data"]["additional_params"]

            if task_data["data"]["exec_mode"] == "retrain_iter":
                output = self.train_model_task(task_data, datasets, mode="retrain")
            elif task_data["data"]["exec_mode"] in ["train", "retrain"]:
                output = self.train_model_task(task_data, datasets)
            elif task_data["data"]["exec_mode"] == "evaluate":
                output = self.evaluate_model_task(task_data, datasets, caching=caching)
            elif task_data["data"]["exec_mode"] == "run":
                output = self.run_model_task(task_data, datasets, caching=caching)
            else:
                raise Exception()
            # if isinstance(task_output, tuple) and len(task_output) > 1:
            #     setattr(self, "metadata", list(task_output[1:]))
            #     output = task_output[0]
            # else:
            #     output = task_output
            # outputs = output
        except Exception as e:
            raise e
        return self, self.serialize_content([output])[0]

    def serialize_content(self, outputs):
        for output in outputs:
            datasets = output["data"]["dataset"] if isinstance(output["data"]["dataset"], list) else [
                output["data"]["dataset"]]
            for dataset in datasets:
                if dataset["data_format"] == "csr":
                    dataset["value"] = {"data": dataset["value"].data.tolist(),
                                        "indices": dataset["value"].indices.tolist(),
                                        "indptr": dataset["value"].indptr.tolist(), "shape": dataset["value"]._shape}

                if dataset["data_format"] == "data_frame":
                    df = dataset["value"]
                    # dataset["value"] = [df.columns.values.tolist()] + df.values.tolist()
                    dataset["value"] = df.to_json(orient='split')

                output["data"]["dataset"] = datasets[0] if len(datasets) == 1 else datasets

            # todo for csr
        return outputs

    def deserialize_content(self, outputs):
        for output in outputs:
            datasets = output["data"]["dataset"] if isinstance(output["data"]["dataset"], list) else [
                output["data"]["dataset"]]
            for dataset in datasets:
                if dataset["data_format"] == "data_frame":
                    serialized_df = dataset["value"]
                    # dataset["value"] = pd.DataFrame(columns=serialized_df[0],data=serialized_df[1:])
                    dataset["value"] = pd.read_json(serialized_df, orient='split')
                if dataset["data_format"] == "csr":
                    if dataset["data_format"] == "csr":
                        dataset["value"] = csr_matrix(
                            (dataset["value"]["data"], dataset["value"]["indices"], dataset["value"]["indptr"]),
                            dataset["value"]["shape"])

            # todo for csr
            output["data"]["dataset"] = datasets[0] if len(datasets) == 1 else datasets
        return outputs

    def run_model_task(self, task_data, datasets, caching=False):

        try:

            log_memory("0.5 starting ml task run model")
            python_task = MLTask.load_execution_script(self.category, source_type=self.config.get("source_type", None),
                                                       src_dir=self.config["src_dir"], source=self.config["source"],
                                                       caching=caching)

            log_memory("1 loaded execution script")
            output_data = deepcopy(task_data)

            if self.category == "ml_function":
                self.config["caching"] = caching
                # todo: check and handle for run_info here
                run_result =  python_task.run(datasets, self.config)
            else:
                run_result = python_task.run(datasets, self.config,caching=caching)

            # to handle tasks that only return dataset
            if isinstance(run_result, dict):
                output_data["data"]["dataset"] = run_result
            else:
                output_data["data"]["dataset"], output_data["run_info"] = run_result

            return output_data
        finally:
            if not caching:
                log_memory("15 unloading execution script")
                self.unload_execution_script()

            log_memory("16 unloaded execution script")

    def train_model_task(self, task_data, datasets, mode = "train"):

        try:
            python_task = MLTask.load_execution_script(self.category, source_type=self.config.get("source_type", None),
                                                       src_dir=self.config["src_dir"], source=self.config["source"],
                                                       caching=False)

            output_data = deepcopy(task_data)
            if hasattr(python_task, 'train') or hasattr(python_task, 'retrain'):
                if "algorithms" not in output_data["data"]:
                    output_data["data"]["algorithms"] = dict()
                if "train_info" not in output_data["data"]:
                    output_data["data"]["algorithms"]["train_info"] = dict()

                if hasattr(python_task, "retrain") and mode == "retrain":
                    output_data["data"]["algorithms"]["train_info"][self.task_id], output_data["data"][
                        "dataset"] = python_task.retrain(datasets, self.config)
                else:
                    output_data["data"]["algorithms"]["train_info"][self.task_id], output_data["data"][
                        "dataset"] = python_task.train(datasets, self.config)

            else:
                train_result = python_task.run(datasets, self.config)
                if isinstance(train_result, dict):
                    output_data["data"]["dataset"] = train_result
                else:
                    output_data["data"]["dataset"], output_data["run_info"] = train_result

            return output_data
        finally:
            self.unload_execution_script()

    def evaluate_model_task(self, task_data, datasets, caching=False):
        # check if evalute is present in the task script
        try:
            python_task = MLTask.load_execution_script(self.category, source_type=self.config.get("source_type", None),
                                                       src_dir=self.config["src_dir"], source=self.config["source"],
                                                       caching=caching)
            # generating task data
            output_data = deepcopy(task_data)

            if hasattr(python_task, 'evaluate'):
                if "algorithms" not in output_data["data"]:
                    output_data["data"]["algorithms"] = dict()
                if "train_info" not in output_data["data"]:
                    output_data["data"]["algorithms"]["eval_info"] = dict()
                if self.category == "ml_function":
                    self.config["caching"] = caching
                    eval_result = python_task.evaluate(datasets, self.config)
                else:
                    eval_result = python_task.evaluate(datasets, self.config, caching=caching)
                if len(eval_result) == 3:
                    output_data["data"]["algorithms"]["eval_info"][self.task_id], output_data["data"][
                        "dataset"], output_data["run_info"] = eval_result
                elif len(eval_result) == 2:
                    output_data["data"]["algorithms"]["eval_info"][self.task_id], output_data["data"][
                        "dataset"] = eval_result
            else:
                if self.category == "ml_function":
                    self.config["caching"] = caching
                    output_data["data"]["dataset"], run_info = python_task.run(datasets, self.config)
                    eval_result = python_task.run(datasets, self.config)
                else:
                    eval_result = python_task.run(datasets, self.config, caching=caching)
                if isinstance(eval_result, dict):
                    output_data["data"]["dataset"] = eval_result
                else:
                    output_data["data"]["dataset"], output_data["run_info"] = eval_result

            return output_data
        finally:
            if not caching:
                self.unload_execution_script()

    def setup(self, mapped_inputs, caching=False):
        if self.status == Status.PROCESSED.value or self.status == Status.FAILED.value:
            return
        mapped_inputs_updated = dict()
        for k in list(mapped_inputs.keys()):
            if "previous_task_names" in self.config:
                key = "{0}${1}".format(self.config["previous_task_names"][k], k)
            else:
                key = k
            mapped_inputs_updated[key] = mapped_inputs[k][0]
        mapped_inputs = mapped_inputs_updated

        for k in list(mapped_inputs.keys()):
            if isinstance(mapped_inputs[k], dict) and "_exception_" in mapped_inputs[k]:
                if self.config.get("dependencies", "any") == "any":
                    mapped_inputs.pop(k)
                else:
                    return

        if self.config.get("conditions"):
            eval_globals = deepcopy(_globals)
            for key, value in self.config["conditions"].items():
                eval_globals.update({"inputs": mapped_inputs.get(key, None)})
                eval_result = eval(value, eval_globals)
                if type(eval_result) == bool and not eval_result:
                    if self.config.get("dependencies", "any") == "any":
                        mapped_inputs.pop(key, None)
                    else:
                        return

        if not mapped_inputs:
            return

        request_message = list(mapped_inputs.values())[0]
        model_id = request_message["data"]["model"]["model_id"]
        model_version_id = request_message["data"]["model"]["version_id"]
        instance_id = self.instance_id.split("$")[-1]
        source_dir = MLTask.create_source_dir(task_reference=self.config.get("task_reference", None),
                                              files=self.config["files"], instance_id=instance_id,
                                              solution_id=self.solution_id, model_id=model_id,
                                              model_version_id=model_version_id, caching=caching)
        output_dir = MLTask.create_output_dir(task_reference=self.config.get("task_reference", None), solution_id=self.solution_id, execution_id=self.execution_id, instance_id=instance_id)
        self.config["src_dir"] = source_dir
        self.config["output_dir"] = output_dir
        self.config["model"] = deepcopy(request_message["data"]["model"])
        self.config["storage"] = os.environ["STORAGE"]
        if "binary" in self.config and self.config['binary']:
            for binary in self.config['binary']:
                binary_path = "{0}/{1}/{2}/{3}".format(self.solution_id, "faas", "resources", self.config['binary'][binary])
                binary_path = XpmsResource.get(key=binary_path).urn
                self.config['binary'][binary] = binary_path
        self.status = Status.PROCESSING.value
        self.start_ts = get_timestamp()
        self.inputs = [mapped_inputs]

        return self, self.inputs

    @staticmethod
    @lru_cache(maxsize=2 * CacheSize.MB.value)
    def create_source_dir(task_reference, files, instance_id, solution_id, model_id, model_version_id, caching=False):
        if task_reference is not None and task_reference.lower() not in ["none", ""]:
            root_instance_id = task_reference.split(dag_constants.TASK_DELIMITER)[-1]
        else:
            root_instance_id = instance_id.split(dag_constants.TASK_DELIMITER)[-1]
        task_resource_dir = "{0}/{1}/{2}/{3}/{4}".format(solution_id, "ml",
                                                         model_id,
                                                         model_version_id,
                                                         root_instance_id)
        task_resource_dir = XpmsResourceFactory.create_resource(key=task_resource_dir)
        task_resource_dir.mkdir()
        for file_path in files:
            try:
                # todo check if filepath is a urn
                if "://" in file_path:
                    f = XpmsResourceFactory.create_resource(urn=file_path)
                else:
                    f = XpmsResourceFactory.create_resource(key=file_path)
                # todo need to be tested
                new_file_res = XpmsResourceFactory.create_resource(
                    key="{}/{}".format(task_resource_dir.key, f.filename))
                f.copy(new_file_res)
            except Exception as e:
                raise TypeError("Invalid file provided. %s" % str(e))
        return task_resource_dir.key

    @staticmethod
    @lru_cache(maxsize=2 * CacheSize.MB.value)
    def create_output_dir(task_reference, solution_id, execution_id, instance_id, caching=False):
        if task_reference is not None and task_reference.lower() not in ["none", ""]:
            root_instance_id = task_reference.split(dag_constants.TASK_DELIMITER)[-1]
        else:
            root_instance_id = instance_id.split(dag_constants.TASK_DELIMITER)[-1]
        output_resource_dir_path = "{0}/{1}/{2}/{3}/{4}".format(solution_id, "ml", "executions", execution_id, root_instance_id)
        output_resource_dir = XpmsResourceFactory.create_resource(key=output_resource_dir_path)
        output_resource_dir.mkdir()
        return output_resource_dir.key

    @staticmethod
    @lru_cache(maxsize=50 * CacheSize.MB.value)
    def load_execution_script(category, source_type, src_dir, source, caching=False):

        if category == "ml_function" or (source_type is not None and source_type == "script"):
            sys.path.insert(0, "src_dir")
            source = "{}/{}.py".format(src_dir, source)
            local_res = LocalResource(rel_path=source)
            if not local_res.exists():
                storage_res = XpmsResourceFactory.create_resource(key=source)
                storage_res.copy(local_res)
            spec = importlib.util.spec_from_file_location(local_res.fullpath, local_res.fullpath)
            python_task = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(python_task)
            return python_task

        else:
            source = source
            tmp_path = source.split('.')
            op_str = tmp_path.pop()
            import_str = '.'.join(tmp_path)
            exec('from {} import {}'.format(import_str, op_str))
            python_task = eval(op_str)
        return python_task

    def unload_execution_script(self):
        if self.category == "ml_function" or ("source_type" in self.config and self.config["source_type"] == "script"):
            source = "{}.{}".format(self.config["src_dir"], self.config["source"])
        else:
            source = self.config["source"]
        sys.modules.pop(source, None)
