from xpms_lib_dag.task_manager import TaskManager


def create_task(task_dict):
    # register tasks with dag library
    service_tasks = TaskManager.get_task({"solution_id": task_dict["solution_id"], "name": task_dict["name"]},
                                         jsonify=False)
    service_task_version = TaskManager.get_task_template(jsonify=False)
    service_task_version.__dict__.update({"solution_id": task_dict["solution_id"]})
    if len(service_tasks) != 0:
        service_task = service_tasks[0]
        service_task_version.version_id = service_task.default_version
        duplicate_version = TaskManager.get_task_versions(
            {"task_id": service_task.task_id, "version_id": service_task.default_version, "dependency_package": service_task.compatible_groups[0],
             "solution_id": task_dict["solution_id"], "is_deleted": False})
        if len(duplicate_version) >0:
            service_task_version.__dict__.update(duplicate_version[0].as_json())
        else:
            service_task_version.version_id = "v1"
            service_task_version.__dict__.update({"task_id": service_task.task_id})
    else:
        # create task
        if "task_id" in task_dict:
            service_task = TaskManager.create_task(
                {"name": task_dict["name"], "task_name": task_dict["name"],
                 "task_id": task_dict["task_id"], "description": task_dict.get("description", ""),
                 "task_class": task_dict["task_class"], "solution_id": task_dict["solution_id"],
                 "category": task_dict["category"], "compatible_groups": task_dict['compatible_groups']})
        else:
            service_task = TaskManager.create_task(
                {"name": task_dict["name"], "task_name": task_dict["name"],
                 "description": task_dict.get("description", ""),
                 "task_class": task_dict["task_class"], "solution_id": task_dict["solution_id"],
                 "category": task_dict["category"], "compatible_groups": task_dict['compatible_groups']})

        service_task_version.version_id = "v1"
        service_task_version.__dict__.update({"task_id": service_task.task_id})
    # register tasks with dag library
    service_task_version.name = task_dict["name"]
    service_task_version.task_name = task_dict["name"]
    service_task_version.description = task_dict.get("description", "")
    service_task_version.task_class = task_dict["task_class"]
    service_task_version.timeout = task_dict["timeout"]["value"] if "timeout" in task_dict else service_task_version.timeout
    service_task_version.config = task_dict.get("config", {})
    service_task_version.category = task_dict["category"]
    service_task_version.extras = task_dict.get("extras", {})
    service_task_version.compatible_groups = task_dict.get('compatible_groups',[])
    service_task_version.save()
    service_task.default_version = service_task_version.version_id
    service_task.is_enabled = True
    service_task.modified_by = "system"
    service_task.created_by = "system"
    service_task.save()
