from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []

    col_name = configuration.StringConfiguration()
    col_name.data_type = configuration.DataType.STRING.value
    col_name.name = "Column Name/s"
    col_name.description = "Column names on which imputation is to be performed"
    col_name.value = "all"
    col_name.multi_select = True
    col_name.config_path = "config.algorithm.configuration.col_name"
    col_name.validate()
    x_config.append(col_name.as_json())

    with_centering = configuration.BooleanConfiguration()
    with_centering.data_type = configuration.DataType.BOOLEAN.value
    with_centering.description = "If True, center the data before scaling."
    with_centering.name = "with centering"
    with_centering.options = [True, False]
    with_centering.value = True
    with_centering.config_path = "config.algorithm.configuration.with_centering"
    with_centering.op_type = configuration.OpType.CATEGORICAL.value
    with_centering.validate()
    x_config.append(with_centering.as_json())

    with_scaling = configuration.BooleanConfiguration()
    with_scaling.data_type = configuration.DataType.BOOLEAN.value
    with_scaling.description = "If True, scale the data to interquartile range"
    with_scaling.name = "with_scaling"
    with_scaling.options = [True, False]
    with_scaling.value = True
    with_scaling.config_path = "config.algorithm.configuration.with_scaling"
    with_scaling.op_type = configuration.OpType.CATEGORICAL.value
    with_scaling.validate()
    x_config.append(with_scaling.as_json())

    quantile_range_min = configuration.NumericConfiguration()
    quantile_range_min.data_type = configuration.DataType.FLOAT.value
    quantile_range_min.name = "quantile_range_min"
    quantile_range_min.description = "Min value of Quantile range used to calculate scale_"
    quantile_range_min.value = 25
    quantile_range_min.min_value = 0
    quantile_range_min.max_value = 100
    quantile_range_min.config_path = "config.algorithm.configuration.quantile_range_min"
    quantile_range_min.validate()
    x_config.append(quantile_range_min.as_json())

    quantile_range_max = configuration.NumericConfiguration()
    quantile_range_max.data_type = configuration.DataType.FLOAT.value
    quantile_range_max.name = "quantile_range_max"
    quantile_range_max.description = "Max value of Quantile range used to calculate scale_"
    quantile_range_max.value = 75
    quantile_range_max.min_value = 0
    quantile_range_max.max_value = 100
    quantile_range_max.config_path = "config.algorithm.configuration.quantile_range_max"
    quantile_range_max.validate()
    x_config.append(quantile_range_max.as_json())

    copy = configuration.BooleanConfiguration()
    copy.data_type = configuration.DataType.BOOLEAN.value
    copy.description = "To copy or not"
    copy.name = "copy"
    copy.options = [True, False]
    copy.value = True
    copy.config_path = "config.algorithm.configuration.copy"
    copy.op_type = configuration.OpType.CATEGORICAL.value
    copy.validate()
    x_config.append(copy.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.preprocessing.RobustScaler"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


def register_task(solution_id=None, task_det=None):
    name = "SKL Robust Scaler"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search"
            },
            "class": "sklearn.preprocessing.RobustScaler"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.preprocessing_robust_scaler",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Scikit-Learn Wrapper interface for Robust Scaler."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
