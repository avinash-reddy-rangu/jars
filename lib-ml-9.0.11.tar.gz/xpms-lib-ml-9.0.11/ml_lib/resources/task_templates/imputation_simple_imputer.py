from ml_lib.utils import create_task
from xpms_objects.models import configuration


# NOte: avoided model.id

def generate_extras():
    # setting up configurations
    x_config = []

    # supporting only for NAN type, need to add support for strings and Numeric Data
    missing_values = configuration.StringConfiguration()
    missing_values.data_type = configuration.DataType.STRING.value
    missing_values.name = "Value to Replace"
    missing_values.description = "The placeholder for missing values. All occurrences of missing_values will be imputed"
    missing_values.value = "nan"
    missing_values.config_path = "config.algorithm.configuration.missing_values"
    missing_values.validate()
    x_config.append(missing_values.as_json())

    col_name = configuration.StringConfiguration()
    col_name.data_type = configuration.DataType.STRING.value
    col_name.name = "Column Name/s"
    col_name.description = "Column names on which imputation is to be performed"
    col_name.value = "all"
    col_name.multi_select = True
    col_name.config_path = "config.algorithm.configuration.col_name"
    col_name.validate()
    x_config.append(col_name.as_json())

    col_dt = configuration.CategoricalListConfiguration()
    col_dt.data_type = configuration.DataType.STRING.value
    col_dt.name = "Data type for selected columns"
    col_dt.description = "Selected columns Data type"
    col_dt.value = "none"
    col_dt.options = ["int", "float", "string"]
    col_dt.config_path = "config.algorithm.configuration.col_dt"
    col_dt.validate()
    x_config.append(col_dt.as_json())

    strategy = configuration.CategoricalListConfiguration()
    strategy.data_type = configuration.DataType.STRING.value
    strategy.name = "strategy"
    strategy.description = "The imputation strategy"
    strategy.value = "mean"
    strategy.options = ["mean", "median", "most_frequent", "constant"]
    strategy.config_path = "config.algorithm.configuration.strategy"
    strategy.validate()
    x_config.append(strategy.as_json())

    # supporting only to replace NAN type, need to add support for strings and Numeric Data
    fill_value = configuration.StringConfiguration()
    fill_value.data_type = configuration.DataType.STRING.value
    fill_value.name = "fill_value"
    fill_value.description = "fill_value is used to replace all occurrences of missing_values"
    fill_value.value = ""
    fill_value.config_path = "config.algorithm.configuration.fill_value"
    fill_value.validate()
    x_config.append(fill_value.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.imputation.SimpleImputer"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL Simple Imputer"
    config = {
        "algorithm": {

            "auto_tuner": {"name": "grid_search"},
            "class": "sklearn.impute.SimpleImputer"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.dataset_skl_imputation",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "SKL Simple Imputer"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
