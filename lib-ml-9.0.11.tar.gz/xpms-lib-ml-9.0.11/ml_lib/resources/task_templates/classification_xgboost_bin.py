from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []
    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    objective = configuration.CategoricalListConfiguration()
    objective.options = [
        "binary:logistic"
    ]
    objective.value = "binary:logistic"
    objective.is_option_object = False
    objective.data_type = configuration.DataType.STRING.value
    objective.name = "objective"
    objective.description = "Specify the learning task and the corresponding learning objective to be used"
    objective.config_path = "config.algorithm.configuration.params.objective"
    objective.validate()
    x_config.append(objective.as_json())

    num_boost_round = configuration.NumericConfiguration()
    num_boost_round.data_type = configuration.DataType.INTEGER.value
    num_boost_round.description = "number of boost rounds"
    num_boost_round.name = "num_boost_round"
    num_boost_round.min_value = 2
    num_boost_round.value = 10
    num_boost_round.config_path = "config.algorithm.configuration.num_boost_round"
    num_boost_round.validate()
    x_config.append(num_boost_round.as_json())

    eta = configuration.NumericConfiguration()
    eta.name = "eta"
    eta.description = ""
    eta.value = 0.3
    eta.data_type = configuration.DataType.FLOAT.value
    eta.config_path = "config.algorithm.configuration.params.eta"
    eta.hidden = False
    eta.max_value=1
    eta.min_value=0
    eta.closure = configuration.Closure.OPEN_CLOSED.value
    eta.validate()
    x_config.append(eta.as_json())

    min_child_weight = configuration.NumericConfiguration()
    min_child_weight.name = "min_child_weight"
    min_child_weight.description = ""
    min_child_weight.value = 1
    min_child_weight.min_value = 1
    min_child_weight.data_type = configuration.DataType.INTEGER.value
    min_child_weight.config_path = "config.algorithm.configuration.params.min_child_weight"
    min_child_weight.hidden = False
    min_child_weight.validate()
    x_config.append(min_child_weight.as_json())

    scale_pos_weight = configuration.NumericConfiguration()
    scale_pos_weight.name = "scale_pos_weight"
    scale_pos_weight.description = ""
    scale_pos_weight.value = 1
    scale_pos_weight.data_type = configuration.DataType.FLOAT.value
    scale_pos_weight.config_path = "config.algorithm.configuration.params.scale_pos_weight"
    scale_pos_weight.validate()
    x_config.append(scale_pos_weight.as_json())

    max_depth = configuration.NumericConfiguration()
    max_depth.name = "max_depth"
    max_depth.description = ""
    max_depth.value = 6
    max_depth.min_value = 1
    max_depth.data_type = configuration.DataType.INTEGER.value
    max_depth.config_path = "config.algorithm.configuration.params.max_depth"
    max_depth.hidden = False
    max_depth.validate()
    x_config.append(max_depth.as_json())

    n_estimators = configuration.NumericConfiguration()
    n_estimators.data_type = configuration.DataType.INTEGER.value
    n_estimators.description = "Number of trees to fit."
    n_estimators.name = "n estimators"
    n_estimators.value = 100
    n_estimators.min_value = 2
    n_estimators.max_value = 20000
    n_estimators.config_path = "config.algorithm.configuration.params.n_estimators"
    n_estimators.validate()
    x_config.append(n_estimators.as_json())


    subsample = configuration.NumericConfiguration()
    subsample.data_type = configuration.DataType.FLOAT.value  # need to edit it to array
    subsample.description = "Subsample ratio of the training instance."
    subsample.name = "subsample"
    subsample.min_value = 0
    subsample.max_value = 1
    subsample.value = 1
    subsample.closure = configuration.Closure.OPEN_CLOSED.value
    subsample.config_path = "config.algorithm.configuration.params.subsample"
    subsample.validate()
    x_config.append(subsample.as_json())


    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "xgboost.XGB_MultiClassifier"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL XGBoost Bin Classifier"
    config = {
        "algorithm": {
            "class": "xgb"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.classification_xgb_multi_incremental",
        "files": [],
        "model_class": "classification"
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Classification using XGBoost."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)


