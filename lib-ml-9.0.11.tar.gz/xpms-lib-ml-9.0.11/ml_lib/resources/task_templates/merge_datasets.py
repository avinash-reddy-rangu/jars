from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []

    ui_index = "format_conversions.merge_datasets"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "Average"
    config = {
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.dataset_custom_merge_datasets",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "computes the sum of the incoming homogeneous datasets"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
