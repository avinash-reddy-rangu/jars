from ml_lib.utils import create_task
from xpms_objects.models import configuration


# NOte: avoided model.id

def generate_extras():
    # setting up configurations
    x_config = []

    # supporting only for Numeric Data, need to add support for strings
    missing_values = configuration.CategoricalListConfiguration()
    missing_values.data_type = configuration.DataType.STRING.value
    missing_values.name = "missing_values"
    missing_values.description = "The placeholder for missing values. All occurrences of missing_values will be imputed"
    missing_values.value = "np.nan"
    missing_values.options = ["int", "np.nan"]
    missing_values.config_path = "config.algorithm.configuration.missing_values"
    missing_values.validate()
    x_config.append(missing_values.as_json())

    initial_strategy = configuration.CategoricalListConfiguration()
    initial_strategy.data_type = configuration.DataType.STRING.value
    initial_strategy.name = "initial_strategy"
    initial_strategy.description = "Which strategy to use to initialize the missing values"
    initial_strategy.value = "mean"
    initial_strategy.options = ["mean", "median", "constant"]
    initial_strategy.config_path = "config.algorithm.configuration.initial_strategy"
    initial_strategy.validate()
    x_config.append(initial_strategy.as_json())

    # supporting only for Numeric Data, need to add support for strings
    fill_value = configuration.NumericConfiguration()
    fill_value.data_type = configuration.DataType.INTEGER.value
    fill_value.name = "fill_value_int"
    fill_value.description = "fill_value is used to replace all occurrences of missing_values"
    fill_value.value = 0
    fill_value.config_path = "config.algorithm.configuration.fill_value"
    fill_value.validate()
    x_config.append(fill_value.as_json())

    max_iter = configuration.NumericConfiguration()
    max_iter.data_type = configuration.DataType.INTEGER.value
    max_iter.description = "Maximum number of imputation rounds to perform before returning the imputations" \
                           " computed during the final round"
    max_iter.name = "max_iter"
    max_iter.min_value = 0
    max_iter.max_value = 100
    max_iter.value = 10
    max_iter.config_path = "config.algorithm.configuration.max_iter"
    max_iter.validate()
    x_config.append(max_iter.as_json())

    tol = configuration.NumericConfiguration()
    tol.data_type = configuration.DataType.FLOAT.value
    tol.description = "Tolerance of the stopping condition"
    tol.name = "tol"
    tol.min_value = 0.001
    tol.max_value = 100
    tol.value = 0.001
    tol.config_path = "config.algorithm.configuration.tol"
    tol.validate()
    x_config.append(tol.as_json())

    imputation_order = configuration.CategoricalListConfiguration()
    imputation_order.data_type = configuration.DataType.STRING.value
    imputation_order.name = "imputation_order"
    imputation_order.description = "The order in which the features will be imputed"
    imputation_order.value = "ascending"
    imputation_order.options = ["ascending", "descending", "roman", "arabic", "random"]
    imputation_order.config_path = "config.algorithm.configuration.imputation_order"
    imputation_order.validate()
    x_config.append(imputation_order.as_json())

    # currently not supported as default value is NONE
    # n_nearest_features = configuration.NumericConfiguration()
    # n_nearest_features.data_type = configuration.DataType.INTEGER.value
    # n_nearest_features.description = "Number of other features to use, " \
    #                                  "to estimate missing values of each feature column"
    # n_nearest_features.name = "n_nearest_features"
    # n_nearest_features.min_value = 0
    # n_nearest_features.max_value = 100
    # n_nearest_features.value = 0.0001
    # n_nearest_features.config_path = "config.algorithm.configuration.n_nearest_features"
    # n_nearest_features.validate()
    # x_config.append(n_nearest_features.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.imputation.IterativeImputer"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL Iterative Imputer"
    config = {
        "algorithm": {

            "auto_tuner": {"name": "grid_search"},
            "class": "sklearn.impute.IterativeImputer"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.dataset_iterative_imputer",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "SKL Iterative Imputer"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
