def make_task(task_dict):
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = "system"
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["description"] = "Default Description"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    return task_dict
