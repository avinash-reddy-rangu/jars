from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []

    col_name = configuration.StringConfiguration()
    col_name.data_type = configuration.DataType.STRING.value
    col_name.name = "Column Name/s"
    col_name.description = "Column names on which imputation is to be performed"
    col_name.value = "all"
    col_name.multi_select = True
    col_name.config_path = "config.algorithm.configuration.col_name"
    col_name.validate()
    x_config.append(col_name.as_json())

    n_quantiles = configuration.NumericConfiguration()
    n_quantiles.data_type = configuration.DataType.INTEGER.value
    n_quantiles.name = "n_quantiles"
    n_quantiles.description = "Number of quantiles to be computed"
    n_quantiles.value = 1000
    n_quantiles.config_path = "config.algorithm.configuration.n_quantiles"
    n_quantiles.validate()
    x_config.append(n_quantiles.as_json())

    output_distribution = configuration.CategoricalListConfiguration()
    output_distribution.data_type = configuration.DataType.STRING.value
    output_distribution.name = "output distribution"
    output_distribution.description = "Marginal distribution for the transformed data."
    output_distribution.value = "uniform"
    output_distribution.options = ["uniform", "normal"]
    output_distribution.config_path = "config.algorithm.configuration.output_distribution"
    output_distribution.validate()
    x_config.append(output_distribution.as_json())

    ignore_implicit_zeros = configuration.BooleanConfiguration()
    ignore_implicit_zeros.data_type = configuration.DataType.BOOLEAN.value
    ignore_implicit_zeros.description = "Only applies to sparse matrices"
    ignore_implicit_zeros.name = "ignore_implicit_zeros"
    ignore_implicit_zeros.options = [True, False]
    ignore_implicit_zeros.value = False
    ignore_implicit_zeros.config_path = "config.algorithm.configuration.ignore_implicit_zeros"
    ignore_implicit_zeros.op_type = configuration.OpType.CATEGORICAL.value
    ignore_implicit_zeros.validate()
    x_config.append(ignore_implicit_zeros.as_json())

    subsample = configuration.NumericConfiguration()
    subsample.data_type = configuration.DataType.FLOAT.value
    subsample.name = "subsample"
    subsample.description = "Maximum number of samples used to estimate the quantiles for computational efficiency"
    subsample.value = 100000
    subsample.config_path = "config.algorithm.configuration.subsample"
    subsample.validate()
    x_config.append(subsample.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.preprocessing.QuantileTransformer"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


def register_task(solution_id=None, task_det=None):
    name = "SKL Quantile Transformer"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search"
            },
            "class": "sklearn.preprocessing.QuantileTransformer"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.preprocessing_quantile_transformer",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Scikit-Learn Wrapper interface for Quantile Transformer."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)

register_task()