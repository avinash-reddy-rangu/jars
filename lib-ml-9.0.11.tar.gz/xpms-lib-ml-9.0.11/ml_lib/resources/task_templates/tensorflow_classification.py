from xpms_objects.models import configuration

from ml_lib.utils import create_task


def generate_extras():
    # setting up configurations
    x_config = []
    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    binary_files = configuration.PlatformApiListConfiguration()
    binary_files.name = "binary_file"
    binary_files.description = "select the binary in binary repository that you want to use"
    binary_files.api = "faas/binaries/get"
    binary_files.config_path = "config.binary.model_file"
    binary_files.options = "result.metadata.binaries"
    binary_files.display_key = "name"
    binary_files.trigger = "get_binaries"
    binary_files.option_type = "dict"
    binary_files.request_data = {}
    binary_files.value_key = "file_name"
    x_config.append(binary_files.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "tf.classification"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


def register_task(solution_id=None, task_det=None):
    name = "Tensor Flow Classification"
    config = {
        "source_type": "lib",
        "model_class": "classification",
        "algorithm": "",
        "source": "ml_lib.resources.task_scripts.tf_classification_run",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Tensorflow Classification"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)


