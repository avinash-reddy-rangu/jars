from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []

    target_column = configuration.StringConfiguration()
    target_column.name = "target column"
    target_column.description = "select the column whose content you want to extract"
    target_column.multi_select = False
    target_column.data_type = configuration.DataType.STRING.value
    target_column.config_path = "config.func.configuration.target_column"
    target_column.value = "file_path"
    target_column.validate()
    x_config.append(target_column.as_json())

    content_type = configuration.CategoricalListConfiguration()
    content_type.options = ["text"]
    content_type.description = "content type of the target column"
    content_type.data_type = configuration.DataType.STRING.value
    content_type.name = "content"
    content_type.value = "text"
    content_type.config_path = "config.func.configuration.content"
    content_type.hidden = False
    content_type.validate()
    x_config.append(content_type.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "format_convertors.extract_file_column"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "Extract File Column"
    config = {

        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.dataset_custom_extract_file_column",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "extracts content of a filetype column"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
