from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []

    columns = configuration.StringConfiguration()
    columns.name = "columns"
    columns.description = "subsetting a list of columns from a dataset"
    columns.multi_select = True
    columns.data_type = configuration.DataType.STRING.value
    columns.config_path = "config.func.configuration.columns"
    columns.value = []
    columns.validate()
    x_config.append(columns.as_json())

    optional_columns = configuration.StringConfiguration()
    optional_columns.name = "optional_columns"
    optional_columns.description = "subsetting a list of columns from a dataset"
    optional_columns.multi_select = True
    optional_columns.data_type = configuration.DataType.STRING.value
    optional_columns.config_path = "config.func.configuration.optional_columns"
    optional_columns.value = []
    optional_columns.validate()
    x_config.append(optional_columns.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "format_convertors.select_columns"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "Select Columns"
    config = {
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.dataset_custom_select_columns",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Selecting the multiple columns from a dataset"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
