from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []
    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    link_task = configuration.PlatformApiListConfiguration()
    link_task.name = "task reference"
    link_task.is_option_object = True
    link_task.value = "none"
    link_task.config_path = "config.task_reference"
    link_task.description = "link a pre_existing task in the model"
    link_task.api = "ml/task/list_instances"
    link_task.options = "result.metadata.tasks"
    link_task.value_key = "instance_id"
    link_task.display_key = "name"
    link_task.trigger = "list_ml_task_instances"
    link_task.custom_request_data = ["model.model_id", "model.version_id", "task.task_id"]
    link_task.request_data = {
        "model": {"model_id": "", "version_id": ""},
        "task": {"task_id": ""}
    }
    link_task.validate()
    x_config.append(link_task.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    n_neighbors = configuration.NumericConfiguration()
    n_neighbors.data_type = configuration.DataType.INTEGER.value
    n_neighbors.description = "Number of neighbors to use"
    n_neighbors.name = "n_neighbors"
    n_neighbors.max_value = 50
    n_neighbors.min_value = 1
    n_neighbors.value = 5
    n_neighbors.config_path = "config.algorithm.configuration.n_neighbors"
    n_neighbors.validate()
    x_config.append(n_neighbors.as_json())

    weights = configuration.CategoricalListConfiguration()
    weights.name = "weights"
    weights.description = "weight function used in prediction"
    weights.options = ["uniform", "distance"]
    weights.value = "uniform"
    weights.data_type = configuration.DataType.STRING.value
    weights.config_path = "config.algorithm.configuration.weights"
    weights.validate()
    x_config.append(weights.as_json())

    algorithm = configuration.CategoricalListConfiguration()
    algorithm.name = "algorithm"
    algorithm.description = "Algorithm used to compute the nearest neighbors"
    algorithm.options = ["ball_tree", "kd_tree", "brute", "auto"]
    algorithm.value = "ball_tree"
    algorithm.data_type = configuration.DataType.STRING.value
    algorithm.config_path = "config.algorithm.configuration.algorithm"
    algorithm.validate()
    x_config.append(algorithm.as_json())

    leaf_size = configuration.NumericConfiguration()
    leaf_size.data_type = configuration.DataType.INTEGER.value
    leaf_size.description = "Leaf size passed to BallTree or KDTree. This can affect the speed of the construction " \
                            "and query, as well as the memory required to store the tree."
    leaf_size.name = "leaf_size"
    leaf_size.max_value = 100
    leaf_size.min_value = 1
    leaf_size.value = 30
    leaf_size.config_path = "config.algorithm.configuration.leaf_size"
    leaf_size.validate()
    x_config.append(leaf_size.as_json())

    p = configuration.NumericConfiguration()
    p.data_type = configuration.DataType.INTEGER.value
    p.description = "Power parameter for the Minkowski metric"
    p.name = "p"
    p.max_value = 50
    p.min_value = -1
    p.value = 2
    p.config_path = "config.algorithm.configuration.p"
    p.validate()
    x_config.append(p.as_json())

    n_jobs = configuration.NumericConfiguration()
    n_jobs.data_type = configuration.DataType.INTEGER.value
    n_jobs.description = "The number of parallel jobs to run for neighbors search"
    n_jobs.name = "n_jobs"
    n_jobs.max_value = 50
    n_jobs.min_value = -1
    n_jobs.value = 1
    n_jobs.config_path = "config.algorithm.configuration.n_jobs"
    n_jobs.validate()
    x_config.append(n_jobs.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.regression.KNeighborsRegressor"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL KNN Regressor"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search"
            },
            "class": "sklearn.neighbors.KNeighborsRegressor"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.regression_algo_skl_model_runner",
        "files": [],
        "model_class": "regression"
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Scikit-Learn Wrapper interface for KNN Regressor."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)


