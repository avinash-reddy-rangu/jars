from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations

    x_config = []

    link_task = configuration.PlatformApiListConfiguration()
    link_task.name = "task reference"
    link_task.is_option_object = True
    link_task.value = "none"
    link_task.config_path = "config.task_reference"
    link_task.description = "link a pre_existing task in the model"
    link_task.api = "ml/task/list_instances"
    link_task.options = "result.metadata.tasks"
    link_task.value_key = "instance_id"
    link_task.display_key = "name"
    link_task.trigger = "list_ml_task_instances"
    link_task.custom_request_data = ["model.model_id", "model.version_id", "task.task_id"]
    link_task.request_data = {
        "model": {"model_id": "", "version_id": ""},
        "task": {"task_id": ""}
    }
    link_task.validate()
    x_config.append(link_task.as_json())

    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    l1_ratio = configuration.NumericConfiguration()
    l1_ratio.data_type = configuration.DataType.FLOAT.value
    l1_ratio.description = "float between 0 and 1 passed to ElasticNet (scaling between l1 and l2 penalties). For l1_ratio = 0 the penalty is an L2 penalty. For l1_ratio = 1 it is an L1 penalty. For 0 < l1_ratio < 1, the penalty is a combination of L1 and L2"
    l1_ratio.name = "l1_ratio"
    l1_ratio.max_value = 1
    l1_ratio.min_value = 0
    l1_ratio.value = 0.5
    l1_ratio.closure = configuration.Closure.CLOSED_CLOSED.value
    l1_ratio.config_path = "config.algorithm.configuration.l1_ratio"
    l1_ratio.validate()
    x_config.append(l1_ratio.as_json())

    eps = configuration.NumericConfiguration()
    eps.data_type = configuration.DataType.FLOAT.value
    eps.description = "Length of the path. eps=1e-3 means that alpha_min / alpha_max = 1e-3."
    eps.name = "eps"
    eps.value = 0.001
    eps.min_value = 0
    eps.max_value = 1
    eps.closure = configuration.Closure.OPEN_OPEN.value
    eps.config_path = "config.algorithm.configuration.eps"
    eps.validate()
    x_config.append(eps.as_json())

    n_alphas = configuration.NumericConfiguration()
    n_alphas.data_type = configuration.DataType.INTEGER.value
    n_alphas.description = "Number of alphas along the regularization path, used for each l1_ratio."
    n_alphas.name = "n_alphas"
    n_alphas.value = 100
    n_alphas.min_value = 10
    n_alphas.max_value = 10000
    n_alphas.closure = configuration.Closure.OPEN_OPEN.value
    n_alphas.config_path = "config.algorithm.configuration.n_alphas"
    n_alphas.validate()
    x_config.append(n_alphas.as_json())

    max_iter = configuration.NumericConfiguration()
    max_iter.data_type = configuration.DataType.INTEGER.value
    max_iter.description = "Number of alphas along the regularization path, used for each l1_ratio."
    max_iter.name = "max_iter"
    max_iter.value = 1000
    max_iter.min_value = 10
    max_iter.max_value = 30000
    max_iter.closure = configuration.Closure.OPEN_OPEN.value
    max_iter.config_path = "config.algorithm.configuration.max_iter"
    max_iter.validate()
    x_config.append(max_iter.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.regression.ElasticNetCV"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL ElasticNetCV Classifier"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search"
            },
            "class": "sklearn.linear_model.ElasticNetCV"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.regression_algo_skl_model_runner",
        "files": [],
        "model_class": "regression"
    }
    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Scikit-Learn Wrapper interface for ElasticNetCV."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
