from ml_lib.utils import create_task
from xpms_objects.models import configuration



def generate_extras():
    # setting up configurations
    x_config = []

    data_format = configuration.CategoricalListConfiguration()
    data_format.data_type = configuration.DataType.STRING.value
    data_format.description = "specifies the format for conversion of the data"
    data_format.name = "convert_to"
    data_format.options = ["data_frame"]
    data_format.value = "data_frame"
    data_format.config_path = "config.func.configuration.convert_to"
    data_format.validate()
    x_config.append(data_format.as_json())

    data_schema = configuration.CategoricalDictConfiguration()
    data_schema.description = "data schema"
    data_schema.name = "data_schema"
    data_schema.value = None
    data_schema.config_path = "config.func.configuration.data_schema"
    data_schema.hidden = True
    data_schema.validate()
    x_config.append(data_schema.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "format_convertors.convert_dataset"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "Convert Dataset"
    config = {
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.dataset_custom_convert_dataset",
        "files": [
        ]
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Converting the data into required format"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)


