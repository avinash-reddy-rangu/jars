from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []
    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    objective = configuration.CategoricalListConfiguration()
    objective.options = [
        "multi:softmax",
        "multi:softprob",
        "binary:logistic"
    ]
    objective.value = "binary:logistic"
    objective.is_option_object = False
    objective.data_type = configuration.DataType.STRING.value
    objective.name = "objective"
    objective.description = "Specify the learning task and the corresponding learning objective to be used"
    objective.config_path = "config.algorithm.configuration.objective"
    objective.validate()
    x_config.append(objective.as_json())

    verbosity = configuration.NumericConfiguration()
    verbosity.name = "verbosity"
    verbosity.description = ""
    verbosity.value = 0
    verbosity.data_type = configuration.DataType.FLOAT.value
    verbosity.config_path = "config.algorithm.configuration.verbosity"
    verbosity.hidden = True
    verbosity.validate()
    x_config.append(verbosity.as_json())

    link_task = configuration.PlatformApiListConfiguration()
    link_task.value = "none"
    link_task.name = "task reference"
    link_task.is_option_object = True
    link_task.config_path = "config.task_reference"
    link_task.description = "link a pre_existing task in the model"
    link_task.api = "ml/task/list_instances"
    link_task.options = "result.metadata.tasks"
    link_task.value_key = "instance_id"
    link_task.display_key = "name"
    link_task.trigger = "list_ml_task_instances"
    link_task.custom_request_data = ["model.model_id", "model.version_id", "task.task_id"]
    link_task.request_data = {
        "model": {"model_id": "", "version_id": ""},
        "task": {"task_id": ""}
    }
    link_task.validate()
    x_config.append(link_task.as_json())

    max_depth = configuration.NumericConfiguration()
    max_depth.data_type = configuration.DataType.INTEGER.value
    max_depth.description = "Maximum tree depth for base learners"
    max_depth.name = "max depth"
    max_depth.min_value = 2
    max_depth.max_value = 15
    max_depth.value = 5
    max_depth.closure = configuration.Closure.CLOSED_CLOSED.value
    max_depth.config_path = "config.algorithm.configuration.max_depth"
    max_depth.validate()
    x_config.append(max_depth.as_json())

    learning_rate = configuration.NumericConfiguration()
    learning_rate.data_type = configuration.DataType.FLOAT.value
    learning_rate.description = "Boosting learning rate (xgb’s eta)"
    learning_rate.name = "learning rate"
    learning_rate.max_value = 1
    learning_rate.min_value = 0
    learning_rate.value = 0.1
    learning_rate.config_path = "config.algorithm.configuration.learning_rate"
    learning_rate.validate()
    x_config.append(learning_rate.as_json())

    n_estimators = configuration.NumericConfiguration()
    n_estimators.data_type = configuration.DataType.INTEGER.value
    n_estimators.description = "Number of trees to fit."
    n_estimators.name = "n estimators"
    n_estimators.value = 100
    n_estimators.min_value = 2
    n_estimators.max_value = 20000
    n_estimators.config_path = "config.algorithm.configuration.n_estimators"
    n_estimators.validate()
    x_config.append(n_estimators.as_json())

    subsample = configuration.NumericConfiguration()
    subsample.data_type = configuration.DataType.INTEGER.value  # need to edit it to array
    subsample.description = "Subsample ratio of the training instance."
    subsample.name = "subsample"
    subsample.min_value = 0
    subsample.max_value = 1
    subsample.value = 1
    subsample.closure = configuration.Closure.OPEN_CLOSED.value
    subsample.config_path = "config.algorithm.configuration.subsample"
    subsample.validate()
    x_config.append(subsample.as_json())

    min_child_weight = configuration.NumericConfiguration()
    min_child_weight.data_type = configuration.DataType.INTEGER.value  # need to edit it to array
    min_child_weight.description = "Minimum sum of instance weight(hessian) needed in a child."
    min_child_weight.name = "min_child_weight"
    min_child_weight.min_value = 1
    min_child_weight.max_value = 1000
    min_child_weight.value = 1
    min_child_weight.closure = configuration.Closure.CLOSED_CLOSED.value
    min_child_weight.config_path = "config.algorithm.configuration.min_child_weight"
    min_child_weight.validate()
    x_config.append(min_child_weight.as_json())

    multi_model = configuration.CategoricalListConfiguration()
    multi_model.name = "multi_model"
    multi_model.description = "to create model for each class"
    multi_model.data_type = configuration.DataType.BOOLEAN.value
    multi_model.value = False
    multi_model.options = [True, False]
    multi_model.config_path = "config.multi_model"
    multi_model.validate()
    x_config.append(multi_model.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "xgboost.XGB_MultiClassifier"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL XGB Multi Classifier"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search"
            },
            "class": "xgboost.XGBClassifier"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.classification_algo_skl_model_runner",
        "files": [],
        "model_class": "classification"
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Scikit-Learn Wrapper interface for XGBoost."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)


