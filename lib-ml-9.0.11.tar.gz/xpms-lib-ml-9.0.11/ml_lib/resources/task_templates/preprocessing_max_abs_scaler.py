from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    x_config = []

    col_name = configuration.StringConfiguration()
    col_name.data_type = configuration.DataType.STRING.value
    col_name.name = "Column Name/s"
    col_name.description = "Column names on which imputation is to be performed"
    col_name.value = "all"
    col_name.multi_select = True
    col_name.config_path = "config.algorithm.configuration.col_name"
    col_name.validate()
    x_config.append(col_name.as_json())

    copy = configuration.BooleanConfiguration()
    copy.data_type = configuration.DataType.BOOLEAN.value
    copy.description = "To copy or not"
    copy.name = "copy"
    copy.options = [True, False]
    copy.value = True
    copy.config_path = "config.algorithm.configuration.copy"
    copy.op_type = configuration.OpType.CATEGORICAL.value
    copy.validate()
    x_config.append(copy.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.preprocessing.MaxAbsScaler"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


def register_task(solution_id=None, task_det=None):
    name = "SKL MaxAbs Scaler"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search"
            },
            "class": "sklearn.preprocessing.MaxAbsScaler"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.preprocessing_maxabs_scaler",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Scikit-Learn Wrapper interface for MaxAbs Scaler."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
