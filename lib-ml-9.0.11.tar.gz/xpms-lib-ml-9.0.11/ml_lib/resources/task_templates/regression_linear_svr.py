from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations

    x_config = []

    link_task = configuration.PlatformApiListConfiguration()
    link_task.name = "task reference"
    link_task.is_option_object = True
    link_task.value = "none"
    link_task.config_path = "config.task_reference"
    link_task.description = "link a pre_existing task in the model"
    link_task.api = "ml/task/list_instances"
    link_task.options = "result.metadata.tasks"
    link_task.value_key = "instance_id"
    link_task.display_key = "name"
    link_task.trigger = "list_ml_task_instances"
    link_task.custom_request_data = ["model.model_id", "model.version_id", "task.task_id"]
    link_task.request_data = {
        "model": {"model_id": "", "version_id": ""},
        "task": {"task_id": ""}
    }
    link_task.validate()
    x_config.append(link_task.as_json())

    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    C = configuration.NumericConfiguration()
    C.data_type = configuration.DataType.FLOAT.value
    C.description = "Penalty parameter C of the error term. The penalty is a squared l2 penalty. " \
                    "The bigger this parameter, the less regularization is used."
    C.name = "C"
    C.max_value = 10000
    C.min_value = 0
    C.value = 1
    C.closure = configuration.Closure.CLOSED_CLOSED.value
    C.config_path = "config.algorithm.configuration.C"
    C.validate()
    x_config.append(C.as_json())

    loss = configuration.CategoricalListConfiguration()
    loss.data_type = configuration.DataType.STRING.value
    loss.description = "Specifies the loss function. The epsilon-insensitive loss (standard SVR) is the L1 loss," \
                       " while the squared epsilon-insensitive loss (‘squared_epsilon_insensitive’) is the L2 loss."
    loss.name = "loss"
    loss.value = "epsilon_insensitive"
    loss.options = ["epsilon_insensitive", "squared_epsilon_insensitive"]
    loss.config_path = "config.algorithm.configuration.loss"
    loss.validate()
    x_config.append(loss.as_json())

    epsilon = configuration.NumericConfiguration()
    epsilon.data_type = configuration.DataType.FLOAT.value
    epsilon.description = "Epsilon parameter in the epsilon-insensitive loss function. Note that the value of this " \
                          "parameter depends on the scale of the target variable y. If unsure, set epsilon=0"
    epsilon.name = "epsilon"
    epsilon.min_value = 0
    epsilon.max_value = 100
    epsilon.value = 0.0
    epsilon.config_path = "config.algorithm.configuration.epsilon"
    epsilon.validate()
    x_config.append(epsilon.as_json())

    dual = configuration.CategoricalListConfiguration()
    dual.data_type = configuration.DataType.BOOLEAN.value
    dual.description = "Select the algorithm to either solve the dual or primal optimization problem. " \
                       "Prefer dual=False when n_samples > n_features"
    dual.name = "dual"
    dual.value = True
    dual.options = [True, False]
    dual.config_path = "config.algorithm.configuration.dual"
    dual.validate()
    x_config.append(dual.as_json())

    tol = configuration.NumericConfiguration()
    tol.data_type = configuration.DataType.FLOAT.value
    tol.description = "Tolerance for stopping criterion"
    tol.name = "tol"
    tol.min_value = 0
    tol.max_value = 100
    tol.value = 0.0001
    tol.config_path = "config.algorithm.configuration.tol"
    tol.validate()
    x_config.append(tol.as_json())

    fit_intercept = configuration.BooleanConfiguration()
    fit_intercept.data_type = configuration.DataType.BOOLEAN.value
    fit_intercept.description = "Whether to calculate the intercept for this model"
    fit_intercept.name = "fit_intercept"
    fit_intercept.options = [True, False]
    fit_intercept.value = True
    fit_intercept.config_path = "config.algorithm.configuration.fit_intercept"
    fit_intercept.op_type = configuration.OpType.CATEGORICAL.value
    fit_intercept.validate()
    x_config.append(fit_intercept.as_json())

    intercept_scaling = configuration.NumericConfiguration()
    intercept_scaling.data_type = configuration.DataType.FLOAT.value
    intercept_scaling.description = "a “synthetic” feature with constant value equals to intercept_scaling is " \
                                    "appended to the instance vector"
    intercept_scaling.name = "intercept_scaling"
    intercept_scaling.min_value = 0
    intercept_scaling.max_value = 100
    intercept_scaling.value = 1.0
    intercept_scaling.config_path = "config.algorithm.configuration.intercept_scaling"
    intercept_scaling.validate()
    x_config.append(intercept_scaling.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    max_iter = configuration.NumericConfiguration()
    max_iter.data_type = configuration.DataType.INTEGER.value
    max_iter.min_value = -1
    max_iter.max_value = 1000
    max_iter.value = 100
    max_iter.name = "max_iter"
    max_iter.description = "Hard limit on iterations within solver"
    max_iter.config_path = "config.algorithm.configuration.max_iter"
    max_iter.validate()
    x_config.append(max_iter.as_json())

    ui_index = "sklearn.regression.LinearSVR"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL Linear SVR Regressor"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search"
            },
            "class": "sklearn.svm.LinearSVR"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.regression_algo_skl_model_runner",
        "files": [],
        "model_class": "regression"
    }
    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Scikit-Learn Wrapper interface for LinearSVR."
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
