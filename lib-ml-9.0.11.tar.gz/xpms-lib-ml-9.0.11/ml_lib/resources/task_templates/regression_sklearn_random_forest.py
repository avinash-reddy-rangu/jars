from xpms_objects.models import configuration

from ml_lib.utils import create_task


def generate_extras():
    # setting up configurations
    x_config = []
    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    link_task = configuration.PlatformApiListConfiguration()
    link_task.name = "task reference"
    link_task.is_option_object = True
    link_task.value = "none"
    link_task.config_path = "config.task_reference"
    link_task.description = "link a pre_existing task in the model"
    link_task.api = "ml/task/list_instances"
    link_task.options = "result.metadata.tasks"
    link_task.value_key = "instance_id"
    link_task.display_key = "name"
    link_task.trigger = "list_ml_task_instances"
    link_task.custom_request_data = ["model.model_id", "model.version_id", "task.task_id"]
    link_task.request_data = {
        "model": {"model_id": "", "version_id": ""},
        "task": {"task_id": ""}
    }
    link_task.validate()
    x_config.append(link_task.as_json())

    n_estimators = configuration.NumericConfiguration()
    n_estimators.data_type = configuration.DataType.INTEGER.value
    # For current version of sklearn - 0.19
    n_estimators.min_value = 10
    n_estimators.max_value = 100
    n_estimators.value = 10
    n_estimators.name = "n_estimators"
    n_estimators.description = "Number of trees to build"
    n_estimators.config_path = "config.algorithm.configuration.n_estimators"
    n_estimators.validate()
    x_config.append(n_estimators.as_json())

    criterion = configuration.StringConfiguration()
    criterion.data_type = configuration.DataType.STRING.value
    criterion.description = "Quality of Split"
    criterion.name = "criterion"
    criterion.value = "mse"
    criterion.config_path = "config.algorithm.configuration.criterion"
    criterion.validate()
    x_config.append(criterion.as_json())

    max_features = configuration.CategoricalListConfiguration()
    max_features.data_type = configuration.DataType.STRING.value
    max_features.description = "Number of features when looking for best split"
    max_features.name = "max_features"
    max_features.options = ["auto", "log2", "sqrt"]
    max_features.value = "auto"
    max_features.config_path = "config.algorithm.configuration.max_features"
    max_features.validate()
    x_config.append(max_features.as_json())

    min_weight_fraction_leaf = configuration.NumericConfiguration()
    min_weight_fraction_leaf.data_type = configuration.DataType.FLOAT.value
    min_weight_fraction_leaf.min_value = 0
    min_weight_fraction_leaf.max_value = 0.5
    min_weight_fraction_leaf.value = 0
    min_weight_fraction_leaf.name = "min_weight_fraction_leaf"
    min_weight_fraction_leaf.description = "Minimum weight required to be at Leaf nodes"
    min_weight_fraction_leaf.config_path = "config.algorithm.configuration.min_weight_fraction_leaf"
    min_weight_fraction_leaf.validate()
    x_config.append(min_weight_fraction_leaf.as_json())

    min_samples_split = configuration.NumericConfiguration()
    min_samples_split.data_type = configuration.DataType.INTEGER.value
    min_samples_split.min_value = 0
    min_samples_split.max_value = 100
    min_samples_split.value = 2
    min_samples_split.name = "min_samples_split"
    min_samples_split.description = "Number of samples required to split an Internal node"
    min_samples_split.config_path = "config.algorithm.configuration.min_samples_split"
    min_samples_split.validate()
    x_config.append(min_samples_split.as_json())

    min_samples_leaf = configuration.NumericConfiguration()
    min_samples_leaf.data_type = configuration.DataType.INTEGER.value
    min_samples_leaf.min_value = 0
    min_samples_leaf.max_value = 100
    min_samples_leaf.value = 1
    min_samples_leaf.name = "min_samples_leaf"
    min_samples_leaf.description = "Number of samples required to be at leaf node"
    min_samples_leaf.config_path = "config.algorithm.configuration.min_samples_leaf"
    min_samples_leaf.validate()
    x_config.append(min_samples_leaf.as_json())

    max_leaf_nodes = configuration.NumericConfiguration()
    max_leaf_nodes.data_type = configuration.DataType.INTEGER.value
    max_leaf_nodes.min_value = 2
    max_leaf_nodes.max_value = 100
    max_leaf_nodes.value = 2
    max_leaf_nodes.name = "max_leaf_nodes"
    max_leaf_nodes.description = "Number of Leaf Nodes"
    max_leaf_nodes.config_path = "config.algorithm.configuration.max_leaf_nodes"
    max_leaf_nodes.validate()
    x_config.append(max_leaf_nodes.as_json())

    min_impurity_decrease = configuration.NumericConfiguration()
    min_impurity_decrease.data_type = configuration.DataType.FLOAT.value
    min_impurity_decrease.min_value = 0
    min_impurity_decrease.max_value = 100
    min_impurity_decrease.value = 0
    min_impurity_decrease.name = "min_impurity_decrease"
    min_impurity_decrease.description = "Inverse of regularization strength"
    min_impurity_decrease.config_path = "config.algorithm.configuration.min_impurity_decrease"
    min_impurity_decrease.validate()
    x_config.append(min_impurity_decrease.as_json())

    bootstrap = configuration.BooleanConfiguration()
    bootstrap.data_type = configuration.DataType.BOOLEAN.value
    bootstrap.description = "Bootstrap samples to build trees"
    bootstrap.name = "bootstrap"
    bootstrap.options = [True, False]
    bootstrap.value = True
    bootstrap.config_path = "config.algorithm.configuration.bootstrap"
    bootstrap.op_type = configuration.OpType.CATEGORICAL.value
    bootstrap.validate()
    x_config.append(bootstrap.as_json())

    verbose = configuration.NumericConfiguration()
    verbose.data_type = configuration.DataType.FLOAT.value
    verbose.min_value = 0
    verbose.max_value = 100
    verbose.value = 0
    verbose.name = "verbose"
    verbose.description = "Controls the Verbosity of tree building process"
    verbose.config_path = "config.algorithm.configuration.verbose"
    verbose.validate()
    x_config.append(verbose.as_json())

    oob_score = configuration.BooleanConfiguration()
    oob_score.data_type = configuration.DataType.BOOLEAN.value
    oob_score.description = "Use of out of bag samples"
    oob_score.name = "oob_score"
    oob_score.options = [True, False]
    oob_score.value = False
    oob_score.config_path = "config.algorithm.configuration.oob_score"
    oob_score.op_type = configuration.OpType.CATEGORICAL.value
    oob_score.validate()
    x_config.append(oob_score.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.regression.RandomForest"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL Random Forest Regressor"
    config = {
        "source_type": "lib",
        "algorithm": {
            "auto_tuner": {"name": "grid_search"},
            "class": "sklearn.ensemble.RandomForestRegressor"
        },
        "source": "ml_lib.resources.task_scripts.regression_algo_skl_model_runner",
        "files": [],
        "model_class": "regression"
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Sklearn Random Forest Regressor"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
    return task_dict


