from ml_lib.utils import create_task
from xpms_objects.models import configuration


def generate_extras():
    # setting up configurations
    # default config

    x_config = []
    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    link_task = configuration.PlatformApiListConfiguration()
    link_task.name = "task reference"
    link_task.is_option_object = True
    link_task.value = "none"
    link_task.config_path = "config.task_reference"
    link_task.description = "link a pre_existing task in the model"
    link_task.api = "ml/task/list_instances"
    link_task.options = "result.metadata.tasks"
    link_task.value_key = "instance_id"
    link_task.display_key = "name"
    link_task.trigger = "list_ml_task_instances"
    link_task.custom_request_data = ["model.model_id", "model.version_id", "task.task_id"]
    link_task.request_data = {
        "model": {"model_id": "", "version_id": ""},
        "task": {"task_id": ""}
    }
    link_task.validate()
    x_config.append(link_task.as_json())

    # model specific configurations

    C = configuration.NumericConfiguration()
    C.data_type = configuration.DataType.FLOAT.value
    C.description = "Penalty parameter C of the error term."
    C.name = "C"
    C.min_value = 0
    C.max_value = 100
    C.value = 1
    C.config_path = "config.algorithm.configuration.C"
    C.validate()
    x_config.append(C.as_json())

    epsilon = configuration.NumericConfiguration()
    epsilon.data_type = configuration.DataType.FLOAT.value
    epsilon.description = "It specifies the epsilon-tube within which no penalty is associated in the" \
                          "training loss function with points predicted within a distance epsilon from actual value."
    epsilon.name = "epsilon"
    epsilon.min_value = 0
    epsilon.max_value = 100
    epsilon.value = 0.1
    epsilon.config_path = "config.algorithm.configuration.epsilon"
    epsilon.validate()
    x_config.append(epsilon.as_json())

    kernel = configuration.CategoricalListConfiguration()
    kernel.data_type = configuration.DataType.STRING.value
    kernel.description = "Specifies the kernel type to be used in the algorithm."
    kernel.name = "kernel"
    kernel.options = ["poly", "rbf", "sigmoid"]
    kernel.value = "rbf"
    kernel.config_path = "config.algorithm.configuration.kernel"
    kernel.validate()
    x_config.append(kernel.as_json())

    degree = configuration.NumericConfiguration()
    degree.data_type = configuration.DataType.INTEGER.value
    degree.min_value = 0
    degree.max_value = 100
    degree.value = 3
    degree.name = "degree"
    degree.description = "Degree of polynomial kernel function"
    degree.config_path = "config.algorithm.configuration.degree"
    degree.validate()
    x_config.append(degree.as_json())

    # gamma is not implemented as type is float, but default value is 'auto'

    coef0 = configuration.NumericConfiguration()
    coef0.data_type = configuration.DataType.FLOAT.value
    coef0.description = "Independent term in kernel function"
    coef0.name = "coef0"
    coef0.min_value = 0
    coef0.max_value = 100
    coef0.value = 0.0
    coef0.config_path = "config.algorithm.configuration.coef0"
    coef0.validate()
    x_config.append(coef0.as_json())

    shrinking = configuration.BooleanConfiguration()
    shrinking.data_type = configuration.DataType.BOOLEAN.value
    shrinking.description = "Whether to use shrinking heuristic"
    shrinking.name = "shrinking"
    shrinking.options = [True, False]
    shrinking.value = True
    shrinking.config_path = "config.algorithm.configuration.shrinking"
    shrinking.op_type = configuration.OpType.CATEGORICAL.value
    shrinking.validate()
    x_config.append(shrinking.as_json())

    tol = configuration.NumericConfiguration()
    tol.data_type = configuration.DataType.FLOAT.value
    tol.description = "Tolerance for stopping criterion"
    tol.name = "tol"
    tol.min_value = 0
    tol.max_value = 100
    tol.value = 0.001
    tol.config_path = "config.algorithm.configuration.tol"
    tol.validate()
    x_config.append(tol.as_json())

    max_iter = configuration.NumericConfiguration()
    max_iter.data_type = configuration.DataType.INTEGER.value
    max_iter.min_value = -1
    max_iter.max_value = 100
    max_iter.value = -1
    max_iter.name = "max_iter"
    max_iter.description = "Hard limit on iterations within solver"
    max_iter.config_path = "config.algorithm.configuration.max_iter"
    max_iter.validate()
    x_config.append(max_iter.as_json())

    # model specific configurations end here
    ui_index = "sklearn.regression.SVR"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


def register_task(solution_id=None, task_det=None):
    name = "SKL SVR Regressor"
    config = {
        "algorithm": {
            "auto_tuner": {
                "name": "grid_search",
                "configuration": {
                }
            },
            "configuration": {
            },
            "class": "sklearn.svm.SVR"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.regression_algo_skl_model_runner",
        "files": [],
        "model_class": "regression"
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "SVR Regressor"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
