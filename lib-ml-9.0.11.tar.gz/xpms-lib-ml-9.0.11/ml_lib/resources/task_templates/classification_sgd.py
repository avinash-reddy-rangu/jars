from ml_lib.utils import create_task
from xpms_objects.models import configuration


# NOte: avoided model.id

def generate_extras():
    # setting up configurations
    x_config = []
    scorers = configuration.CategoricalListConfiguration()
    scorers.name = "scorers"
    scorers.description = "evaluation_metrics"
    scorers.options = ["accuracy"]
    scorers.data_type = configuration.DataType.STRING.value
    scorers.config_path = "config.scorers"
    scorers.validate()
    x_config.append(scorers.as_json())

    target = configuration.StringConfiguration()
    target.name = "target"
    target.description = "target column"
    target.value = "target"
    target.data_type = configuration.DataType.STRING.value
    target.config_path = "config.target"
    target.validate()
    x_config.append(target.as_json())

    link_task = configuration.PlatformApiListConfiguration()
    link_task.name = "task reference"
    link_task.is_option_object = True
    link_task.value = "none"
    link_task.config_path = "config.task_reference"
    link_task.description = "link a pre_existing task in the model"
    link_task.api = "ml/task/list_instances"
    link_task.options = "result.metadata.tasks"
    link_task.value_key = "instance_id"
    link_task.display_key = "name"
    link_task.trigger = "list_ml_task_instances"
    link_task.custom_request_data = ["model.model_id", "model.version_id", "task.task_id"]
    link_task.request_data = {
        "model": {"model_id": "", "version_id": ""},
        "task": {"task_id": ""}
    }
    link_task.validate()
    x_config.append(link_task.as_json())

    loss = configuration.CategoricalListConfiguration()
    loss.data_type = configuration.DataType.STRING.value
    loss.description = "Specifies the kernel type to be used in the algorithm."
    loss.name = "loss"
    loss.options = ["log", "hinge", "modified_huber", "squared_hinge", "perceptron"]
    loss.value = "log"
    loss.config_path = "config.algorithm.configuration.loss"
    loss.validate()
    x_config.append(loss.as_json())

    multi_model = configuration.CategoricalListConfiguration()
    multi_model.name = "multi_model"
    multi_model.description = "to create model for each class"
    multi_model.data_type = configuration.DataType.BOOLEAN.value
    multi_model.value = False
    multi_model.options = [True, False]
    multi_model.config_path = "config.multi_model"
    multi_model.validate()
    x_config.append(multi_model.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.classification.SGDClassifier"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


# default config


def register_task(solution_id=None, task_det=None):
    name = "SKL SGD Classifier"
    config = {
        "algorithm": {

            "auto_tuner": {"name": "grid_search"},
            "class": "sklearn.linear_model.SGDClassifier"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.classification_algo_skl_model_runner",
        "files": [],
        "model_class": "classification"
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "Linear Model SGD Classifier"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)


