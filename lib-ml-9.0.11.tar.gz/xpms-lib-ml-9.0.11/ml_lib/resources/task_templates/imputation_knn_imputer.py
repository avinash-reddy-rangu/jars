from ml_lib.utils import create_task
from xpms_objects.models import configuration


# NOte: avoided model.id

def generate_extras():
    # setting up configurations
    x_config = []

    missing_value_dt = configuration.CategoricalListConfiguration()
    missing_value_dt.data_type = configuration.DataType.STRING.value
    missing_value_dt.name = "missing_values"
    missing_value_dt.description = "The placeholder for missing values type"
    missing_value_dt.value = "nan"
    missing_value_dt.options = ["int", "nan"]
    missing_value_dt.config_path = "config.algorithm.configuration.missing_value_dt"
    missing_value_dt.validate()
    x_config.append(missing_value_dt.as_json())

    # supporting only for Numeric Data, need to add support for strings
    missing_values = configuration.StringConfiguration()
    missing_values.data_type = configuration.DataType.STRING.value
    missing_values.name = "values to replace"
    missing_values.description = "The placeholder for missing values. All occurrences of missing_values will be imputed"
    missing_values.value = "nan"
    missing_values.config_path = "config.algorithm.configuration.missing_values"
    missing_values.validate()
    x_config.append(missing_values.as_json())

    col_name = configuration.StringConfiguration()
    col_name.data_type = configuration.DataType.STRING.value
    col_name.name = "Column Name/s"
    col_name.description = "Column names on which imputation is to be performed"
    col_name.value = "all"
    col_name.multi_select = True
    col_name.config_path = "config.algorithm.configuration.col_name"
    col_name.validate()
    x_config.append(col_name.as_json())

    n_neighbors = configuration.NumericConfiguration()
    n_neighbors.data_type = configuration.DataType.INTEGER.value
    n_neighbors.description = "Number of neighboring samples to use for imputation"
    n_neighbors.name = "n_neighbors"
    n_neighbors.min_value = 0
    n_neighbors.max_value = 100
    n_neighbors.value = 5
    n_neighbors.config_path = "config.algorithm.configuration.n_neighbors"
    n_neighbors.validate()
    x_config.append(n_neighbors.as_json())

    weights = configuration.CategoricalListConfiguration()
    weights.data_type = configuration.DataType.STRING.value
    weights.name = "weights"
    weights.description = "Weight function used in prediction"
    weights.value = "uniform"
    weights.options = ["uniform", "distance"]
    weights.config_path = "config.algorithm.configuration.weights"
    weights.validate()
    x_config.append(weights.as_json())

    metric = configuration.StringConfiguration()
    metric.data_type = configuration.DataType.STRING.value
    metric.name = "metric"
    metric.description = "The Distance metric for searching neighbors"
    metric.value = "nan_euclidean"
    metric.config_path = "config.algorithm.configuration.metric"
    metric.validate()
    x_config.append(metric.as_json())

    dependencies_config = configuration.CategoricalListConfiguration()
    dependencies_config.data_type = configuration.DataType.STRING.value
    dependencies_config.name = "dependencies"
    dependencies_config.description = "dependency on previous tasks to run"
    dependencies_config.value = "any"
    dependencies_config.options = ["any", "all"]
    dependencies_config.config_path = "config.dependencies"
    dependencies_config.validate()
    x_config.append(dependencies_config.as_json())

    ui_index = "sklearn.imputation.KNNImputer"

    # extras property
    extras = {"ui_index": ui_index, "x_config": x_config}
    return extras


def register_task(solution_id=None, task_det=None):
    name = "SKL KNN Imputer"
    config = {
        "algorithm": {

            "auto_tuner": {"name": "grid_search"},
            "class": "sklearn.impute.KNNImputer"
        },
        "source_type": "lib",
        "source": "ml_lib.resources.task_scripts.dataset_knn_imputer",
        "files": []
    }

    extras = generate_extras()
    task_dict = dict(name=name)
    if task_det is not None:
        for task in task_det:
            if task == name:
                task_dict["task_id"] = task_det[task]
                break
    task_dict["category"] = "ml"
    task_dict["created_by"] = "system"
    task_dict["modified_by"] = "system"
    task_dict["solution_id"] = solution_id if solution_id is not None else "system"
    task_dict["extras"] = extras
    task_dict["task_class"] = "ml_lib.model.dag_tasks.ml_task.MLTask"
    task_dict["config"] = config
    task_dict["description"] = "SKL KNN Imputer"
    task_dict["compatible_groups"] = ["default_dependency_package_group"]
    create_task(task_dict)
