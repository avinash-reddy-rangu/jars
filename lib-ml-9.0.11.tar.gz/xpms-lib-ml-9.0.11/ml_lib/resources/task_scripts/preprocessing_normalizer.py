from sklearn.preprocessing import Normalizer
from pandas.api.types import is_string_dtype


def run(dataset_dict: dict, config, caching=False):
    try:
        task_config = config["algorithm"]["configuration"]
    except Exception:
        raise Exception("configuration not found")
    task_data = list(dataset_dict.values())[0]
    if task_config["col_name"] == ["all"]:
        numeric_columns = [col for col in list(task_data['value'].columns) if
                           not is_string_dtype(task_data['value'][col])]
    else:
        numeric_columns = [col.strip() for col in task_config['col_name']]

    imp = Normalizer(norm=task_config['norm'], copy=task_config['copy'])

    for column in numeric_columns:
        if is_string_dtype(task_data['value'][column]):
            raise Exception("Scaling/Standardisation is to be done for only numeric columns")
        task_data['value'][column] = imp.fit_transform(task_data['value'][[column]])
    return task_data
