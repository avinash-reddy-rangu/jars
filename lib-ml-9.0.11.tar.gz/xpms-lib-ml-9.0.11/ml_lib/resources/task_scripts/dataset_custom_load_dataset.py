from ml_lib.model.data_schema import DatasetFormat, DatasetConvertor


def run(datasets, config,caching=False):
    convert_to = DatasetFormat.DATA_FRAME.value
    if "data_schema" not in config:
        data_schema = None
    else:
        data_schema = config["data_schema"]
    dataset = next(iter(datasets.values()))
    new_dataset = DatasetConvertor.convert(dataset, DatasetFormat(convert_to), data_schema)
    return new_dataset
