from sklearn.impute import KNNImputer
import numpy as np
from pandas.api.types import is_string_dtype


def run(dataset_dict: dict, config, caching=False):
    try:
        task_config = config["algorithm"]["configuration"]
    except Exception:
        raise Exception("configuration not found")
    task_data = list(dataset_dict.values())[0]
    if task_config['missing_values'] == "nan":
        task_config['missing_values'] = np.nan
    elif "missing_value_dt" in task_config and task_config['missing_value_dt']=="int":
        task_config['missing_values'] = int(task_config['missing_values'])
    if task_config["col_name"] == ["all"]:
        columns = [col for col in list(task_data['value'].columns) if not is_string_dtype(task_data['value'][col])]
    else:
        columns = [col.strip() for col in task_config['col_name']]
    if any(col for col in columns if is_string_dtype(task_data['value'][col])):
        raise Exception("Knn imputation can only be used for numeric columns")
    imp = KNNImputer(missing_values=task_config['missing_values'],n_neighbors=task_config['n_neighbors'],weights=task_config['weights'],
                     metric=task_config['metric'])
    for col in columns:
        task_data['value'][col] = imp.fit_transform(task_data['value'][[col]])
    return task_data
