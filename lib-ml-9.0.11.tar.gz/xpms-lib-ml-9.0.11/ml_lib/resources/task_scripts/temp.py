from datetime import datetime

import sys
val = "mayan 'a'"
class ml_task:

    def __init__(self, src):
        self.src = src
    def load_module(self):
        # spec = importlib.util.spec_from_file_location(full_path, full_path)
        # python_task = importlib.util.module_from_spec(spec)
        # spec.loader.exec_module(python_task)
        # return  python_task
        src = self.src
        tmp_path = src.split('.')
        op_str = tmp_path.pop()
        import_str = '.'.join(tmp_path)
        exec('from {} import {}'.format(import_str, op_str))
        python_task = eval(op_str)
        return python_task

    def unload_execution_script(self):
        source = self.src
        sys.modules.pop(source, None)

    def run(self):
        a = self.load_module()
        a.run(False)
        self.unload_execution_script()
