from copy import deepcopy


def run(dataset_dict: dict, config,caching=False):
    result_df = None
    task_data = list(dataset_dict.values())
    for dataset in task_data:
        if result_df is None:
            result_df = deepcopy(dataset["value"])
        else:
            result_df = result_df + dataset["value"]
    new_dataset = {"value": result_df, "data_format": "data_frame"}
    return new_dataset
