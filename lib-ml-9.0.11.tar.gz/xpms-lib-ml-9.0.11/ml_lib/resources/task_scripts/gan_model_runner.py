import pandas as pd
from xpms_helper.model import model_utils
from keras.preprocessing.image import img_to_array
import tensorflow as tf
from keras.preprocessing.image import save_img, load_img
from uuid import uuid4
from xpms_file_storage.file_handler import XpmsResource, LocalResource
from xpms_helper.model import dataset_utils
from xpms_helper.lru_cache import lru_cache, GRANDE_CACHE_SIZE
import gc
from ml_lib.log_memory import log_memory
from multiprocessing import Process, Queue
import traceback
from xpms_common.errors import InternalError

import os
import psutil

process = psutil.Process(os.getpid())

def train(datasets, config):
    train_info = {}
    result_dataset = {"value": pd.DataFrame(), "data_format": "data_frame", "target_column": "tables",
                      "predicted_classes": ""}
    return train_info, result_dataset


def run(datasets, config,caching=False):

    def run_model(datasets,config,output,caching=False):
        try:
            file_ext = config["binary"]["model_file"].split(".")[-1]
            if file_ext == ".h5":
                save_option = "h5_to_pb"
            elif file_ext == "pb":
                save_option = "pb"
            else:
                raise Exception("unspported model resource for GAN model")
            log_memory("step 3 entered gan script")
            sess = get_session(caching=caching)
            log_memory("step 4 created tf session")
            load_model_graph(config, save_option, caching=caching)
            log_memory("step 6 loaded tf graph")
            predicted_images = []
            images_df = dataset_utils.load_dataset(config, datasets, "x")
            if len(images_df.columns.tolist()) > 1:
                raise Exception("multiple input folders/columns given")
            elif not images_df.columns.tolist():
                raise Exception("No data found to run the model")
            images_list = images_df[images_df.columns.tolist()[0]].tolist()

            log_memory("step 7 selecting model graph")
            softmax_tensor = sess.graph.get_tensor_by_name('import/activation_10/Tanh:0')

            log_memory("step 8 selected model graph")
            for image in images_list:
                file_name = XpmsResource.get(urn=image).filename
                image_nd_array = preprocess_image(image)
                log_memory("step 9 selected loaded table image")
                gen_image = sess.run(softmax_tensor, {'import/input_3:0': image_nd_array})

                log_memory("step 11 ran gan model")
                gen_image = gen_image.reshape(512, 1024, 3) * 255
                filepath = convert_to_image(config, gen_image, "{0}_{1}".format(str(uuid4()), file_name))
                predicted_images.append(filepath)
                log_memory("step 12 ran post processing of image")
            result_df = pd.DataFrame(data=predicted_images, columns=['output'])
            result_dataset = {"value": result_df, "data_format": "data_frame"}
            output.put(result_dataset)
        except Exception as e:
            output.put(str(e))
            output.put(traceback.format_exc())

    if caching:
        result_dataset = run_model(datasets, config, caching)
    else:
        output = Queue()
        p = Process(target=run_model, args=(datasets, config, output, caching))
        p.start()
        p.join()
        del p
        result_dataset = output.get()
        if not isinstance(result_dataset,dict):
            e = InternalError(error_message=result_dataset,traceback=output.get())
            gc.collect()
            raise e
    gc.collect()
    return result_dataset, None


def evaluate(datasets, config,caching=False):
   raise Exception("Evaluation is Not Implemented")


def convert_to_image(config, image_nd_array, file_name):
    local_path = "predicted_images/{0}".format(file_name)
    local_res = LocalResource(key=local_path)
    if not local_res.exists():
        local_res.mkdir(parent=True)
    save_img(local_path, image_nd_array)
    remote_path = "{0}/predicted_tables/{1}".format(config['output_dir'], file_name)
    remote_res = XpmsResource.get(key=remote_path)
    local_res.copy(remote_res)
    local_res.delete()
    return remote_res.urn


def preprocess_image(image_path):
    remote_res = XpmsResource.get(urn=image_path)
    local_res = LocalResource(key="tmp/{0}.{1}".format(str(uuid4()), remote_res.extension))
    remote_res.copy(local_res)
    img = load_img(path=local_res.fullpath, target_size=(512, 1024))
    img_arry = img_to_array(img)
    resized_img_arry = img_arry.reshape(1, 512, 1024, 3)
    normalized_img = (resized_img_arry - 127.5) / 127.5
    local_res.delete()
    return normalized_img

@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def get_session(caching= False):
    sess = tf.compat.v1.InteractiveSession()
    sess.graph.as_default()
    return sess

@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_graph(graph_def, caching_key=None,caching=False):
    tf.import_graph_def(graph_def)

def load_model_graph(config, save_option, caching=False ):
    graph_def = model_utils.load(file_name=None, config=config, save_option=save_option,
                                 filepath=config["binary"]["model_file"], caching=caching)

    log_memory("step 5 read model from file")
    load_graph(graph_def=graph_def, caching_key=config["binary"]["model_file"], caching=caching)




# images = []
# paths= ["/home/revanth/Downloads/table1.png", "/home/revanth/Downloads/table3-1 (2).png", "/home/revanth/Downloads/table_1_1 (3).png"]
# for path in paths:
#     img = load_img(path=path,target_size=(512, 1024))
#     img_ary = img_to_array(img)
#     normalized_img = (img_ary - 127.5) / 127.5
#     images.append([normalized_img])
# config={"model_file":{"file_path":""}}
# config['src_dir']= "/home/revanth/test_img"
# config["model_file"]["filepath"] = "/home/revanth/Projects/enso-image/col_gan_train_model/tf_model_903_1600.pb"
# dataset = {"key": images}
# # run(datasets=dataset, config=config)
#
# convert_to_ndarray(paths)