def run(dataset_dict: dict, config,caching=False):
    import pandas as pd
    from copy import deepcopy
    result_df = pd.DataFrame()
    try:
        func_config = config["func"]["configuration"]
    except Exception:
        func_config = {}

    for key, x in dataset_dict.items():
        x_df = x["value"]
        if func_config.get("generate_suffix", False):
            x_df.columns = ["{}_{}".format(key, col) for col in x_df.columns]
        result_df = result_df.join(x_df, how="outer")

    task_output = deepcopy(dataset_dict[list(dataset_dict.keys())[0]])
    task_output["value"] = result_df
    return task_output
