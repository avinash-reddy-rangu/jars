from sklearn.impute import SimpleImputer
import numpy as np
from pandas.api.types import is_string_dtype


def run(dataset_dict: dict, config, caching=False):
    try:
        task_config = config["algorithm"]["configuration"]
    except Exception:
        raise Exception("configuration not found")
    strategy = task_config["strategy"]
    task_data = list(dataset_dict.values())[0]
    if task_config["col_name"] == ["all"]:
        columns = [col for col in list(task_data['value'].columns)]
    else:
        columns = [col.strip() for col in task_config['col_name']]
    if task_config['missing_values'] == "nan":
        task_config['missing_values'] = np.nan
    if strategy == "constant":
        if task_config['col_dt'] == "string":
            fill_value = str(task_config['fill_value'])
        elif task_config['col_dt'] == "int":
            fill_value = int(task_config['fill_value'])
        else:
            fill_value = float(task_config['fill_value'])
        imp = SimpleImputer(missing_values=task_config['missing_values'],strategy=strategy,fill_value=fill_value)
        for col in columns:
            task_data['value'][col] = imp.fit_transform(task_data['value'][[col]])
    else:
        if strategy in ['mean','median'] and any(col for col in columns if is_string_dtype(task_data['value'][col])):
            raise Exception("only numeric columns can use {} strategy".format(strategy))
        imp = SimpleImputer(missing_values=task_config['missing_values'],strategy=strategy)
        for col in columns:
            task_data['value'][col] = imp.fit_transform(task_data['value'][[col]])
    return task_data
