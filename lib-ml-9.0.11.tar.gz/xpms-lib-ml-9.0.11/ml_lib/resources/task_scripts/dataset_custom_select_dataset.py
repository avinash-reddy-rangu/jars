def run(dataset_dict: dict, config,caching=False):
    import json
    from xpms_common.errors import InvalidUsageError

    task_dataset = list(dataset_dict.values())[0]
    try:
        bucket = int(config["func"]["configuration"]["bucket"])
        return task_dataset[bucket]
    except KeyError:
        raise InvalidUsageError("Invalid configuration provided. %s" %
                                json.dumps(config["func"]["configuration"]))
