import pandas as pd
from xpms_helper.model import dataset_utils, model_utils
from xpms_helper.model.model_utils import calculate_metrics


def train(datasets, config):
    train_info = {}
    result_dataset = {"value": pd.DataFrame(), "data_format": "data_frame", "target_column": config['target'],
                      "predicted_classes": ""}
    return train_info, result_dataset


def run(datasets, config,caching=False):
    x = dataset_utils.load_dataset(config, datasets, "x")
    model_obj = model_utils.load(file_name=None, config=config, save_option="h5",
                                 filepath=config["binary"]["model_file"], caching=caching)
    result = model_obj.predict(x)
    result_df = pd.DataFrame(data=result)
    result_dataset = {"value": result_df, "data_format": "data_frame"}
    data = list(datasets.values())[0]['value']
    if isinstance(x, pd.DataFrame):
        run_info = {"dataval": x[0:50].values.tolist(), "datacol": x[0:50].columns.tolist(), "rec": data.shape[0],
                    "col": data.shape[1], "dep_var": config["target"]}
        return result_dataset, run_info
    return result_dataset, None


def evaluate(datasets, config,caching=False):
    y = dataset_utils.load_dataset(config, datasets, "y")
    x = dataset_utils.load_dataset(config, datasets, "x")
    model_obj = model_utils.load(file_name=None, config=config, save_option="h5",
                                 filepath=config["binary"]["filepath"], caching=caching)
    result = model_obj.predict_classes(x)
    result_df = pd.DataFrame(data=result, columns=[config['target']])
    result_dataset = {"value": result_df, "data_format": "data_frame"}
    y_pred = result_dataset['value'][config['target']].tolist()
    scorers = config["scorers"]
    data = list(datasets.values())[0]['value']
    if isinstance(x, pd.DataFrame):
        run_info = {"dataval": x[0:50].values.tolist(), "datacol": x[0:50].columns.tolist(), "rec": data.shape[0],
                    "col": data.shape[1], "dep_var": config["target"]}
    else:
        run_info = None
    metrics = calculate_metrics(data, scorers, y, y_pred, config)
    return metrics, result_dataset, run_info
