from copy import copy


def run(dataset_dict: dict, config, caching=False):
    task_data = list(dataset_dict.values())[0]
    task_dataset = task_data["value"].copy()
    try:
        columns = config["func"]["configuration"]["columns"]
        optional_columns = config["func"]["configuration"]["optional_columns"]
        filter_columns = copy(columns)
        for column in task_dataset.columns.tolist():
            if column in optional_columns:
                filter_columns.append(column)

    except Exception:
        filter_columns = []
    output_data = {"value": task_dataset[filter_columns], "data_format": "data_frame"}
    return output_data