from sklearn.preprocessing import RobustScaler
from pandas.api.types import is_string_dtype


def run(dataset_dict: dict, config, caching=False):
    try:
        task_config = config["algorithm"]["configuration"]
    except Exception:
        raise Exception("configuration not found")
    task_data = list(dataset_dict.values())[0]
    quantile_range_max = task_config['quantile_range_max']
    quantile_range_min = task_config['quantile_range_min']
    if quantile_range_max < quantile_range_min:
        raise Exception("min value in feature range should be less than max value")
    quantile_range = (quantile_range_min,quantile_range_max)
    scalar = RobustScaler(with_centering=task_config['with_centering'],with_scaling=task_config['with_scaling'],quantile_range=quantile_range,copy=task_config['copy'])
    if task_config["col_name"] == ["all"]:
        numeric_columns = [col for col in list(task_data['value'].columns) if not is_string_dtype(task_data['value'][col])]
    else:
        numeric_columns = [col.strip() for col in task_config['col_name']]
    for column in numeric_columns:
        if is_string_dtype(task_data['value'][column]):
            raise Exception("Scaling/Standardisation is to be done for only numeric columns")
        task_data['value'][column] = scalar.fit_transform(task_data['value'][[column]])

    return task_data
