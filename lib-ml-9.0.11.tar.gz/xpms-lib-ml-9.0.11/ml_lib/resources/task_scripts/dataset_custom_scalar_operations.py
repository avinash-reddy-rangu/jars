import pandas as pd

def run(dataset_dict: dict, config,caching=False):
    try:
        func_config = config["func"]["configuration"]
    except Exception:
        raise Exception("configuration not found")

    task_data = list(dataset_dict.values())[0]
    non_numeric_columns = task_data['value'].select_dtypes(exclude=['int','float'])
    numeric_columns = task_data['value'].select_dtypes(include=['int','float'])
    if func_config["operation"] == "multiply":
        numeric_columns = numeric_columns * float(func_config["scalar_value"])
    if func_config["operation"] == "divide":
        numeric_columns = numeric_columns / float(func_config["scalar_value"])
    task_data['value'] = pd.concat([numeric_columns,non_numeric_columns],axis=1)
    return task_data
