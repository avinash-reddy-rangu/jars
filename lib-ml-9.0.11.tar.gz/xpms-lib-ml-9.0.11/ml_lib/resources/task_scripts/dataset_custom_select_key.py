def run(dataset_dict: dict, config,caching=False):
    import json
    from xpms_common.errors import InvalidUsageError

    task_dataset = list(dataset_dict.values())[0]
    try:
        key = config["func"]["configuration"]["key"]
        return task_dataset[key]
    except KeyError:
        raise InvalidUsageError("Invalid configuration provided. %s" %
                                json.dumps(config["func"]["configuration"]))
