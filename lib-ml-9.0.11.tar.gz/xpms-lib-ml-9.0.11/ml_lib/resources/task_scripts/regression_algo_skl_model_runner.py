from copy import copy
from pydoc import locate

import pandas as pd

from xpms_helper.model.train_info import TrainInfo
from xpms_helper.model.model_utils import calculate_metrics
from xpms_helper.model import dataset_utils, model_utils


def run(datasets, config,caching=False):
    x = dataset_utils.load_dataset(config, datasets, "x")
    file_name = "{0}.pkl".format("model")
    model_obj = model_utils.load(file_name=file_name, config=config, caching=caching)
    result = model_obj.predict(x)
    result_df = pd.DataFrame(data=result, columns=[config['target']])
    result_dataset = {"value": result_df, "data_format": "data_frame"}
    data = list(datasets.values())[0]['value']
    final_df = x.join(result_df)
    if isinstance(x, pd.DataFrame):
        run_info = {"dataval": final_df[0:50].values.tolist(), "datacol": final_df[0:50].columns.tolist(),
                    "rec": data.shape[0], "col": data.shape[1], "dep_var": config["target"]}
        return result_dataset, run_info
    else:
        return result_dataset, None


def initialize_algorithm(config):
    algorithm = locate(config["algorithm"]["class"])
    try:
        algorithm_config_params = config["algorithm"]["configuration"]
    except:
        algorithm_config_params = dict()
    # this comes here
    if "auto_tune" in config["algorithm"] and not config["algorithm"]["auto_tune"]:
        from sklearn.model_selection import KFold
        from sklearn.model_selection import GridSearchCV

        # cv = config["algorithm"]["auto_tuner"]["cv"]
        cv = 5
        scorer = config["algorithm"]["auto_tuner"]["scorer"]
        if config["algorithm"]["auto_tuner"]["name"] != "grid_search":
            raise Exception("mentioned auto_tuner not found")
        params = copy(config["algorithm"]["auto_tuner"]["configuration"])

        if "predict" not in dir(algorithm):
            raise Exception("Selected regression model is not supported")
        else:
            algorithm = algorithm()

        folds = KFold(n_splits=cv)
        # train using gridsearch
        clf = GridSearchCV(algorithm, params, cv=folds,
                           scoring=scorer, error_score=-1.0)
    else:
        if "predict" not in dir(algorithm):
            raise Exception("Selected regression model is not supported")
        else:
            clf = algorithm(**algorithm_config_params)

    return clf


def train(datasets, config):
    x = dataset_utils.load_dataset(config, datasets, "x")
    y = dataset_utils.load_dataset(config, datasets, "y")
    clf = initialize_algorithm(config)

    model_obj = clf.fit(x, y)
    file_name = "{}.pkl".format("model")
    model_utils.save(file_name=file_name, obj=model_obj, config=config)
    data = list(datasets.values())[0]['value']
    classes = data.columns.tolist()
    classes.remove(config["target"])

    if "auto_tune" in config["algorithm"] and not config["algorithm"]["auto_tune"]:
        params = model_obj.best_params_
    else:
        params = model_obj.get_params()

    if getattr(clf, "feature_importances_", None) is not None:
        feature_importance = clf.feature_importances_.tolist()
    elif getattr(clf, "coef_", None) is not None:
        feature_importance = clf.coef_.tolist()
    else:
        feature_importance = None

    train_info = TrainInfo(
        **{"name": "", "path": config["src_dir"], "params": params, "classes": classes,
           "feature_imp": feature_importance, "rec": data.shape[0], "col": data.shape[1],
           "dep_var": config["target"]}).as_json()
    config["algorithm"]["path"] = config["src_dir"]
    predictions = model_obj.predict(x)
    result_df = pd.DataFrame(data=predictions, columns=[config['target']])
    result_dataset = {"value": result_df, "data_format": "data_frame"}
    return train_info, result_dataset


def evaluate(datasets, config,caching=False):
    y = dataset_utils.load_dataset(config, datasets, "y")
    model_output, run_info = run(datasets, config, caching=caching)
    y_pred = model_output['value'][config['target']].tolist()
    scorers = config["scorers"]
    # todo model output isnt of correct shape
    data = list(datasets.values())[0]['value']
    metrics = calculate_metrics(data, scorers, y, y_pred, config)
    return metrics, model_output, run_info
