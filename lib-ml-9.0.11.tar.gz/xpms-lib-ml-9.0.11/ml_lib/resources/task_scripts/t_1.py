import pandas as pd
from xpms_helper.model import model_utils
from keras.preprocessing.image import img_to_array
import tensorflow as tf
from keras.preprocessing.image import save_img, load_img
from uuid import uuid4
from xpms_file_storage.file_handler import XpmsResource, LocalResource
from xpms_helper.model import dataset_utils
from datetime import datetime
from xpms_helper.lru_cache import lru_cache, GRANDE_CACHE_SIZE
import gc
from tensorflow.python.platform import gfile
from multiprocessing import Process

import os
import psutil

image_path = "/Users/mayank/Desktop/table-1result.jpg"

from keras.models import save_model, load_model
import os
import psutil

process = psutil.Process(os.getpid())
from keras.backend.tensorflow_backend import set_session
from keras.backend.tensorflow_backend import clear_session
from keras.backend.tensorflow_backend import get_session
import tensorflow

# Reset Keras Session
def reset_keras():
    sess = get_session()
    clear_session()
    sess.close()
    gc.collect()

def print_memory_and_ts(process_name, previous_ts= None):
    time_stamp = datetime.utcnow()
    if previous_ts:
        print(time_stamp)
        print("time_taken : "+ str((time_stamp - previous_ts).microseconds))
    print("memory {0} : ".format(process_name) + str(process.memory_info().rss / 1000000))
    return time_stamp


def run_model():
    def f(name):
        print('hello', name)

    if __name__ == '__main__':
        p = Process(target=f, args=('bob',))
        p.start()
        p.join()

def run(caching=True):
    def f():
        filepath = "/Users/mayank/Desktop/903_col_model_001600.h5"
        # filepath = "/Users/mayank/Desktop/model_gan"
        save_option = "pb"
        print_memory_and_ts("method start")
        # ts = print_memory_and_ts("before model load", datetime.utcnow())
        # sess = get_session(caching=caching)

        graph_def = load_model_graph(filepath, save_option, caching=caching)

    if not caching:
        p = Process(target=f, args=())
        p.start()
        p.join()
        del p

    else:
        f()

        # del softmax_tensor
    gc.collect()

    print_memory_and_ts("deleted memory")

    return None



@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def get_session(caching= True):
    sess = tf.compat.v1.InteractiveSession()
    sess.graph.as_default()
    return sess

@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_graph(graph_def, caching_key = None, caching=True):
    tf.import_graph_def(graph_def)
    return 1

# @lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_model_graph(filepath, save_option, caching=True):
    graph_def = load(file_name=None, save_option=save_option,
                                 filepath=filepath, caching=caching)

    # load_graph(graph_def= graph_def, caching_key="load_gan_graph",caching=caching)
    return graph_def




def load(file_name, save_option="pkl", filepath=None, caching=True):
    """
        This function is for loading scikit and tensorflow model resources
        supported resource types are .pkl and .hd5.
    :param file_name: Name of the file - type <string>
    :param config :  Configuration - type <dict>
    :param save_option: File type - type <string>
    :return: file content  - type <string>
    """
    return load_h5_local(filepath, caching=caching)


@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_h5_local(file_path,caching=False):
    print_memory_and_ts("before load start")
    model_file = LocalResource(key=file_path)
    model = load_model(model_file.fullpath)

    print_memory_and_ts("after load ")
    del model
    del model_file
    gc.collect()
    print_memory_and_ts("after delete ")
    return None

@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_pb(filepath, caching=True):
    local_r = LocalResource(key=filepath)
    model = load_model(local_r.fullpath)
    save_model(model,"mymodel.h5")
    # local_r = LocalResource(key=filepath)
    # f = gfile.FastGFile(local_r.fullpath, 'rb')
    # graph_def = tf.compat.v1.GraphDef()
    # graph_def.ParseFromString(f.read())
    # f.close()
    # del f
    # graph_def.save("mymodel.h5")
    return None


@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_pb_model(filepath, caching=True):
    local_r = LocalResource(key=filepath)
    graph_def = tf.saved_model.load(local_r.fullpath)
    # graph_def.save(local_r.fullpath+"_new.h5" )
    # tf.saved_model.save(graph_def, export_dir =local_r.fullpath+"_new",)
    save_model(graph_def, filepath=local_r.fullpath+"_new.h5")
    # graph_def.save(local_r.fullpath+"_new")
    return graph_def

def preprocess_image(image_path):
    img = load_img(path=image_path, target_size=(512, 1024))
    img_arry = img_to_array(img)
    resized_img_arry = img_arry.reshape(1, 512, 1024, 3)
    normalized_img = (resized_img_arry - 127.5) / 127.5
    return normalized_img
