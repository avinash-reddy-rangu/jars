def run(config, datasets,caching=False):
    weights = config["func"]["configuration"]["weights"]
    result_df = None
    for key in datasets:
        df = datasets[key]["value"] * weights[key]
        if result_df is None:
            result_df = df
        else:
            result_df += df
    total_weight = 0
    for k in weights:
        total_weight += weights[k]
    result_df /= total_weight
    new_dataset = {"value": result_df, "data_format": "data_frame"}
    return new_dataset
