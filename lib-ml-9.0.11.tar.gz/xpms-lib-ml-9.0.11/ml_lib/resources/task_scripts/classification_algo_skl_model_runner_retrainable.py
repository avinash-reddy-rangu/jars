from copy import copy
from pydoc import locate
import json
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV

from xpms_helper.model.train_info import TrainInfo
from xpms_helper.model.model_utils import calculate_metrics
from xpms_helper.model import dataset_utils, model_utils


# on shuffle
# You need to shuffle the training data between each iteration, as setting shuffle=True when instantiating the model will NOT shuffle the data when using partial_fit (it only applies to fit)

# on size of batch
# This method has some performance overhead hence it is better to call partial_fit on chunks of data that are as large as possible (as long as fitting in the memory budget) to hide the overhead.

# algorithms
# Multinomial nb
# BernoulliNB
# GaussianNB
# SGDClassifier
#


def run(datasets, config,caching=False):
    x = dataset_utils.load_dataset(config, datasets, "x")
    file_name = "{0}.pkl".format("model")
    model_obj = model_utils.load(file_name=file_name, config=config,caching=caching)
    result = model_obj.predict_proba(x)
    result_df = pd.DataFrame(data=result, columns=model_obj.classes_)
    full_dataset = dataset_utils.update_dataset(datasets, result_df,config)
    result_dataset = {"value": full_dataset, "data_format": "data_frame","target_column":config['target'],"predicted_classes": json.dumps(model_obj.classes_.tolist())}
    data = list(datasets.values())[0]['value']
    if isinstance(x, pd.DataFrame):
        run_info = {"dataval": x[0:50].values.tolist(), "datacol": x[0:50].columns.tolist(), "rec": data.shape[0],
                    "col": data.shape[1], "dep_var": config["target"]}
        return result_dataset, run_info
    else:
        return result_dataset, None


def initialize_algorithm(config):
    algorithm = locate(config["algorithm"]["class"])
    try:
        algorithm_config_params = config["algorithm"]["configuration"]
    except:
        algorithm_config_params = dict()
    # this comes here
    if "auto_tune" in config["algorithm"] and not config["algorithm"]["auto_tune"]:
        from sklearn.model_selection import KFold
        from sklearn.model_selection import GridSearchCV

        # cv = config["algorithm"]["auto_tuner"]["cv"]
        cv = 5
        scorer = config["algorithm"]["auto_tuner"]["scorer"]
        if config["algorithm"]["auto_tuner"]["name"] != "grid_search":
            raise Exception("mentioned auto_tuner not found")
        params = copy(config["algorithm"]["auto_tuner"]["configuration"])

        if "predict_proba" not in dir(algorithm):
            algorithm = CalibratedClassifierCV(algorithm(), cv=3)
        else:
            algorithm = algorithm()

        folds = KFold(n_splits=cv)
        # train using gridsearch
        clf = GridSearchCV(algorithm, params, cv=folds,
                           scoring=scorer, error_score=-1.0)
    else:
        if "predict_proba" not in dir(algorithm):
            clf = CalibratedClassifierCV(algorithm(), **algorithm_config_params, cv=3)
        else:
            clf = algorithm(**algorithm_config_params)

    return clf


def train(datasets, config):
    x = dataset_utils.load_dataset(config, datasets, "x")
    y = dataset_utils.load_dataset(config, datasets, "y")
    clf = initialize_algorithm(config)

    model_obj = clf.fit(x, y)
    file_name = "{}.pkl".format("model")
    model_utils.save(file_name=file_name, obj=model_obj, config=config)

    if "auto_tune" in config["algorithm"] and not config["algorithm"]["auto_tune"]:
        params = model_obj.best_params_
    else:
        params = model_obj.get_params()
    data = list(datasets.values())[0]['value']
    # to be checked which models do not have feature_importance and implemented
    # if config['algorithm']['class'].split(".")[2] not in [""]:
    #     if clf.feature_importances_ is not None:
    #         feature_importance = clf.feature_importances_
    #     elif clf.coef_ is not None:
    #         feature_importance = clf.coef_
    #     else:
    #         feature_importance = None
    # else:
    #     feature_importance = None
    # add feature_importance to train_info
    train_info = TrainInfo(
        **{"name": "", "path": config["src_dir"], "params": params, "classes": model_obj.classes_.tolist(), "rec": data.shape[0], "col": data.shape[1],
           "dep_var": config["target"]}).as_json()
    config["algorithm"]["path"] = config["src_dir"]
    predictions = model_obj.predict_proba(x)
    result_df = pd.DataFrame(data=predictions, columns=model_obj.classes_)
    full_dataset = dataset_utils.update_dataset(datasets, result_df)
    result_dataset = {"value": full_dataset, "data_format": "data_frame","target_column":config['target'],"predicted_classes": json.dumps(model_obj.classes_.tolist())}
    return train_info, result_dataset


def evaluate(datasets, config,caching=False):
    y = dataset_utils.load_dataset(config, datasets, "y")
    model_output, run_info = run(datasets, config,caching=caching)
    # get prediction columns
    dataset_df = dataset_utils.load_predictions(datasets, model_output["value"])
    y_pred = dataset_df.idxmax(axis=1).values
    scorers = config["scorers"]
    # todo model output is not of correct shape
    data = list(datasets.values())[0]['value']
    metrics = calculate_metrics(data, scorers, y, y_pred, config)
    return metrics, model_output, run_info


def retrain(datasets, config,caching=False):
    x = dataset_utils.load_dataset(config, datasets, "x")
    y = dataset_utils.load_dataset(config, datasets, "y")
    file_name = "{0}.pkl".format("model")
    model_obj = model_utils.load(file_name=file_name, config=config)
    model_obj.partial_fit(x, y)
    file_name = "{}.pkl".format("model")
    model_utils.save(file_name=file_name, obj=model_obj, config=config)
    params = model_obj.get_params()
    train_info = TrainInfo(
        **{"name": "", "path": config["src_dir"], "params": params, "classes": model_obj.classes_.tolist()}).as_json()
    config["algorithm"]["path"] = config["src_dir"]
    predictions = model_obj.predict_proba(x)
    result_df = pd.DataFrame(data=predictions, columns=model_obj.classes_)
    result_dataset = {"value": result_df, "data_format": "data_frame"}
    return train_info, result_dataset
