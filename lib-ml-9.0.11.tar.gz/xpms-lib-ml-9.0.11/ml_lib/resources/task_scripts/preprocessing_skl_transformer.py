from pydoc import locate
from xpms_helper.model import dataset_utils, model_utils
from xpms_helper.model.train_info import TrainInfo
from copy import deepcopy

def run(datasets, config,caching=False):
    dataset_value = dataset_utils.load_dataset(config, datasets, "dataset")
    dataset = datasets[next(iter(datasets))]
    file_name = "{0}.pkl".format("model")
    model_obj = model_utils.load(file_name=file_name, config=config,caching=caching)
    model_obj = deepcopy(model_obj)
    if dataset["data_format"] == "data_frame":
        transformed_dataset = model_obj.transform( dataset_value["content"].values.tolist())
    elif dataset["data_format"]=="csr":
        transformed_dataset = model_obj.transform(dataset_value)
    else:
        raise Exception("data format {} not supported".format(dataset["data_format"]))
    new_dataset = {"data_format": "csr", "value": transformed_dataset}
    for k in ["labels"]:
        if k in dataset: new_dataset[k] = dataset[k]
    return new_dataset


def train(datasets, config):
    dataset_value = dataset_utils.load_dataset(config, datasets, "dataset")
    dataset = datasets[next(iter(datasets))]
    params = config["algorithm"]["configuration"]
    algorithm = locate(config["algorithm"]["class"])
    if "ngram_range" in params:
        params["ngram_range"] = [2, params["ngram_range"]]
    transformer = algorithm(**params)
    if dataset["data_format"] == "data_frame":
        input_data = dataset_value["content"].values.tolist()
    elif dataset["data_format"]=="csr":
        input_data = dataset_value
    else:
        raise Exception("data format {} not supported".format(dataset["data_format"]))
    transformer.fit(input_data)
    src_dir = config["src_dir"]
    file_name = "{0}.pkl".format("model")
    train_info = TrainInfo(
        **{"name": "", "path": src_dir}).as_json()
    # save vectorizer
    model_utils.save(file_name=file_name, obj=transformer, config=config)
    transformed_dataset = transformer.transform(input_data)
    # dataset format from configurations
    new_dataset = {"data_format": "csr", "value": transformed_dataset}
    for k in ["labels"]:
        if k in dataset: new_dataset[k] = dataset[k]
    return train_info, new_dataset

# todo look at refit
