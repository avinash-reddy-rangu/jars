import json
import pandas as pd

from xpms_helper.model.train_info import TrainInfo
from xpms_helper.model.model_utils import calculate_metrics
from xpms_helper.model import dataset_utils, model_utils
import xgboost as xgb


def run_model(config, model_obj, X, en_classes, de_classes):
    class_indexes = {}
    for index in range(0, len(en_classes)):
        class_indexes[en_classes[index]] = index
    predictions = []
    params = get_params(config)["params"]
    predictions_raw = model_obj.predict(X)
    if params["objective"] in ["binary:logistic"]:
        for val in predictions_raw:
            row = [(1-val), val]
            predictions.append(row)
    elif params["objective"] in ["multi:softmax"]:
        for val in predictions_raw:
            row = [0] * len(en_classes)
            row[class_indexes[val]] = 1
            predictions.append(row)
    elif params["objective"] == "multi:softprob":
        predictions = predictions_raw
    else:
        raise Exception("unsupported objective parameter")

    result_df = pd.DataFrame(data=predictions, columns=de_classes)

    return result_df


def run(datasets, config,caching=False):

    x = dataset_utils.load_dataset(config, datasets, "x")
    dtest = xgb.DMatrix(data=x)

    file_name = "{0}.pkl".format("model")
    model_obj = model_utils.load(file_name=file_name, config=config,caching=caching)
    encoder = SimpleEncoder()
    encoder.fit(config, [], exec_mode="run")

    result_df = run_model(config, model_obj,dtest, encoder.encoded_labels(), encoder.labels())

    full_dataset = dataset_utils.update_dataset(datasets, result_df,config)
    result_dataset = {"value": full_dataset, "data_format": "data_frame","target_column":config['target'],"predicted_classes": json.dumps(encoder.labels())}
    data = list(datasets.values())[0]['value']
    if isinstance(x, pd.DataFrame):
        run_info = {"dataval": x[0:50].values.tolist(), "datacol": x[0:50].columns.tolist(), "rec": data.shape[0],
                    "col": data.shape[1], "dep_var": config["target"]}
        return result_dataset, run_info
    else:
        return result_dataset, None


def get_params(config):
    try:
        params = config["algorithm"]["configuration"]
    except:
        params = dict()
    # this comes here

    if "additional_params" in config:
        for k in ["learning_rates","num_boost_round"]:
            params[k] = config["additional_params"][k]
        if "params" in  config["additional_params"]:
            params["params"].update(config["additional_params"]["params"])
    return params


def train(datasets, config):
    x = dataset_utils.load_dataset(config, datasets, "x")
    y = dataset_utils.load_dataset(config, datasets, "y")
    encoder = SimpleEncoder()
    y = encoder.fit(config, y, exec_mode="train")
    dtrain = xgb.DMatrix(x, label=y)

    params = get_params(config)
    if params["params"]["objective"] in ["multi:softmax","multi:softprob"]:
        params["params"]["num_class"] = len(set(y))
    model_obj = xgb.train( dtrain= dtrain,**params)
    file_name = "{}.pkl".format("model")
    model_utils.save(file_name=file_name, obj=model_obj, config=config)

    result_df = run_model(config, model_obj, dtrain, encoder.encoded_labels(), encoder.labels())
    full_dataset = dataset_utils.update_dataset(datasets, result_df)

    data = list(datasets.values())[0]['value']
    train_info = TrainInfo(
        **{"name": "", "path": config["src_dir"], "params": params, "classes": encoder.labels(), "rec": data.shape[0], "col": data.shape[1],
           "dep_var": config["target"]}).as_json()

    config["algorithm"]["path"] = config["src_dir"]
    result_dataset = {"value": full_dataset, "data_format": "data_frame","target_column":config['target'], "predicted_classes": encoder.labels()}
    return train_info, result_dataset


def evaluate(datasets, config,caching=False):
    y = dataset_utils.load_dataset(config, datasets, "y")
    model_output, run_info = run(datasets, config,caching=caching)
    # get prediction columns
    dataset_df = dataset_utils.load_predictions(datasets, model_output["value"])
    y_pred = dataset_df.idxmax(axis=1).values
    scorers = config["scorers"]
    # todo model output is not of correct shape
    data = list(datasets.values())[0]['value']
    metrics = calculate_metrics(data, scorers, y, y_pred, config)
    return metrics, model_output, run_info


def retrain(datasets, config, caching=False):
    x = dataset_utils.load_dataset(config, datasets, "x")
    y = dataset_utils.load_dataset(config, datasets, "y")
    encoder = SimpleEncoder()
    y = encoder.fit(config, y, exec_mode="retrain")
    dtrain = xgb.DMatrix(x, label=y)

    params = get_params(config)
    if params["params"]["objective"] in ["multi:softmax","multi:softprob"]:
        params["params"]["num_class"] = len(set(y))
    #load previous model
    file_name = "{0}.pkl".format("model")
    model_obj = model_utils.load(file_name=file_name, config=config, caching=caching)
    model_obj = xgb.train( dtrain=dtrain, xgb_model=model_obj, **params)
    file_name = "{}.pkl".format("model")
    model_utils.save(file_name=file_name, obj=model_obj, config=config)

    result_df = run_model(config, model_obj, dtrain, encoder.encoded_labels(), encoder.labels())
    full_dataset = dataset_utils.update_dataset(datasets, result_df)

    data = list(datasets.values())[0]['value']
    train_info = TrainInfo(
        **{"name": "", "path": config["src_dir"], "params": params, "classes": encoder.labels(), "rec": data.shape[0], "col": data.shape[1],
           "dep_var": config["target"]}).as_json()

    config["algorithm"]["path"] = config["src_dir"]
    result_dataset = {"value": full_dataset, "data_format": "data_frame","target_column":config['target'], "predicted_classes": encoder.labels()}
    return train_info, result_dataset




class SimpleEncoder:

    def labels(self):
        return self.labels_list

    def encoded_labels(self):
        return list(range(0, len(self.labels())))

    def defcode(self, config):
        pass

    def fit(self, config, Y, exec_mode = "train"):
        if exec_mode == "train":
            labels_list = list(set(Y))
            label_map = dict()
            for i in range(0, len(labels_list)):
                label_map[labels_list[i]] = i
            label_coding = {
                "labels_list": labels_list,
                "label_map": label_map
            }
            model_utils.save("label_coding", label_coding, config)
        elif exec_mode in ["run", "eval"]:
            label_coding = model_utils.load("label_coding", config)
            label_map = label_coding["label_map"]
            labels_list = label_coding["labels_list"]
        elif exec_mode == "retrain":
            label_coding = model_utils.load("label_coding", config)
            labels_list = list(set(Y))
            for label in labels_list:
                if label not in label_coding["labels_list"]:
                    label_coding["label_map"][label] = len(label_coding["labels_list"])
                    label_coding["labels_list"].append(label)
            model_utils.save("label_coding", label_coding, config)
            labels_list = label_coding["labels_list"]
            label_map = label_coding["label_map"]
        else:
            raise Exception("exec mode {} is not handled in the model runner script".format(exec_mode))

        y_ = []
        for label in Y:
            y_.append(label_map[label])

        self.label_map = label_map
        self.labels_list = labels_list

        return y_
































