from pandas.api.types import is_string_dtype
from sklearn.preprocessing import LabelEncoder
from xpms_helper.model import model_utils
from xpms_helper.model.train_info import TrainInfo


def train(dataset_dict: dict, config,caching=False):
    try:
        task_config = config["algorithm"]["configuration"]
    except Exception:
        raise Exception("configuration not found")

    task_data = list(dataset_dict.values())[0]
    if task_config['col_name'] == ["all"]:
        columns = list(task_data['value'].columns)
    else:
        columns = [col.strip() for col in task_config['col_name']]
    for col in columns:
        if not is_string_dtype(task_data['value'][col]):
            raise Exception("can encode only categorical columns")
        le = LabelEncoder()
        task_data['value'][col] = le.fit_transform(task_data['value'][col])
        file_name = "{}.pkl".format(col)
        model_utils.save(file_name=file_name,obj=le,config=config)
    train_info = TrainInfo(
        **{"name": "label encoder", "path": config["src_dir"]}).as_json()
    return train_info, task_data

def run(dataset_dict: dict, config,caching=False):
    try:
        task_config = config["algorithm"]["configuration"]
    except Exception:
        raise Exception("configuration not found")
    task_data = list(dataset_dict.values())[0]
    if task_config['col_name'] == ["all"]:
        columns = list(task_data['value'].columns)
    else:
        columns = [col.strip() for col in task_config['col_name']]
    for col in columns:
        file_name = "{}.pkl".format(col)
        le = model_utils.load(file_name=file_name,config=config,caching=caching)
        task_data['value'][col] = le.fit_transform(task_data['value'][col])
    return task_data

def evaluate(dataset_dict: dict, config,caching=False):
    try:
        task_config = config["algorithm"]["configuration"]
    except Exception:
        raise Exception("configuration not found")
    task_data = list(dataset_dict.values())[0]
    if task_config['col_name'] == ["all"]:
        columns = list(task_data['value'].columns)
    else:
        columns = [col.strip() for col in task_config['col_name']]
    for col in columns:
        file_name = "{}.pkl".format(col)
        le = model_utils.load(file_name=file_name,config=config,caching=caching)
        task_data['value'][col] = le.fit_transform(task_data['value'][col])
    return {},task_data
