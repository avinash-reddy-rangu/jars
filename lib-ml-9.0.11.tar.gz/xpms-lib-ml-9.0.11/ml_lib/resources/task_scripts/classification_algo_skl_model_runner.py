import json
from copy import copy
from pydoc import locate

import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from xpms_helper.model import dataset_utils, model_utils
from xpms_helper.model.model_utils import calculate_metrics
from xpms_helper.model.train_info import TrainInfo


def run(datasets, config, caching=False):
    x = dataset_utils.load_dataset(config, datasets, "x")
    result_df, classes = run_model(x, config, caching)
    full_dataset = dataset_utils.update_dataset(datasets, result_df, config)
    result_dataset = {"value": full_dataset, "data_format": "data_frame", "target_column": config['target'],
                      "predicted_classes": json.dumps(classes)}
    data = list(datasets.values())[0]['value']
    if isinstance(x, pd.DataFrame):
        run_info = {"dataval": x[0:50].values.tolist(), "datacol": x[0:50].columns.tolist(), "rec": data.shape[0],
                    "col": data.shape[1], "dep_var": config["target"]}
        return result_dataset, run_info
    else:
        return result_dataset, None


def initialize_algorithm(config):
    algorithm = locate(config["algorithm"]["class"])
    try:
        algorithm_config_params = config["algorithm"]["configuration"]
    except:
        algorithm_config_params = dict()
    # this comes here
    if "auto_tune" in config["algorithm"] and not config["algorithm"]["auto_tune"]:
        from sklearn.model_selection import KFold
        from sklearn.model_selection import GridSearchCV

        # cv = config["algorithm"]["auto_tuner"]["cv"]
        cv = 5
        scorer = config["algorithm"]["auto_tuner"]["scorer"]
        if config["algorithm"]["auto_tuner"]["name"] != "grid_search":
            raise Exception("mentioned auto_tuner not found")
        params = copy(config["algorithm"]["auto_tuner"]["configuration"])

        if "predict_proba" not in dir(algorithm):
            algorithm = CalibratedClassifierCV(algorithm(), cv=3)
        else:
            algorithm = algorithm()

        folds = KFold(n_splits=cv)
        # train using gridsearch
        clf = GridSearchCV(algorithm, params, cv=folds,
                           scoring=scorer, error_score=-1.0)
    else:
        if "predict_proba" not in dir(algorithm):
            clf = CalibratedClassifierCV(algorithm(), **algorithm_config_params, cv=3)
        else:
            clf = algorithm(**algorithm_config_params)

    return clf


def run_model_obj(x, model_name, config, caching=False):
    file_name = "{0}.pkl".format(model_name)
    model_obj = model_utils.load(file_name=file_name, config=config, caching=caching)
    result = model_obj.predict_proba(x)
    return result, model_obj.classes_.tolist()


def run_model(x, config, caching=False):
    result_df = None
    if not config.get("multi_model", False):
        result, classes = run_model_obj(x, "model", config, caching)
        result_df = pd.DataFrame(data=result, columns=classes)
        return result_df, classes
    classes = [file_name[:-4] for file_name in model_utils.get_file_names("model",config,caching=caching)]
    for pred_class in classes:
        model_path = "model/" + pred_class + ".pkl"
        model_obj = model_utils.load(model_path, config, caching=caching)
        predictions = model_obj.predict_proba(x)
        model_pred = pd.DataFrame(data=predictions, columns=model_obj.classes_)
        model_pred.rename(columns={1: pred_class}, inplace=True)
        model_pred = model_pred[[pred_class]]
        if result_df is None:
            result_df = model_pred
        else:
            result_df = pd.concat([result_df, model_pred], ignore_index=True, axis=1)
    result_df.columns = classes
    return result_df, classes

def train_model(x, y, model_name, config):
    clf = initialize_algorithm(config)
    model_obj = clf.fit(x, y)
    file_name = "{}.pkl".format(model_name)
    model_utils.save(file_name=file_name, obj=model_obj, config=config)
    if "auto_tune" in config["algorithm"] and not config["algorithm"]["auto_tune"]:
        params = model_obj.best_params_
    else:
        params = model_obj.get_params()

    predictions = model_obj.predict_proba(x)
    result_df = pd.DataFrame(data=predictions, columns=model_obj.classes_)

    return params, result_df


def train_multi_models(x, y, model_folder_name, config):
    # only supports if x and y are dataframes
    result_df = None

    params_list = []
    for pred_class in set(y):
        model_name = model_folder_name + "/" + pred_class
        y_dash = [0]*len(y)
        for i, cls_name in enumerate(y):
            if cls_name == pred_class:
                y_dash[i] = 1
            else:
                y_dash[i] = 0
        params, model_pred = train_model(x, y_dash, str(model_name), config)

        model_pred.rename(columns={1: pred_class}, inplace=True)
        model_pred = model_pred[[pred_class]]
        if result_df is None:
            result_df = model_pred
        else:
            result_df = pd.concat([result_df, model_pred], ignore_index=True, axis=1)
        params_list.append(params)
    result_df.columns = set(y)

    return params_list, result_df


def train(datasets, config):
    x = dataset_utils.load_dataset(config, datasets, "x")
    y = dataset_utils.load_dataset(config, datasets, "y")

    if config.get("multi_model") == True:
        params_list, result_df = train_multi_models(x, y, "model", config)
    else:
        params, result_df = train_model(x, y, "model", config)
        params_list = [[params]]

    data = list(datasets.values())[0]['value']
    classes = result_df.columns.tolist()
    config["algorithm"]["path"] = config["src_dir"]
    full_dataset = dataset_utils.update_dataset(datasets, result_df)

    train_info = TrainInfo(
        **{"name": "", "path": config["src_dir"], "params": params_list, "classes": classes,
           "rec": data.shape[0], "col": data.shape[1],
           "dep_var": config["target"]}).as_json()
    result_dataset = {"value": full_dataset, "data_format": "data_frame", "target_column": config['target'],
                      "predicted_classes": json.dumps(classes)}
    return train_info, result_dataset


def evaluate(datasets, config, caching=False):
    y = dataset_utils.load_dataset(config, datasets, "y")
    model_output, run_info = run(datasets, config, caching=caching)
    # get prediction columns
    dataset_df = dataset_utils.load_predictions(datasets, model_output["value"])
    y_pred = dataset_df.idxmax(axis=1).values
    scorers = config["scorers"]
    # todo model output is not of correct shape
    data = list(datasets.values())[0]['value']
    metrics = calculate_metrics(data, scorers, y, y_pred, config)
    return metrics, model_output, run_info

# import os
# from uuid import uuid4
# train_input = {"config":
#                    {
#                        "multi_model":True,
#                        "algorithm": {"auto_tuner": {"name": "grid_search", "configuration": {"probability": [True]}},
#                                         "configuration": {"probability": True, "C": 1.0, "kernel": "rbf"},
#                                         "class": "sklearn.svm.SVC"}, "source_type": "lib",
#                           "source": "ml_lib.resources.task_scripts.classification_algo_skl_model_runner", "files": [],
#                           "conditions": {}, "scorers": "None", "target": "class", "task_reference": "",
#                           "dependencies": "any", "previous_tasks": ["processed"], "retry_call": False,
#                           "task_max_retries": 3, "retry_count": 1,
#                           "src_dir": "daxqw_97947ea9-d319-4c48-adca-7991ec527c30/ml/fa5ba6af-c84f-4589-bab2-8d7d57d718c0/333d91f2-bbd7-47fd-a410-4a0cbae3c44a/ServiceTask_0vvpvj7",
#                           "model": {"pipeline": {"pipeline_id": "8df7efa9-cf1e-41d8-ba30-f3a70c6d1af5",
#                                                  "source": {"model_type": "classification",
#                                                             "pipeline_template_name": "empty"},
#                                                  "source_type": "template", "pipeline_name": "mld_base_version",
#                                                  "version_id": "333d91f2-bbd7-47fd-a410-4a0cbae3c44a"},
#                                     "evaluation": None, "training_dataset": "675d6e5e-f260-4395-8377-1926cc03685e",
#                                     "model_type": "classification", "data_format": "csv", "status": "failed",
#                                     "version_id": "333d91f2-bbd7-47fd-a410-4a0cbae3c44a", "data_schema": {},
#                                     "is_deleted": False, "is_enabled": False, "is_default": False,
#                                     "is_published": False, "parent_version": "333d91f2-bbd7-47fd-a410-4a0cbae3c44a",
#                                     "model_id": "fa5ba6af-c84f-4589-bab2-8d7d57d718c0",
#                                     "solution_id": "daxqw_97947ea9-d319-4c48-adca-7991ec527c30",
#                                     "_XpmsObjectMixin__api_version": "8.5", "_XpmsObjectMixin__type": "MLModelVersion",
#                                     "created_by": "system", "cts": "2020-02-13T12:36:07.030799", "description": "",
#                                     "modified_by": "system", "name": "base_version",
#                                     "uts": "2020-02-14T12:58:16.944627", "retraining_threshold": 500},
#                           "storage": "minio",
#                           "context": {"solution_id": "daxqw_97947ea9-d319-4c48-adca-7991ec527c30", "project_name": "ml",
#                                       "doc_id": None, "user_info": {},
#                                       "request_id": "2c486134-2026-479b-9999-bc39b4cad540",
#                                       "service_name": "test_pipeline", "method_name": "get_trigger_handler",
#                                       "ref_id": "a5bac16e-bf56-495d-b36b-5d8690b65fad", "file_name": None,
#                                       "case_id": "", "entry_stack": [], "exit_stack": [],
#                                       "model_execution_id": "a5bac16e-bf56-495d-b36b-5d8690b65fad",
#                                       "dag_execution_id": "noNGdh0SQL6zT9KVb7MMyA"}, "state": {}},
#                "dataset": {
#                    "2ZCrAJ1bTfiW3IKKm0LbWQ$ServiceTask_1lwvwae": {"data_format": "data_frame", "data_schema": None,
#                                                                   "value": "iris.csv"}},
#                "solution_id": "sol_id"
#                }
# uid = next(iter(train_input['dataset']))
# abspath = os.path.abspath(__file__)
# if train_input['dataset'][uid]['data_format'] == "data_frame":
#     data_file_path = os.path.dirname(abspath)+"/testcases"+"/data/"+train_input['dataset'][uid]['value']
#     train_input['dataset'][uid]['value'] = pd.read_csv(data_file_path)
# train_input['config']['src_dir'] = "/".join(abspath.split("/")[:-1])+"/testcases"+"/data"+train_input['solution_id']+"/"+str(uuid4())
# train_input['config']['storage'] = "local"
# train(datasets=train_input["dataset"], config= train_input["config"])
# result = run(datasets=train_input["dataset"], config= train_input["config"])
# print()