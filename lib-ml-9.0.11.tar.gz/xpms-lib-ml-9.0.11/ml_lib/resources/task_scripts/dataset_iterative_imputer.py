def run(dataset_dict: dict, config, caching=False):
    import pandas as pd
    import numpy as np
    from copy import deepcopy
    result_df = pd.DataFrame()
    from sklearn.experimental import enable_iterative_imputer
    from sklearn.impute import IterativeImputer

    for key, x in dataset_dict.items():
        x_df = x["value"]
        if config["algorithm"]["configuration"]["missing_values"] == "np.nan":
            imp_mean = IterativeImputer(missing_values=np.nan,
                                        initial_strategy=config["algorithm"]["configuration"]["initial_strategy"],
                                        max_iter=config["algorithm"]["configuration"]["max_iter"],
                                        tol=config["algorithm"]["configuration"]["tol"],
                                        imputation_order=config["algorithm"]["configuration"]["imputation_order"]
                                        )
        elif config["algorithm"]["configuration"]["missing_values"] == "int":
            imp_mean = IterativeImputer(missing_values=config["algorithm"]["configuration"]["missing_values"],
                                        initial_strategy=config["algorithm"]["configuration"]["initial_strategy"],
                                        fill_value=config["algorithm"]["configuration"]["fill_value"],
                                        max_iter=config["algorithm"]["configuration"]["max_iter"],
                                        tol=config["algorithm"]["configuration"]["tol"],
                                        imputation_order=config["algorithm"]["configuration"]["imputation_order"]
                                        )
        result_df = pd.DataFrame(imp_mean.fit_transform(x_df))
        result_df.columns = x_df.columns
        result_df.index = x_df.index

    task_output = deepcopy(dataset_dict[list(dataset_dict.keys())[0]])
    task_output["value"] = result_df
    return task_output
