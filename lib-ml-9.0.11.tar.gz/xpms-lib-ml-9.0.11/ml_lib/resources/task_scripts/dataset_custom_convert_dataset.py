from ml_lib.model.data_schema import DatasetConvertor, DatasetFormat


def run(datasets, config,caching=False):
    convert_to = config["func"]["configuration"]["convert_to"]
    try:
        data_schema = config["func"]["configuration"]["data_schema"]
    except:
        data_schema = None
    dataset = next(iter(datasets.values()))
    new_dataset = DatasetConvertor.convert(dataset, DatasetFormat(convert_to), data_schema)
    run_info = None
    return new_dataset, run_info
