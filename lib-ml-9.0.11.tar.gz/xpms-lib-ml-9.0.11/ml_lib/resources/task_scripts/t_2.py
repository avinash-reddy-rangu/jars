import pandas as pd
from xpms_helper.model import model_utils
from keras.preprocessing.image import img_to_array
import tensorflow as tf
from keras.preprocessing.image import save_img, load_img
from uuid import uuid4
from xpms_file_storage.file_handler import XpmsResource, LocalResource
from xpms_helper.model import dataset_utils
from datetime import datetime
from xpms_helper.lru_cache import lru_cache, GRANDE_CACHE_SIZE
import gc
from tensorflow.python.platform import gfile
from multiprocessing import Process

import os
import psutil

image_path = "/Users/mayank/Desktop/table-1result.jpg"



import os
import psutil

process = psutil.Process(os.getpid())

def print_memory_and_ts(process_name, previous_ts= None):
    time_stamp = datetime.utcnow()
    if previous_ts:
        print(time_stamp)
        print("time_taken : "+ str((time_stamp - previous_ts).microseconds))
    print("memory {0} : ".format(process_name) + str(process.memory_info().rss / 1000000))
    return time_stamp

def run(caching=True):

    def run_model(caching = True):
        filepath = "/Users/mayank/Desktop/tf_model_903_160.pb"
        save_option = "pb"

        # ts = print_memory_and_ts("before model load", datetime.utcnow())
        sess = get_session(caching=caching)
        load_model_graph(filepath, save_option, caching=caching)
        image_nd_array = preprocess_image(image_path)
        softmax_tensor = sess.graph.get_tensor_by_name('import/activation_10/Tanh:0')
        gen_image = sess.run(softmax_tensor, {'import/input_3:0': image_nd_array})

        # ts = print_memory_and_ts("before after load", ts)

    if not caching:
        p = Process(target=run_model, args=(caching,))
        p.start()
        p.join()
        del p
    else:
        run_model(caching)
    gc.collect()

    return None



@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def get_session(caching= True):
    sess = tf.compat.v1.InteractiveSession()
    sess.graph.as_default()
    return sess

@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_graph(graph_def, caching_key = None, caching=True):
    tf.import_graph_def(graph_def)
    return 1

# @lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_model_graph(filepath, save_option, caching=True):
    graph_def = load(file_name=None, save_option=save_option,
                                 filepath=filepath, caching=caching)

    load_graph(graph_def= graph_def, caching_key="load_gan_graph",caching=caching)




def load(file_name, save_option="pkl", filepath=None, caching=True):
    """
        This function is for loading scikit and tensorflow model resources
        supported resource types are .pkl and .hd5.
    :param file_name: Name of the file - type <string>
    :param config :  Configuration - type <dict>
    :param save_option: File type - type <string>
    :return: file content  - type <string>
    """
    return load_pb(filepath, caching=caching)

@lru_cache(maxsize=GRANDE_CACHE_SIZE)
def load_pb(filepath, caching=True):
    local_r = LocalResource(key=filepath)
    f = gfile.FastGFile(local_r.fullpath, 'rb')
    graph_def = tf.compat.v1.GraphDef()
    graph_def.ParseFromString(f.read())
    f.close()
    return graph_def

def preprocess_image(image_path):
    img = load_img(path=image_path, target_size=(512, 1024))
    img_arry = img_to_array(img)
    resized_img_arry = img_arry.reshape(1, 512, 1024, 3)
    normalized_img = (resized_img_arry - 127.5) / 127.5
    return normalized_img
