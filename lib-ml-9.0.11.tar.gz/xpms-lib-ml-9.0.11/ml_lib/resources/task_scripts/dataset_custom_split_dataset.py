def run(dataset_dict: dict, config,caching=False):
    from copy import copy
    from sklearn.model_selection import train_test_split

    task_data = list(dataset_dict.values())[0]
    task_dataset = task_data["value"].copy()

    ratio = float(config["func"]["configuration"]["split_ratio"])
    if ratio == 1:
        ratio = 0.99999
    shuffle = config["func"]["configuration"]["shuffle"]
    random_state = config["func"]["configuration"]["random_state"]
    stratify_column = config["func"]["configuration"]["stratify_column"]

    stratify = stratify_column if stratify_column in task_dataset[stratify_column].tolist() and shuffle else None
    train_df, test_df = train_test_split(task_dataset, test_size=ratio, shuffle=shuffle,
                                         random_state=random_state, stratify=stratify)
    # output_data = copy(task_data)
    output_data = [
        {"value": test_df.reset_index(drop=True), "data_format": "data_frame"},
        {"value": train_df.reset_index(drop=True), "data_format": "data_frame"}

    ]
    return output_data
