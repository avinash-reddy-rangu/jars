import os
import psutil
from datetime import datetime
from xpms_storage.db_handler import DBProvider
process = psutil.Process(os.getpid())
from uuid import uuid4

def log_memory(message):
    _id = str(uuid4())
    data = {"message":message, "memory":str(process.memory_info().rss / 1000000),"ts": datetime.utcnow().isoformat(), "uid":_id}
    find_query = {"uid":_id}
    db = DBProvider.get_instance(db_name="system")
    db.update(table="dag_memory",update_obj=data, filter_obj=find_query)