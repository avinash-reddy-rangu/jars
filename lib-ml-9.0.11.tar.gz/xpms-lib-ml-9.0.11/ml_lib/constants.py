from enum import Enum

MAX_DATAFRAME_ROWS = 100000

MICROSERVICE_PATH = "ml"
RESOURCE_PATH = "resources"


class StandardOutputs(Enum):
    JOB_COMPLETE = "job_complete"
