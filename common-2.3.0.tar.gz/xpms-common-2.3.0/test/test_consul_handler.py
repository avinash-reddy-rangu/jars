from xpms_common.consul_handler import ConsulHandler
import pytest
from pprint import pprint

@pytest.mark.parametrize("service_name, host, port, expected",
                         [("dummy_service", None, None, "Service not found"),
                          ("dummy_host", "localhost", None, "Couldn't connect to Consul"),
                          ("consul", None, None, "8300")]
                         )
def test_discover_service(service_name, host, port, expected):
    res = ConsulHandler.discover_service(service_name, host=host, port=port)
    pprint(res)
    if res['status']['success']:
        assert str(res['service_port']) == expected
    else:
        assert res['status']['msg'].startswith(expected)
