from xpms_common.cache_handler import CacheHandler


def test_set_and_update_json_value_in_cache():
    initial_value = {"name": "Nishant", "mobile": 9920292029}
    CacheHandler.set("info", initial_value)
    initial_value_set = CacheHandler.get_json_value("info")
    assert initial_value_set == initial_value
    updated_value = {"name": "Nishant Saxena", "mobile": 98910982098}
    CacheHandler.set("info", updated_value)
    updated_value_set = CacheHandler.get_json_value("info")
    assert updated_value_set == updated_value

test_set_and_update_json_value_in_cache()
def test_set_and_update_raw_value_in_cache():
    initial_value = "initial information"
    CacheHandler.set_raw_value("info", initial_value)
    initial_value_set = CacheHandler.get_raw_value("info")
    assert initial_value_set == initial_value
    updated_value = "updated information"
    CacheHandler.set("info", updated_value)
    updated_value_set = CacheHandler.get_raw_value("info")
    assert updated_value_set == updated_value

def test_delete_cache_handler():
    CacheHandler.set("name1", {"name": "mayank"})
    CacheHandler.set("name2",{"name":"mayank"})
    CacheHandler.set("name3",{"name":"mayank"})
    val = CacheHandler.get_json_value("name1")
    assert val is not None
    name_list = ["name1","name2","name3"]
    CacheHandler.delete_keys(name_list)
    val = CacheHandler.get_json_value("name1")
    assert val is None
