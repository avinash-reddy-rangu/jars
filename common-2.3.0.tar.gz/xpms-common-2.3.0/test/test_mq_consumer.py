import pytest
from xpms_common.mq_consumer import MQConsumer

#todo need to see how to test
# queue_name = rkey = "entity.signal"
# consumer = MQConsumer(queue=queue_name, routing_key=rkey)
#
# try:
#     consumer.blocking_connection()
# except (RuntimeError, KeyboardInterrupt, Exception) as e:
#     consumer.close_connection()

