import pytest
import os
from uuid import uuid4
import pickle

abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath)
share_volume = dname+"/"
print(share_volume)
os.environ["SHARED_VOLUME"] = share_volume

from xpms_common.efs_handler import EFSHandler





test_data_test_load_and_get_file = [({"local_file_path":"test/data/efs_test.json", "server_file_path":"data/", "server_file_name": "efs_test_result.json"})]

@pytest.mark.parametrize("test_data_test_load_and_get_file", test_data_test_load_and_get_file)
def test_load_and_get_file(test_data_test_load_and_get_file):
    local_file_path = test_data_test_load_and_get_file["local_file_path"]
    server_file_path = test_data_test_load_and_get_file["server_file_path"]
    server_file_name = test_data_test_load_and_get_file["server_file_name"]
    result_file_path = server_file_path + server_file_name
    try:
        os.remove(result_file_path)
    except OSError:
        pass
    EFSHandler.initialize()
    EFSHandler.upload_file(local_file_path, server_file_path, server_file_name)

    try:
        os.remove(local_file_path)
        if os.path.exists(local_file_path) == False:
            pass
        else:
            raise Exception
    except OSError:
        pass

    EFSHandler.download_file(local_file_path, server_file_path, server_file_name)
    assert os.path.exists(EFSHandler.storage_path+result_file_path)

# test_load_and_get_file(test_data_test_load_and_get_file[0])

msg ={"a": "test","trigger":"test","request_id":str(uuid4()),"solution_id":"test","data":{}}
test_data_load_and_get_file_as_obj = [({"local_file_path":"test/data/efs_test.json", "server_file_path":"data/", "server_file_name": "efs_test_result.json", "file_data": msg})]

@pytest.mark.parametrize("test_data_load_and_get_file_as_obj", test_data_load_and_get_file_as_obj)
def test_load_and_get_file_as_obj(test_data_load_and_get_file_as_obj):
    local_file_path = test_data_load_and_get_file_as_obj["local_file_path"]
    server_file_path = test_data_load_and_get_file_as_obj["server_file_path"]
    server_file_name = test_data_load_and_get_file_as_obj["server_file_name"]
    file_data = test_data_load_and_get_file_as_obj["file_data"]

    upload_object = pickle.dumps(file_data)

    try:
        os.remove(server_file_path + server_file_name)
    except OSError:
        pass
    EFSHandler.initialize()
    EFSHandler.upload_object(server_file_path, server_file_name, upload_object)

    result = EFSHandler.download_object(server_file_path, server_file_name)
    result = pickle.loads(result)
    assert result == test_data_load_and_get_file_as_obj["file_data"]


# test_load_and_get_file_as_obj(test_data_load_and_get_file_as_obj[0])