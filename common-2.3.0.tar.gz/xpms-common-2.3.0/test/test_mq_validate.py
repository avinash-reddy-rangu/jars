import pytest
from xpms_common.mq_validate import is_valid_json, HEADER_SCHEMA
from xpms_common.errors import InvalidUsageError, InternalError
import sys

test_header = {
    "msg_id": "6b1570db-e83b-44ba-801d-a1f37a2c9d88",
    "msg_type": "ping",
    "from": "",
    "to": "",
    "timestamp": "2017-04-11T15:41:42.929805"
}

test_header2 = {
    "msg_id": "6b1570db-e83b-44ba-801d-a1f37a2c9d88",
    "msg_type": "endpoint",
    "from": "",
    "to": "",
    "timestamp": "2017-04-11T15:41:42.929805"
}

test_schema =  {
    "$schema": "http://json-schema.org/schema#",
    "type": "object",
    "properties": {
            "msg_id": {
                "type": "string",
                "pattern": {}
                },
            "msg_type": {
                "enum": ["ping", "signal", "broadcast"]
            },
            "from": {"type": "string"},
            "to": {"type": "string"},
            "timestamp": {"type": "string"}
    },
    "required": [ "msg_id", "msg_type", "from", "to", "timestamp" ]
}

test_data = [
    (test_header, HEADER_SCHEMA, True),
    (test_header2, HEADER_SCHEMA, 405),
    (test_header, test_schema, 500)
]


@pytest.mark.parametrize("_json, schema, expected", test_data)
def test_is_valid_json(_json, schema, expected):
    try:
        v = is_valid_json(_json, schema)
        assert v == expected
    except InvalidUsageError as e:
        assert e.status_code == expected
    except InternalError as e:
        assert e.status_code == expected