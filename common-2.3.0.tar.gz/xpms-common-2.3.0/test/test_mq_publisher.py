from xpms_common.mq_publisher import MQPublisher
# from errors import AuthenticationError
from uuid import uuid4
import pytest
import os
# TODO move to tests/
# TODO mock test_exchange and test_queues
host = os.environ["EX_HOST_QUEUE"]
port = os.environ["EX_PORT_QUEUE"]
user_name = os.environ["EX_USERID_QUEUE"]
password = os.environ["EX_PASSWORD_QUEUE"]

conn_url = 'amqp://user_name:password@host:port/%2F?connection_attempts=3&heartbeat_interval=3600'
conn_url_err = 'amqp://user_name:password@host:port/%2F?connection_attempts=3&heartbeat_interval=3600'
msg = {"a": "test","trigger":"test","request_id":str(uuid4()),"solution_id":"test","data":{}}
msg_type = 'ping'
rkey = 'all.data'

test_data = [
    (conn_url, msg, msg_type, rkey, True),
    (conn_url, msg, msg_type, "entity", False)
]

@pytest.mark.parametrize("conn_url, msg, msg_type, rkey, expected", test_data)
def test_publish_message(conn_url, msg, msg_type, rkey, expected):
    # try:
    pub = MQPublisher(service_name="test_service")
    pub.connect()
    receipt = pub.publish_message(payload=msg, routing_key=rkey, message_type=msg_type)
    pub.stop()
    assert receipt['success'] == expected
    # except AuthenticationError as e:
    #     assert e.status_code == expected