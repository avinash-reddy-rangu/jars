from xpms_common.storage_handler import StorageHandler
from uuid import uuid4
import pickle
import pytest
import os


msg ={"a": "test","trigger":"test","request_id":str(uuid4()),"solution_id":"test","data":{}}
test_data_load_and_get_file_as_obj = [({"bucket_name":"xpms_test_bucket","key":"1234","file_data":msg})]

@pytest.mark.parametrize("test_data_load_and_get_file_as_obj", test_data_load_and_get_file_as_obj)
def test_load_and_get_file_as_obj(test_data_load_and_get_file_as_obj):
    bucket_name = test_data_load_and_get_file_as_obj["bucket_name"]
    file_name = test_data_load_and_get_file_as_obj["key"]
    file_data = test_data_load_and_get_file_as_obj["file_data"]
    file_data = pickle.dumps(file_data)

    try:
        StorageHandler.create_bucket(bucket_name)
    except:
        pass

    StorageHandler.upload_object(bucket_name, file_name, file_data)
    result = StorageHandler.download_object(bucket_name,file_name)
    result = pickle.loads(result)
    assert result == test_data_load_and_get_file_as_obj["file_data"]


test_data_test_load_and_get_file = [({"bucket_name":"xpms_test_bucket","file_name":"test/data/s3_test.json","key":"test_12345","result_file_path":"test/data/s3_test_result.json"})]

@pytest.mark.parametrize("test_data_test_load_and_get_file", test_data_test_load_and_get_file)
def test_load_and_get_file(test_data_test_load_and_get_file):
    file_name = test_data_test_load_and_get_file["file_name"]
    key = test_data_test_load_and_get_file["key"]
    result_file_path = test_data_test_load_and_get_file["result_file_path"]
    bucket_name = test_data_test_load_and_get_file["bucket_name"]

    try:
        os.remove(result_file_path)
    except OSError:
        pass

    try:
        StorageHandler.create_bucket(bucket_name)
    except:
        pass

    StorageHandler.upload_file( file_name,bucket_name,key)
    StorageHandler.download_file(result_file_path,bucket_name,key)
    assert os.path.exists(result_file_path)


# test_load_and_get_file({"bucket_name":"xpms_test_bucket","file_name":"test/data/s3_test.json","key":"test_12345","result_file_path":"test/data/s3_test_result.json"})