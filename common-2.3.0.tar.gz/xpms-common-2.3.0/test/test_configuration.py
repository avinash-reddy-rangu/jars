from xpms_common.configuration import Configuration
import sys

sys.path.append("../")

#todo
# def test_get_config_from_store():
#     instance = Configuration().get_instance()
#     assert instance is not None

def test_update_configuration():
    assert True

def test_get_instance():
    instance = Configuration().get_instance()
    assert instance is not None
