import pytest
from xpms_common.s3_utils import *
import hashlib


def pytest_generate_tests(metafunc):
    file_name = os.path.basename(__file__)
    abspath = os.path.abspath(__file__)
    dname = os.path.dirname(abspath)
    dname = dname + "/testdata/"
    test_path = dname + file_name
    test_path_parts = test_path.split(".")
    for parameter_name in ["test_data", "test_delete_data"]:
        if parameter_name in metafunc.funcargnames:
            tests_file = test_path_parts[0] + "/" + parameter_name[:-5] + ".json"
            with open(tests_file) as data_file:
                data = json.load(data_file)
                metafunc.parametrize(parameter_name, data["test_cases"])


def md5_for_file(path, block_size=256*128, hr=False):
    '''
    Block size directly depends on the block size of your filesystem
    to avoid performances issues
    Here I have blocks of 4096 octets (Default NTFS)
    '''
    md5 = hashlib.md5()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(block_size), b''):
             md5.update(chunk)
    if hr:
        return md5.hexdigest()
    return md5.digest()


def test(test_data):

    abspath = os.path.abspath(__file__)
    dname = os.path.dirname(abspath)
    storage = Storage(os.environ["AMAZON_AWS_KEY"],os.environ["AMAZON_AWS_SECRET_KEY"],os.environ["AMAZON_AWS_REGION"])
    #upload
    filename  = dname + "/testdata/test_s3_utils/" + test_data['upload_filename']
    key_name   = test_data['key_name']
    bucket_name = test_data['aws_bucket']
    md5 = md5_for_file(filename)
    storage.upload_to_s3(file_name=filename, bucket_name=bucket_name, key_name=key_name)

    #download
    filename = dname + "/testdata/test_s3_utils/" + test_data['download_filename']
    storage.download_from_s3(filename=filename, bucket_name=bucket_name, key_name=key_name)
    new_md5 = md5_for_file(filename)

    assert md5 == new_md5

