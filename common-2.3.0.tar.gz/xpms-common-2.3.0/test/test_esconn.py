# from xpms_common.esconn import ESConn
# import sys
# Need to be run only if ESConn is to be used, lets see
# sys.path.append("../")
#
# TEST_INDEX = "test_index"
# TEST_DOC_TYPE = "test_doc_type"
#
#
# def test_elastic_connection():
#     print("Test If connection established to the ES or not")
#     assert ESConn.get_server_info()
#
#
# def test_create_doc_and_delete():
#     print("create a new document")
#     rs = ESConn.create_doc(TEST_INDEX, TEST_DOC_TYPE, {"new": "document"})
#     print("Verify if  the new document inserted")
#     inserted_doc = ESConn.get_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     assert inserted_doc
#     print("Delete the document and verify if deleted successfully")
#     deleted_doc = ESConn.del_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     assert deleted_doc['found']
#
#
# def test_overwrite_doc_and_delete():
#     print("create a new document")
#     initial_doc = {"name": "John", "city": "SF"}
#     rs = ESConn.create_doc(TEST_INDEX, TEST_DOC_TYPE, initial_doc)
#     print("Verify if  the new document inserted")
#     inserted_doc = ESConn.get_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     assert inserted_doc
#     print("Overwrite Doc")
#     overwrite_doc = {"name": "John Lee", "county": "US"}
#     ESConn. overwrite_doc_having_id(TEST_INDEX, TEST_DOC_TYPE,
#                                     overwrite_doc, rs["_id"])
#     ow_doc = ESConn.get_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     print("Verify if doc overwritten as expected.")
#     assert ow_doc['_source'] == overwrite_doc
#     print("Delete the document and verify if deleted successfully")
#     deleted_doc = ESConn.del_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     assert deleted_doc['found']
#
#
# def test_update_doc_and_delete():
#     print("create a new document")
#     initial_doc = {"name": "John", "city": "SF"}
#     rs = ESConn.create_doc(TEST_INDEX, TEST_DOC_TYPE, initial_doc)
#     print("Verify if  the new document inserted")
#     inserted_doc = ESConn.get_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     assert inserted_doc
#     print("Update Doc")
#     update_doc = {"name": "John Lee", "county": "US"}
#     ESConn.update_doc_having_id(TEST_INDEX, TEST_DOC_TYPE,
#                                 update_doc, rs["_id"])
#     updated_doc = ESConn.get_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     print("Verify if doc overwritten as expected.")
#     initial_doc.update(update_doc)
#     assert updated_doc['_source'] == initial_doc
#     print("Delete the document and verify if deleted successfully")
#     deleted_doc = ESConn.del_doc_by_id(TEST_INDEX, TEST_DOC_TYPE, rs['_id'])
#     assert deleted_doc['found']
#
# # TODO : As above method is using : update_doc_having_id which internally using
# # search_by_clause and serach method but need to write test cases for them
