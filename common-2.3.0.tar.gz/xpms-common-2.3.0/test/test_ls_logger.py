import unittest
from xpms_common.ls_logger import LogConfig

'''
Author: Shashank 16-Sep-2016
LsLoggerTestCases requires consul to be running.
Few services are registered and the testing starts.

install     : brew install consul
run         :consul agent -dev -bind 127.0.0.1
register some services:  ( remove ./data/ if needed and cd to the folder for stm below.
            :   curl -X PUT -d @./data/service.json localhost:8500/v1/agent/service/register
                curl -X PUT -d @./data/entclasifier.json localhost:8500/v1/agent/service/register
                curl -X PUT -d @./data/rules.json localhost:8500/v1/agent/service/register
set env variable
            export CONSUL_HOST= 127.0.0.1
            export CONSUL_PORT= 8500
'''

#
# class LsLoggerTestCases(unittest.TestCase):
#
#     def test_upper(self):
#         self.assertEqual('foo'.upper(), 'FOO')
#
#     def test_pop_setting_log(self):
#         #cu = ConsulUtil("http://" + "localhost:8500")
#         ls = LsLogger()
#         settings_log = ls.pop_setting_log()
#         self.assertEqual(settings_log.__len__(), 3)
#
#     # def test_getServiceEndpoint(self):
#     #     uri = self.cu.getServiceEndpoint("RulesEngineMicroservice", "processData")
#     #     self.assertEqual(uri, "http://127.0.0.1:18007/processData")
#
# if __name__ == '__main__':
#     unittest.main()


#todo