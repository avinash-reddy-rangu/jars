import pytest
import os, json
from xpms_common.errors import InternalError
from xpms_common.cassandra_dbconn import Cassandra, OperationFailureCassandra
from cassandra import InvalidRequest
"""
These tests use xpms_common keyspace and emp table
"""

def pytest_generate_tests(metafunc):

    file_name = os.path.basename(__file__)
    abspath = os.path.abspath(__file__)
    dir_name = os.path.dirname(abspath)
    dir_name = dir_name + "/testdata/"
    test_path = dir_name + file_name
    test_path_parts = test_path.split(".")
    for parameter_name in ["get_column_names_test", "alter_table_test", "save_get_delete_test"]:
        if parameter_name in metafunc.funcargnames:
            tests_file = test_path_parts[0] + "/" + parameter_name + ".json"
            with open(tests_file) as data_file:
                data = json.load(data_file)
                metafunc.parametrize(parameter_name, data["test_cases"])

dbConn = None
entity_table_types = {

"emp":[
    """
     CREATE TABLE emp(
     emp_id int,
	emp_name text,
	emp_city text,
	emp_sal int,
	emp_phone int,
	primary key(emp_id)
     );
"""
]
}


def keyspace_exist(keyspace):

    try:
        init_cassandra(keyspace='system_schema')


        keyspaces = dbConn.find(table='keyspaces', filter_obj={"keyspace_name":keyspace})

        if len(keyspaces) > 1:
            raise InternalError('More than once keyspace found')

        if keyspaces:
            return True
        else:
            return False

    except OperationFailureCassandra:
        raise InternalError('Error occurred while checking existence of keyspace')


def create_keyspace(keyspace, strategy='SimpleStrategy', replication_factor='2'):

    try:

        init_cassandra(keyspace='system_schema')

        keyspace_create = """
                                CREATE KEYSPACE %s
                                WITH replication = {'class': 'SimpleStrategy', 'replication_factor': '2'}
                          """ % keyspace

        session = dbConn.get_session()

        session.execute(keyspace_create)

        return

    except OperationFailureCassandra:
        raise InternalError('Error occurred while creating keyspace' + keyspace)

def create_tables(keyspace):



    global entity_table_types

    try:
        init_cassandra(keyspace=keyspace)

        session = dbConn.get_session()
        session.set_keyspace(keyspace=keyspace)

        for table in entity_table_types:
            for query in entity_table_types[table]:
                print(query)
                session.execute(query)

        return

    except OperationFailureCassandra:
        raise InternalError('Error occured while creating entity tables')


def verify_tables(keyspace):

    def format_result(result):
        formatted = []

        for res in result:
            formatted.append(res[0])

        return formatted


    global entity_table_types

    init_cassandra(keyspace=keyspace)

    session = dbConn.get_session()

    query = 'SELECT table_name from system_schema.columns where keyspace_name=\'{0}\''.format(keyspace)

    tables = list(set(format_result(session.execute(query))))

    session.set_keyspace(keyspace=keyspace)
    for key in entity_table_types.keys():
        if key not in tables:
            for query in entity_table_types[key]:
                try:
                    session.execute(query)
                except InvalidRequest as e:
                    # These errors should be because of already existent types
                    print(type(e))

def init_cassandra(keyspace):
    global dbConn
    dbConn = Cassandra(keyspace)




def test_get_column_names(get_column_names_test):

    keyspace = get_column_names_test[0]['keyspace']
    table = get_column_names_test[1]['table']
    expected = get_column_names_test[2]['expected']

    if not keyspace_exist(keyspace):
        create_keyspace(keyspace)
        create_tables(keyspace)
    else:

        verify_tables(keyspace)

    init_cassandra(keyspace=keyspace)

    columns = dbConn.get_column_names(table=table)

    assert len(columns) == len(expected)

    for col in columns:
        assert col in expected

test_get_column_names([
      {
        "keyspace": "xpms_common"
      },
      {
        "table": "emp"
      },
      {
        "expected": ["emp_id","emp_name","emp_city","emp_sal","emp_phone"]
      }
    ])
def test_alter_table(alter_table_test):

    keyspace = alter_table_test[0]['keyspace']
    table = alter_table_test[1]['table']

    column_name = alter_table_test[2]['column_name']
    column_type = alter_table_test[2]['column_type']

    init_cassandra(keyspace)

    # adding column
    dbConn.alter_table(command='ADD', table=table, column_name=column_name, type=column_type)

    # fetching column names
    columns = dbConn.get_column_names(table=table)

    assert column_name in columns

    # drop column
    dbConn.alter_table(command='DROP', table=table, column_name=column_name)

    # fetching column names
    columns = dbConn.get_column_names(table=table)

    assert column_name not in columns


def test_save_get_delete(save_get_delete_test):

    keyspace = save_get_delete_test[0]['keyspace']
    table = save_get_delete_test[1]['table']
    data = save_get_delete_test[2]['data']
    filter_obj = save_get_delete_test[3]['filter_obj']

    init_cassandra(keyspace=keyspace)

    dbConn.insert(table=table, data=data)

    get_response = dbConn.find(table=table, filter_obj=filter_obj)

    assert len(get_response[0].keys()) == len(data.keys())

    dbConn.delete(table=table, filter_obj=filter_obj)

    # Verify succesful delete
    verify = dbConn.find(table=table, filter_obj=filter_obj)

    assert not verify

test_get_column_names([
      {
        "keyspace": "xpms_common"
      },
      {
        "table": "emp"
      },
      {
        "expected": ["emp_id","emp_name","emp_city","emp_sal","emp_phone"]
      }
    ])

