from xpms_common.db_handler import DBHandler
import sys
from bson.code import Code
from bson.dbref import DBRef
import pytest

sys.path.append("../")

TEST_DB = "test_db"
TEST_COLLECTION = "test_collection"





@pytest.mark.parametrize("raw_query,expected_result",
                         [(
                             {"data":{"patient":{"username":"john"}},"solution_id":"1241","primary_key":{"mrn":"1234","solution_id":"1241"}},{"data.patient.username":"john","solution_id":"1241","primary_key.solution_id":"1241","primary_key.mrn":"1234"})])
def test_create_mongo_query(raw_query,expected_result):
    result = DBHandler.create_mongo_query(raw_query)
    assert result == expected_result

def test_mongo_connection():
    print("Test If connection established to the Mongo or not")
    assert DBHandler.get_server_info()


def test_remove():
    print("Clean ", TEST_DB)
    DBHandler.remove(TEST_DB, TEST_COLLECTION, {})
    print("After cleanup, table should have zero records")
    assert not [e for e in DBHandler.find(TEST_DB, TEST_COLLECTION, {})]


def test_insert_find_and_remove():
    print("Insert New conneciton to Table")
    record_id = DBHandler.insert(TEST_DB, TEST_COLLECTION,
                                   {"name": "Nishant"})
    inserted_record = [e for e in DBHandler.find(TEST_DB, TEST_COLLECTION,
                                                   {"_id": record_id})]
    assert len(inserted_record) == 1
    print("Delete the inserted record")
    DBHandler.remove(TEST_DB, TEST_COLLECTION, {"_id": record_id})
    assert not [e for e in DBHandler.find(TEST_DB, TEST_COLLECTION,
                                            {"_id": record_id})]


def test_insert_find_one_update_and_remove():
    initial_data = {"name": "Nishant", "mobile": 9452710408}
    print("Insert New conneciton to Table")
    record_id = DBHandler.insert(TEST_DB, TEST_COLLECTION,
                                   initial_data)
    inserted_record = DBHandler.find_one(TEST_DB, TEST_COLLECTION,
                                           {"_id": record_id})
    assert inserted_record
    initial_data.update({"_id": record_id})
    assert initial_data == inserted_record
    updated_data = {"name": "Nishant1", "address": "Ameerpeth"}
    DBHandler.update(TEST_DB, TEST_COLLECTION, {"_id": record_id},
                       updated_data)
    updated_record = DBHandler.find_one(TEST_DB, TEST_COLLECTION, {"_id":
                                                                     record_id}
                                          )
    initial_data.update(updated_data)
    assert updated_record == initial_data

    print("Delete the record entered")
    DBHandler.remove(TEST_DB, TEST_COLLECTION, {"_id": record_id})
    assert not [e for e in DBHandler.find(TEST_DB, TEST_COLLECTION,
                                            {"_id": record_id})]
def test_basic_operations():
    initial_data = {'service':'nlp_microservice','rule':{'run': 'replace','all':[{'m':{'$mt':{'subject': '.*AB.*'}}}]}}
    print("Insert New conneciton to Table")
    record_id = DBHandler.insert(TEST_DB, TEST_COLLECTION,
                                 initial_data)
    inserted_record = DBHandler.find_one(TEST_DB, TEST_COLLECTION,
                                         {"_id": record_id})
    assert inserted_record
    initial_data.update({"_id": record_id})
    assert initial_data == inserted_record
    updated_data = {'service':'nlp_microservice1'}
    DBHandler.update(TEST_DB, TEST_COLLECTION, {"_id": record_id},
                     updated_data)
    updated_record = DBHandler.find_one(TEST_DB, TEST_COLLECTION, {"_id":
                                                                       record_id}
                                        )
    initial_data.update(updated_data)
    assert updated_record == initial_data

    print("Delete the record entered")
    DBHandler.remove(TEST_DB, TEST_COLLECTION, {"_id": record_id})
    assert not [e for e in DBHandler.find(TEST_DB, TEST_COLLECTION,
                                          {"_id": record_id})]
test_basic_operations()
def test_insert_embedded_document():
    db = DBHandler.get_db(TEST_DB)
    db.contact.remove()
    db.dudes.remove()
    doc_1 = {"address": "memorial park", "phone": "555"}
    db.contact.insert(doc_1)
    c1 = DBHandler.find_one(TEST_DB, "contact", {"phone": "555"})
    print("object_id")
    print(c1['_id'])
    doc_2 = {"name": "dude1", "contact": DBRef(collection = "contact", id = c1["_id"]),}
    DBHandler.update(TEST_DB, "dudes", {"name": "dude1"}, doc_2)
    # db.dudes.upsert({"name": "dude1"}, doc_2)
    dude1 = DBHandler.find_one(TEST_DB, "dudes", {"name": "dude1"})
    c = db.dereference(dude1['contact'])
    assert c['phone'] == "555"

    DBHandler.update(TEST_DB, "dudes", {"name": "dude1"}, {"age": 22})
    updated_dude1 = DBHandler.find_one(TEST_DB, "dudes", {"name": "dude1"})
    assert updated_dude1['age'] == 22

    db.contact.remove()
    db.dudes.remove()


def test_map_reduce():
    # '''
    # Open a connection to MongoDb (localhost)
    mdb = DBHandler()
    db = mdb.get_db(TEST_DB)

    # Insert the data
    lines = ["nation nation nation."]
    [mdb.update(db_name="test_db", collection_name="test_collection", find_query={"text": line},
                update_query={"text": line, "mpr": 1}) for line in lines]

    # Load map and reduce functions
    wordmapjs = """
    function wordMap(){

        //find words in the document text
        if (this.mpr != 1) {
            return;
        }

        var words = this.text.match(/\w+/g);

        if (words == null){
            return;

        }


        for (var i = 0; i < words.length; i++){
            //emit every word, with count of one
            emit(words[i], {count: 1});

        }

    }
    """

    wordreducejs = """
    function wordReduce(key,values){

        var total = 0;
        for (var i = 0; i < values.length; i++){
            total += values[i].count;

        }

        return {count: total};


    }
    """

    map = Code(wordmapjs)
    reduce = Code(wordreducejs)

    # Run the map-reduce query
    results = db.get_collection(TEST_COLLECTION).inline_map_reduce(map=map, reduce=reduce, full_response=True)

    # Print the results
    for result in results['results']:
        if result['_id'] == 'nation':
            assert result['value']['count'] == 3