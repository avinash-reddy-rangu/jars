#! /usr/bin/env python

from setuptools import setup, find_packages

# from xpms-common import __version__ as version
description = ''
history = ''
with open('HISTORY.rst') as f:
    history = f.read()

description = 'Python Common utilities for XPMS - 1.GetsEndpoints,\
                 2.DbUri, 3.logging to logstash'

setup(
        name='xpms-common',
        version='2.3.0',
        description='{0}\n\n{1}'.format(description, history),
        author='PLATFORMTEAM',
        author_email='mayankt@xpms.io',
        url='https://gitlab.com/xp1/xpms-common.git',
        # packages=find_packages('xpms-common', exclude=["test"]),
        packages=['xpms_common'],
        license='na',
        # install_requires=['python-logstash','logging']
        install_requires=['jsonschema==2.6.0','requests==2.18.1','itsdangerous==0.24','Werkzeug==0.12.2','Jinja2==2.9.6','kombu==4.1.0','','Flask==0.12.2','pymongo==3.4.0','redis==2.10.5','python-logstash', 'pika==0.10.0', 'redis==2.10.5',
                          'elasticsearch==5.1.0', 'pytest==3.0.7','pytz==2016.7','iso8601==0.1.11','boto3==1.4.4','celery==4.1.0','botocore==1.5.76', 'cassandra-driver==3.11', 'python-consul==0.7.2']
)
