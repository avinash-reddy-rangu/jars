1.0.6 ( Fig Sprint)
released 2016-09-27

Initial package after development.


1.0.7
released 2017-02-10

changes in logger


1.0.8
released 2017-02-14

added dispatcher, listener(queue), common exceptions

2.0.0
released 2017-04-10

refactored, addition of errors by Nishant Saxena, addition of mq_consumer, mq_publisher by Jayanth

2.1.0
released 2017-06-18

2.2.0
released 2017-07-31

refactored mq_consumer and mq_publisher

2.3.0
released

storage, logging, cache and db classes now generic; support for both old and new consumers; depricated elastic search connection, consulutils, added celery app; updated s3 handler, redis cache handler

