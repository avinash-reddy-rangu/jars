############### Steps for building the package #################

1) Run test cases  : run test cases using the command, "PYTHONPATH=#pathoftherespository py.test test" , you would require environment variables set for the connected vpn
2) Update setup files : update setup.py with any additional requirements, update version, history(from history.rst file) if required
3) Create distributary : Run command "python setup.py sdist" (should be run by gocd pipeline as well)





################################################################


# XPMS COMMON

## Description
XPMS COMMON is a common functions lib for the platform.
It contains the following:
  - Errors, a module containing custom errors, its recommended but optional to pass traceback and error message
  - DB Handler, common methods of insert, find, update and delete for mongo db and cassandra, but its recommended to use your the specific client property and write your own code for any specific need
  - Storage handler, with common methods for storage and retrieval for files/objects from s3/efs
  - Mq consumer-publisher, these classes can be inherited for communicating with rabbitmq
  - Cache handler, with common methods for storage and retrieval for key/value pairs from Redis
  - ls_logger, logging module
  - ConsulHandler, provides method for service discovery

## Modules

### 1. Errors
Contains custom errors derived from base class XPMSERROR.
##### Usage
On the event of an exception being caught, they can be reraised as platform specific errors. Error message and traceback can be passed with the error constructor. Can be caught together with the base class
 Example:
 ```sh
try:
    storage_path = os.environ["SHARED_VOLUME"]
except KeyError as e:
    error_message = "key SHARED_VOLUME not found in environment variables"
    tb = traceback.format_exc()
    raise MissingEnvVar(error_message, traceback=tb)
```
### 2. DB Handler
Common methods of insert, find, update and delete for mongo db and cassandra, but its recommended to use your the specific client property and write your own code for any specific need.

##### Usage
 currently supports mongodb and cassandra, one can get wrappers for standard operations on them using the get_instance method. One can get respective clients/connections if custom operations/queries are required using the get_client method.
  ```sh
from xpms_common.db_handler import DBHandler, get_instance, get_client

cassandra_wrapper = get_instance('CASSANDRA')
mongo_wrapper = get_instance('MONGODB')
cassandra_client = get_client('CASSANDRA')
mongo_client = get_client('MONGODB')

# gets default database wrapper based on "DATABASE" environment variable
default_db_wrapper = DBHandler

```

 ##### Environment variables
 DATABASE(optional, values: MONGODB/CASSANDRA)(1)


if DATABASE value is MONGODB
- DB_MAXPOOL_MONGO(optional, default=20)(2)
- DB_MINPOOL_MONGO(optional, default=2)(3)
- DB_USERID_MONGO(optional, default=admin)(4)
- DB_PASSWORD_MONGO(optional, default=password)(5)
- DB_HOST_MONGO(optional, default=localhost)(6)
- DB_PORT_MONGO(optional, default=27017)(7)
- DB_AUTH_NM_MONGO(optional, default=admin)(8)

if DATABASE value is CASSANDRA
- DB_HOST_CASSANDRA(optional, default=localhost)(9)


### 3. Storage handler
Common methods of upload, download and deletion of files and objects for s3 and efs.

##### Usage
currently supports s3 and efs, one can get wrappers for standard operations on them using the get_instance method.
  ```sh
from xpms_common.storage_handler import StorageHandler, get_instance

s3_wrapper = get_instance('S3')


# gets default database wrapper based on "STORAGE" environment variable (S3)
default_storage_wrapper = StorageHandler

```

##### Environment variables
STORAGE(optional, values:S3/efs)(10)

S3
-  S3_MAX_POOL(optional, default=30)(11)
-  AMAZON_AWS_REGION(not required if ec2 instance is provided an access role for s3, default=None)(12)
-  AMAZON_AWS_KEY(not required if ec2 instance is provided an access role for s3, default=None)(13)
-  AMAZON_AWS_SECRET_KEY(not required if ec2 instance is provided an access role for s3, default=None)(14)

efs
-  SHARED_VOLUME(optional, default=None)(15)

 ### 4. Cache Handler
Contains Generic methods of get and set for redis (with a parameter timeout) , but its recommended to use your the specific client using the get_client method and write your own code for any specific need.

##### Usage
 currently supports redis, one can get wrappers for standard operations on them using the get_instance method. One can get respective clients/connections if custom operations/queries are required using the get_client method.
  ```sh
from xpms_common.cache_handler import CacheHandler, get_instance, get_client

redis_wrapper = get_instance('REDIS')
redis_wrapper.set("name",{"name":""},timeout = 400)
redis_wrapper.set("name2",{"name":""},set_timeout = False)
name_json = redis_wrapper.get_json_value("name")

redis_client = get_client('REDIS')

# gets default database wrapper based on "CACHE_SERVER" environment variable (REDIS)
default_cache_wrapper = CacheHandler

```

##### Environment variables
CACHE_SERVER(optional, values:Redis)(16)

if CACHERedis
-  REDIS_HOST(optional, default=localhost)(17)
-  REDIS_NOAUTH_PORT(optional, default=6379)(18)
-  REDIS_MAX_CONNECTIONS(optional, default=20)(19)

### 5. consul_util - api discovery service
    required envvars
        export CONSUL_HOST=10.0.1.112
        export CONSUL_PORT=8500
#####Usage:
```sh
from xpms_common import ConsulHandler
ConsulHandler.discover_service('deep-srl')
{'service_port': 32891, 'service_host': '10.0.1.88', 'status': {'success': True, 'code': 200, 'msg': ''}}
# service not found
ConsulHandler.discover_service('deep-sro')
{'service_port': '', 'service_host': '', 'status': {'success': False, 'code': 400, 'msg': 'Service not found'}}
# consul host not found
ConsulHandler.discover_service('deep-srl', host='localhost')
{'service_port': '', 'service_host': '', 'status': {'success': False, 'code': 500, 'msg': "Couldn't connect to Consul with host=localhost, port=8500"}}
```

### 6. ls_logger
currently supports  logstash or local logging set by env variable

local logger env configurations
    export LOGGER=DEFAULT


logstash env configurations
    export LOGGER=LOGSTASH
    export LOGSTASH_HOST=10.0.1.19
    export LOGSTASH_PORT=19000
    export LOGSTASH_LOG_LEVEL=info

##### Usage

  ```sh
from xpms_common import ls_logger
import traceback
try:
    ...
except:

    tb = traceback.format_exec()
    ls_logger.log_message(ls_logger.LogConfig("learning_service", "data_handler"),
                              {"message": "error while loading the dataset", "error_message": str(e),
                               "traceback": tb}, message,
                              method_name=str(inspect.stack()[0][3]))

    #without LogConfig
    ls_logger._log_("learning_service", "data_handler",
                              {"message": "error while loading the dataset", "error_message": str(e),
                               "traceback": tb}, message,
                              method_name=str(inspect.stack()[0][3]),**{"any_other_info":{},"":{}})
```







## Environment varibales per module

### DB Handler

###### DATABASE(optional, values: MONGODB/CASSANDRA)(1)


MONGODB
- DB_MAXPOOL_MONGO(optional, default=20)(2)
- DB_MINPOOL_MONGO(optional, default=2)(3)
- DB_USERID_MONGO(optional, default=admin)(4)
- DB_PASSWORD_MONGO(optional, default=password)(5)
- DB_HOST_MONGO(optional, default=localhost)(6)
- DB_PORT_MONGO(optional, default=27017)(7)
- DB_AUTH_NM_MONGO(optional, default=admin)(8)

CASSANDRA
- DB_HOST_CASSANDRA(optional, default=localhost)(9)

### Storage Handler

###### STORAGE(optional, values:S3/efs)(10)

S3
-  S3_MAX_POOL(optional, default=30)(11)
-  AMAZON_AWS_REGION(not required if ec2 instance is provided an access role for s3, default=None)(12)
-  AMAZON_AWS_KEY(not required if ec2 instance is provided an access role for s3, default=None)(13)
-  AMAZON_AWS_SECRET_KEY(not required if ec2 instance is provided an access role for s3, default=None)(14)

efs
-  SHARED_VOLUME(optional, default=None)(15)

### Cache Handler(optional, values:Redis)(16)

Redis
-  REDIS_HOST(optional, default=localhost)(17)
-  REDIS_NOAUTH_PORT(optional, default=6379)(18)
-  REDIS_MAX_CONNECTIONS(optional, default=20)(19)

### Mq consumer,Mq publisher(variables required only if used)
EX_HOST_QUEUE(not optional, default=None)(20)
EX_PORT_QUEUE(not optional, default=None)(21)
EX_PASSWORD_QUEUE(not optional, default=None)(22)
EX_USERID_QUEUE(not optional, default=None)(23)
MESSAGE_EXCHANGE(not optional, default=None)(24)
DEFAULT_ROUTING_KEY(optional, default=all.data)(25)

### ConsulHandler(variables required only if used)
EX_HOST_QUEUE(not optional, default=None)(26)
EX_HOST_QUEUE(not optional, default=None)(27)




### ls_logger - class for storing storage requests

Currently supports  logstash or local logging set by env variable
    LOGGER(not optional, default=None, values: LOGSTASH/DEFAULT)(28)

    local logger env configurations
        export LOGGER=DEFAULT


    logstash env configurations
        export LOGGER=LOGSTASH
        export LOGSTASH_HOST=10.0.1.19
        export LOGSTASH_PORT=19000
        export LOGSTASH_LOG_LEVEL=info

consul_util - api discovery service

    export CONSUL_HOST=10.0.1.112
    export CONSUL_PORT=8500
