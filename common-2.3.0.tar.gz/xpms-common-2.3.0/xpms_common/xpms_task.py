from celery import Task
from xpms_common.connections import fork_reset

class XpmsTask(Task):
    """XpmsTask requests task class."""

    abstract = True


    def __init__(self):
        # since this class is instantiated once, use this method
        # to initialize and cache resources like a requests.session
        # or use a property like the example below which will create
        # a requests.session only the first time it's accessed
        fork_reset()