import consul
import os
import re

class ConsulHandler:
    @staticmethod
    def discover_service(service_name, host=None, port=None, regex=False):
        service_host = ""
        service_port = ""
        status = dict(success=False, code=500, msg="")
        if host is None:
            host = os.getenv('CONSUL_HOST')
        if port is None:
            port = os.getenv('CONSUL_PORT')

        try:
            c = consul.Consul(host=host, port=port)
            if regex is True:
                services = list(c.catalog.services()[1].keys())
                r = re.compile(service_name)
                matches = list(filter(r.search, services))
                if len(matches) < 1:
                    status['success'] = False
                    status['code'] = 400
                    status['msg'] = "Service not found"
                    return dict(status=status, service_host=service_host, service_port=service_port)
                else:
                    service_name = matches[0]
            index, data = c.catalog.service(service_name)
            if len(data) > 0:
                service_host = data[-1]['ServiceAddress']
                service_port = data[-1]['ServicePort']
                status['success'] = True
                status['code'] = 200
            else:
                status['success'] = False
                status['code'] = 400
                status['msg'] = "Service not found"
        except Exception:
            status['msg'] = "Couldn't connect to Consul with host={0}, port={1}".format(host, port)

        return dict(status=status, service_host=service_host, service_port=service_port)