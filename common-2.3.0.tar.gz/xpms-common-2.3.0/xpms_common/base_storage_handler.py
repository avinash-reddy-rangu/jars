class BaseStorageHandler:
    @staticmethod
    def fork_reset():
        raise NotImplementedError()

    @staticmethod
    def thread_reset():
        raise NotImplementedError()

    @staticmethod
    def initialize():
        raise NotImplementedError()

    @staticmethod
    def upload_object(server_file_path, server_file_name, object):
        raise NotImplementedError()

    @staticmethod
    def upload_file(upload_file_path,server_file_path, server_file_name):
        raise NotImplementedError()

    @staticmethod
    def download_object(server_file_path, server_file_name):
        raise NotImplementedError

    @staticmethod
    def download_file(download_file_path,server_file_path, server_file_name):
        raise NotImplementedError

    @staticmethod
    def get_file_url(server_file_path, server_file_name):
        raise NotImplementedError()

    @staticmethod
    def delete(server_file_path, server_file_name):
        raise NotImplementedError()