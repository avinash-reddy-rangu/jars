'''
Author: Nishant 20-Mar-2017
    This module is used to create mongo connections using following


    And provide the methods for all mongo operations.
'''

from pymongo import MongoClient
import os
from builtins import staticmethod
from copy import deepcopy
import traceback
from xpms_common.errors import InternalError, MissingEnvVar
from xpms_common.utils import get_env
# from xpms_common import ls_logger
import inspect

MongoDBConn = None


#If your user is defined in one database with a role that gives it authorization on a different database use the source option(or auth source) to specify the database in which the user is defined
#refer http://api.mongodb.com/python/current/examples/authentication.html
# http://api.mongodb.com/python/current/faq.html

MONGO_CLIENT =None


class MongoDbConn:
    @staticmethod
    def fork_reset():
        MongoDbConn.initialize()

    @staticmethod
    def thread_reset():
        return

    @staticmethod
    def reset():
        MongoDbConn.initialize()

    @staticmethod
    def initialize():
        try:

            global MONGO_CLIENT
            max_pool_size = int(get_env("DB_MAXPOOL_MONGO", "20", False))
            min_pool_size = int(get_env("DB_MINPOOL_MONGO", "2", False))
            username = get_env("DB_USERID_MONGO", "admin", False)
            password = get_env("DB_PASSWORD_MONGO", "password", False)
            host = get_env("DB_HOST_MONGO", "localhost", False)
            port = get_env("DB_PORT_MONGO", "27017", False)
            source_db = get_env("DB_AUTH_NM_MONGO", "admin", False)
            microservice_name = get_env("PROJECT_NAME", "unknown", True)


            # max_pool_size = 20
            settings_mongo = {
            'username': username,
            'password': password,
            'host': host + ":" +
                    port,
            'source_database': source_db
            }
            MONGO_CLIENT = \
            MongoClient("mongodb://{username}:{password}@"
                        "{host}/?authSource={source_database}".format(
                **settings_mongo),maxPoolSize=max_pool_size,minPoolSize=min_pool_size)
        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            # ls_logger.log_error(ls_logger.LogConfig(microservice_name, MongoDbConn.__name__),
            #                     {"error_message": error_message, "traceback": tb}, {},
            #                     method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def  get_db(db_name):
        db = MONGO_CLIENT[db_name]
        return db

    @staticmethod
    def get_server_info():
        return MONGO_CLIENT.server_info()

    @staticmethod
    def execute_operation(db_name, collection_name, find_query,
                          operation,  secondary_query=None, map=None, reduce=None):
        assert operation in ["insert", "find", "find_one", "update", "distinct", "remove", "map_reduce", "count"]

        db = MONGO_CLIENT[db_name]
        collection = db[collection_name]
        if operation == "update":
            if '$set' not in secondary_query:
                secondary_query = {"$set": secondary_query}
            return getattr(collection, operation)(find_query, secondary_query, upsert=True, multi=True)
        elif operation == "map_reduce":
            return getattr(collection, operation)(map, reduce, {"inline": True})
        elif operation in ["find_one", "find"]:
            if secondary_query is not None:
                return getattr(collection, operation)(find_query, secondary_query)
            else:
                return getattr(collection, operation)(find_query)
        elif operation in ["delete", "remove"]:
            return getattr(collection, operation)(find_query)
        else:
            return getattr(collection, operation)(find_query,check_keys=False)

    @staticmethod
    def count(db_name, collection_name, find_query):
        return MongoDbConn.execute_operation(db_name, collection_name,find_query, operation="count")

    @staticmethod
    def find_one(db_name, collection_name, find_query, projection_fields=None):
        return MongoDbConn.execute_operation(db_name, collection_name,
                                             find_query, operation="find_one", secondary_query=projection_fields)

    @staticmethod
    def find(db_name, collection_name, find_query, projection_fields=None):
        return MongoDbConn.execute_operation(db_name, collection_name,
                                             find_query, operation="find", secondary_query=projection_fields)

    @staticmethod
    def remove(db_name, collection_name, find_query):
        return MongoDbConn.execute_operation(db_name, collection_name,
                                             find_query, operation="remove")

    @staticmethod
    def insert(db_name, collection_name, find_query):
        return MongoDbConn.execute_operation(db_name, collection_name,
                                             find_query, operation="insert")

    @staticmethod
    def update(db_name, collection_name, find_query, update_query):
        return MongoDbConn.execute_operation(db_name, collection_name,
                                             find_query, operation="update",
                                             secondary_query=update_query)

    @staticmethod
    def map_reduce(db_name, collection_name, map, reduce):
        return MongoDbConn.execute_operation(db_name, collection_name,
                                             find_query=None, operation="map_reduce",
                                             secondary_query=None, map=map,
                                             reduce=reduce)


    @staticmethod
    def create_mongo_query(query_json):
        #temporary method for simplest query creation
        new_query = {}
        for property in query_json:
            property_name = property
            value = query_json[property]
            if isinstance(value,dict):
                inner_elements = MongoDbConn.create_mongo_query(value)
                for element in inner_elements:
                    new_query[property_name+"."+element] = inner_elements[element]
            else:
                new_query[property_name] = value
        return new_query

    @staticmethod
    def clean_json(json_obj):
        if isinstance(json_obj, str):
            return json_obj
        elif isinstance(json_obj, dict):
            to_delete = []
            to_update = {}
            updated_template = deepcopy(json_obj)
            for element in json_obj:
                value = MongoDbConn.clean_json(json_obj[element])
                element_parts = element.split(".")
                if len(element_parts) > 1:
                    to_delete.append(element)
                    temp_template = updated_template
                    prev_template = temp_template
                    element_part = None
                    for element_part in element_parts:
                        prev_template = temp_template
                        if element_part not in temp_template:
                            temp_template[element_part] = {}
                        temp_template = temp_template[element_part]
                    if element_part:
                        prev_template[element_part] = value
                else:
                    updated_template[element] = value
            for element in to_delete:
                updated_template.pop(element)
            return updated_template
        elif isinstance(json_obj, list):
            new_template = []
            for val in json_obj:
                new_template.append(MongoDbConn.clean_json(val))
            return new_template
        return json_obj

# if __name__ == '__main__':
#     mdb = MongoDbConn()
#     print(mdb.insert('test_db', 'test_collection', {}))
#     print(mdb.find_one('test_db', 'test_collection', {}))
