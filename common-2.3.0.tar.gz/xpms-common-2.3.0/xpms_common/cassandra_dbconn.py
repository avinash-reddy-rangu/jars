
from cassandra.cluster import Cluster, NoHostAvailable
import json
import uuid
from xpms_common.errors import InternalError, InvalidUsageError
from datetime import datetime
import os
from copy import deepcopy
from xpms_common.utils import get_env
# from xpms_common import ls_logger
# from xpms_common.ls_logger import LogConfig

# log_config = LogConfig("xpms-common", __name__)


def format_time():
    dt = datetime.utcnow()
    t = dt.replace(microsecond=0).isoformat()
    return t


class OperationFailureCassandra(Exception):

    def __init__(self, error):
        Exception.__init__(self, error)


class Cassandra:

    @staticmethod
    def fork_reset():
        return

    @staticmethod
    def thread_reset():
        return

    @staticmethod
    def reset():
        return

    def __init__(self, keyspace, contact_points=None):

        try:
            if not contact_points:
                contact_points = [get_env("DB_HOST_CASSANDRA", "localhost", False)]

            self.cluster = Cluster(contact_points=contact_points)
            self.keyspace = keyspace
            self.session = self.cluster.connect(self.keyspace)

            # ls_logger.log_message(log_config, {"message": "Established connection to " + self.keyspace}, {'Host': contact_points}, 'cassandra_init')

        except NoHostAvailable:
            # ls_logger.log_message(log_config, {"message": 'No Host Available'}, {"keyspace" : keyspace}, 'cassandra_init')

            raise OperationFailureCassandra('Unable to establish connection with database')


    def get_session(self):
        return self.session


    def get_column_names(self, table):

        def format_result(result):

            formated = []
            for res in result:
                formated.append(json.loads(res[0])['column_name'])

            return formated

        try:
            get_columns = (
            'SELECT JSON column_name FROM system_schema.columns WHERE keyspace_name = \'{0}\' AND table_name = \'{1}\'').format(
                self.keyspace, table)
            names = self.session.execute(get_columns)
            names = format_result(names)

            # ls_logger.log_message(log_config, {"message": "Got columns for " + table}, {"names": names}, 'cassandra_get_columns')
            return names

        except Exception as e:
            # ls_logger.log_message(log_config, {"message": e}, {}, 'cassandra_alter_table')

            raise OperationFailureCassandra('DB operation failed while getting column name')


    def alter_table(self, command, table, column_name, type=None):

        try:
            if command == 'ADD' and type:
                alter = 'ALTER TABLE {0} {1} {2} {3}'.format(table, command, column_name, type)
                self.session.execute(alter)
            elif command == 'DROP':
                alter = 'ALTER TABLE {0} {1} {2}'.format(table, command, column_name)
                self.session.execute(alter)
            else:
                raise InvalidUsageError('Invalid command to alter table')

            # ls_logger.log_message(log_config, {"message": "Added column {0} in table {1}".format(column_name, table)}, {"alter_table_command": command}, 'cassandra_get_columns')

        except Exception as e:
            # ls_logger.log_message(log_config, {"message": e}, {"alter_table_command":command}, 'cassandra_alter_table')

            raise OperationFailureCassandra('DB operation failed while altering table')


    def insert(self, table, data):

        def format_data(data):

            for key in data.keys():
                if isinstance(data[key], str):
                    data[key] = data[key].translate(str.maketrans({"'": r"''"}))

            return data

        try:
            column_names = self.get_column_names(table)
            data_copy = deepcopy(data)
            for key in data.keys():
                if key not in column_names:
                    if isinstance(data[key], dict):
                        self.alter_table(command='ADD', table=table, column_name=key, type='map<text, float>')
                    elif isinstance(data[key], str):
                        self.alter_table(command='ADD', table=table, column_name=key, type='text')
                    elif isinstance(data[key], bool):
                        self.alter_table(command='ADD', table=table, column_name=key, type='boolean')
                    else:
                        data_copy.pop(key)


            data_copy = format_data(data_copy)
            insert = 'INSERT INTO {0} JSON \'{1}\''.format(table, json.dumps(format_data(data_copy)))
            self.session.execute(insert)

            # ls_logger.log_message(log_config, {"message": "Inserted data in " + table}, {"data":data_copy}, 'cassandra_insert')

        except Exception as e:

            # ls_logger.log_message(log_config, {"message": e}, {"data": data}, 'cassandra_insert')

            raise OperationFailureCassandra('DB operation failed while inserting row')


    def find(self, table, filter_obj, allow_filtering=False, limit=None):

        def format_result(result):

            formatted = []
            for res in result:
                formatted.append(json.loads(res[0]))

            return formatted

        try:
            query = 'SELECT JSON * FROM {0} WHERE '.format(table)

            first = True
            for key in filter_obj.keys():
                if first:
                    first = False
                    if isinstance(filter_obj[key], uuid.UUID) or isinstance(filter_obj[key], int):
                        query = query + key + '=' + str(filter_obj[key])
                    elif isinstance(filter_obj[key], dict):
                        query = query + key + '=' + json.dumps(filter_obj[key]).replace('"','\'')
                    else:
                        query = query + key + '=' + '\'' + filter_obj[key] + '\''
                else:
                    if isinstance(filter_obj[key], uuid.UUID) or isinstance(filter_obj[key], int):
                        query = query + ' AND ' + key + '=' + str(filter_obj[key])
                    elif isinstance(filter_obj[key], dict):
                        query = query + ' AND ' + key + '=' + json.dumps(filter_obj[key]).replace('"','\'')
                    else:
                        query = query + ' AND ' + key + '=' + '\'' + filter_obj[key] + '\''

            # adding limit on number of fetched rows
            if limit:
                query = query + ' limit {0}'.format(limit)

            # allow filtering should come in the end
            if allow_filtering:
                query = query + ' allow filtering'

            result = self.session.execute(query)
            result = format_result(result)

            # ls_logger.log_message(log_config, {"message": "Found data in " + table}, {"result":result}, 'cassandra_find')
            return result

        except Exception as e:

            raise OperationFailureCassandra('DB operation failed while finding row(s) in table')


    def delete(self, table, filter_obj):

        try:
            query = 'DELETE FROM {0} WHERE '.format(table)

            first = True
            for key in filter_obj.keys():
                if first:
                    first = False
                    if isinstance(filter_obj[key], uuid.UUID) or isinstance(filter_obj[key], int):
                        query = query + key + '=' + str(filter_obj[key])
                    elif isinstance(filter_obj[key], dict):
                        query = query + key + '=' + json.dumps(filter_obj[key]).replace('"','\'')
                    else:
                        query = query + key + '=' + '\'' + filter_obj[key] + '\''
                else:
                    if isinstance(filter_obj[key], uuid.UUID) or isinstance(filter_obj[key], int):
                        query = query + ' AND ' + key + '=' + str(filter_obj[key])
                    elif isinstance(filter_obj[key], dict):
                        query = query + ' AND ' + key + '=' + json.dumps(filter_obj[key]).replace('"','\'')
                    else:
                        query = query + ' AND ' + key + '=' + '\'' + filter_obj[key] + '\''

            self.session.execute(query)
            #todo do we need to log? logging of uuid causing error

        except Exception as e:

            raise OperationFailureCassandra('DB operation failed while deleting row')


    def shutdown(self):
        self.cluster.shutdown()
        raise InternalError("Cluster shut down " + self.keyspace)
        # ls_logger.log_message(log_config, {"message": "Cluster shut down " + self.keyspace}, {}, 'cassandra_cluster_shutdown')








