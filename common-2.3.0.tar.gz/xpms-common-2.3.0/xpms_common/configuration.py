import os
from xpms_common.db_handler import DBHandler
from xpms_common.event import Event
from xpms_common.errors import *
from xpms_common.utils import get_env
from xpms_common import ls_logger
import traceback


class Configuration():
    instance = None
    update_config_event = Event()
    event_handlers = []
    #on_update_event
    @staticmethod
    def register_update_config_event(on_update_function, function_tag):
        #todo validations of on update event, function_tag
        if not isinstance(function_tag,str):
            raise InvalidUsageError("function_tag should be a string")
        Configuration.update_config_event.append(on_update_function)
        Configuration.event_handlers.append(function_tag)
    @staticmethod
    def unregister_update_config_event(on_update_function):
        #todo validations of on update event, function_tag

        Configuration.update_config_event.remove(on_update_function)
    def __init__(self):
        self.get_config_from_store()

    @staticmethod
    def load_config(database, collection):
        if database is None: database = get_env("CONFIG_DB", "localhost", False)
        if collection is None: collection = get_env("CONFIG_COLL", "27017", False)
        config = {}
        configs = DBHandler.find(database,collection,{})
        for conf in configs:
            if "is_deleted" in conf and conf["is_deleted"] == True:
                continue
            if "solution_id" not in conf:
                config["default_solution_id"] = conf
            else:
                config[conf["solution_id"]] = conf
        if not config:
            config = {}
        return config

    def get_config_from_store(self, database=None, collection=None):
        if database is None: database = get_env("CONFIG_DB", "localhost", False)
        if collection is None: collection = get_env("CONFIG_COLL", "27017", False)
        config = {}
        configs = DBHandler.find(database,collection,{})
        for conf in configs:
            if "is_deleted" in conf and conf["is_deleted"] == True:
                continue
            if "solution_id" not in conf:
                config["default_solution_id"] = conf
            else:
                config[conf["solution_id"]] = conf
        if not config:
            config = {}
        Configuration.instance = config

    @staticmethod
    def get_instance():
        if Configuration.instance is None:
            Configuration()
        return Configuration.instance

    @staticmethod
    def process(self,data):
        if Configuration.instance is None:
            Configuration()
        #run
        #value
        return ""

    @staticmethod
    def update_configuration(config_data, solution_id, compress_query = True):
        database = get_env("CONFIG_DB", "localhost", False)
        collection = get_env("CONFIG_COLL", "27017", False)
        if compress_query:
            config_data = DBHandler.create_mongo_query(config_data)
        if "_id" in config_data:
            DBHandler.update(database, collection,{"_id": config_data["_id"]}, config_data)
        else:
            DBHandler.update(database, collection, {"solution_id":solution_id}, config_data)

        #to update configuration variable in memory
        Configuration()

        #call update configuration events
        Configuration.update_config_event(solution_id,config_data)

    @staticmethod
    def delete_configuration(solution_id):
        if solution_id not in Configuration.get_instance():
            raise InternalError("configuration doesnt exist")
        database = get_env("CONFIG_DB", "localhost", False)
        collection = get_env("CONFIG_COLL", "27017", False)
        config_data = Configuration.get_instance()

        DBHandler.update(database, collection, {"solution_id": solution_id}, {"is_deleted":True})
        # to update configuration variable in memory
        Configuration()

