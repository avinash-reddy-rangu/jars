

class Hasher():
    @staticmethod
    def hash_primary_key(json_key, prefix = ""):
        key = prefix
        if isinstance(json_key, str):
            return key + prefix
        if isinstance(json_key, dict):
            keys = list(json_key.keys())
            keys.sort()
            for k in keys:
                if isinstance(json_key[k], str):
                    key = key + json_key[k]
        return key