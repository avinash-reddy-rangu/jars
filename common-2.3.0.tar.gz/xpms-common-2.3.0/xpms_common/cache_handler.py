
from xpms_common.utils import get_env

microservice_name = get_env("PROJECT_NAME", "unknown", True)

CACHE_SERVER = get_env("CACHE_SERVER", "unknown", False)

Cache_handlers = dict()
Clients = dict()

CACHE_HANDLER = None

if CACHE_SERVER == "REDIS":
    from xpms_common.redis_handler import RedisHandler as CacheHandler

    CacheHandler.initialize()
else:
    CacheHandler = None


def get_instance(cache_name, refresh=False):
    """
    gets instance of wrapper for the mentioned cache_name, currently support redis
    :param cache_name: cache to be used, options : 'REDIS'
    :param refresh: same copy of the instance is used unless refreshed( resets the connection)
    :return: cache handler wrapper
    """
    if cache_name in Cache_handlers and not refresh:
        return Cache_handlers[cache_name]
    if cache_name == "REDIS":
        from xpms_common.redis_handler import RedisHandler as CacheHandler
        Cache_handlers[cache_name] = CacheHandler.initialize()
        return Cache_handlers[cache_name]
    return None


def get_client(cache_name, refresh=False):
    """
    gets instance of client for the mentioned cache_name, currently support redis
    :param cache_name: cache to be used, options : 'REDIS'
    :param refresh: same copy of the client instance is used unless refreshed( resets the connection)
    :return: client wrapper
    """
    if cache_name in Cache_handlers and not refresh:
        return Clients[cache_name]
    if cache_name == "REDIS":
        from xpms_common.redis_handler import RedisHandler as CacheHandler
        CacheHandler.initialize()
        from xpms_common.redis_handler import CACHE_SERVER
        Clients[cache_name] = CACHE_SERVER
        return Clients[cache_name]
    return None


if __name__ == "__main__":
    pass
