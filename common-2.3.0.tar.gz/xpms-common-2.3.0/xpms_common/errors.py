


class XpmsError(Exception):
    """Base error class for all xpms microservices."""
    status_code = 400

    def __init__(self, message,traceback="", status_code=None, payload=None):
        """
        Base class initialization
        :param message: message related to the exception
        :param status_code: status code of the exception, in sync with web
        status codes
        :param payload: any payload associated
        """
        Exception.__init__(self)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.traceback = traceback
        self.payload = payload

    def to_dict(self):
        rv = dict(self.payload or ())
        rv['message'] = self.message
        return rv


class InvalidUsageError(XpmsError):
    """
    invalid usage error, code 400
    """
    status_code = 405


class RequestTimeoutError(XpmsError):
    """
    request timeout error, code 408
    """
    status_code = 408


class ValidationError(XpmsError):
    """
    Validation error, code 400
    """
    status_code = 400


class AuthenticationError(XpmsError):
    """
    Error authenticating request, code 401
    """
    status_code = 401


class ForbiddenError(XpmsError):
    """
    Forbidden error, code 403
    """
    status_code = 403


class ServiceUnavailableError(XpmsError):
    """
    Service unavailable error, code 503
    """
    status_code = 503


class InternalError(XpmsError):
    """
    internal error , code 500
    """
    status_code = 500

class EntityNotFoundError(XpmsError):
    """
    internal error , code 500
    """
    status_code = 500

class PlatformConfigurationError(XpmsError):
    """
    internal error , code 500
    """
    status_code = 500

class SourceTemplateNotFoundError(XpmsError):
    """
    internal error , code 500
    """
    status_code = 500
class MissingEnvVar(XpmsError):
    """
       internal error , code 500
       """
    status_code = 500
