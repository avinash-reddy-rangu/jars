
class CacheHandlerBase:

    @staticmethod
    def initialize():
        raise NotImplementedError("you need to implement this before using")
    @staticmethod
    def get_json_value(key):

        raise NotImplementedError("you need to implement this before using")

    @staticmethod
    def set(key, value, timeout=200, set_timeout=True):

        raise NotImplementedError("you need to implement this before using")

    @staticmethod
    def get_raw_value(key):

        raise NotImplementedError("you need to implement this before using")

    @staticmethod
    def set_raw_value(key, value, timeout=200, set_timeout=True):
        raise NotImplementedError("you need to implement this before using")

    @staticmethod
    def delete_keys(keys):
        raise NotImplementedError("you need to implement this before using")