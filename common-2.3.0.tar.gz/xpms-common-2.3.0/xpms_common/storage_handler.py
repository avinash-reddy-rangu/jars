import os
from xpms_common import ls_logger
import traceback
from xpms_common.errors import XpmsError,MissingEnvVar, InvalidUsageError
from xpms_common.base_storage_handler import BaseStorageHandler
from xpms_common.utils import get_env

StorageHandlers = dict()
microservice_name = get_env("PROJECT_NAME","unknown",True)

storage = get_env("STORAGE", "unknown", False)

StorageHandler = None

if storage == "S3":
    from xpms_common.s3_handler import S3Handler as StorageHandler

    StorageHandler.initialize()
elif storage == "efs":
    from xpms_common.efs_handler import EFSHandler as StorageHandler

    StorageHandler.initialize()


def get_instance(storage_name):
    if storage_name in StorageHandlers:
        return StorageHandlers[storage_name]
    if storage_name == "S3":
        from xpms_common.s3_handler import S3Handler
        S3Handler.initialize()
        StorageHandlers[storage_name] = S3Handler
        return StorageHandlers[storage_name]
    elif storage_name == "efs":
        from xpms_common.efs_handler import EFSHandler
        EFSHandler.initialize()
        StorageHandlers[storage_name] = EFSHandler
        return StorageHandlers[storage_name]
    else:
        error_message = "Invalid storage name in env vars"
        tb = traceback.format_exc()
        ls_logger.log_error(ls_logger.LogConfig(microservice_name, "storage_hanlder"),
                            {"error_message": error_message, "traceback": tb}, {},
                            method_name="")
        raise InvalidUsageError(error_message, traceback=tb)


if __name__ == "__main__":
    if storage == "S3":
        from xpms_common.s3_handler import S3Handler as StorageHandler

        StorageHandler.initialize()
    elif storage == "efs":
        from xpms_common.efs_handler import EFSHandler as StorageHandler

        StorageHandler.initialize()