from xpms_common.ls_logger import log_message, log_error, LogConfig
import traceback
from flask import request, jsonify
import json
import pprint

ppp = pprint.PrettyPrinter(indent=4)


def microservice_logger(app, app_name):

    log_config = LogConfig(app_name, app_name)

    @app.before_request
    def before_request():
        if request.data:
            req_missing_msg = "request_id, solution_id all required"
            try:
                request_data = json.loads(request.data.decode("utf-8"))
            except:
                request_data = {
                    "INVALID_JSON": request.data.decode("utf-8")
                    }
            request_id = request_data.get("request_id", "")
            solution_id = request_data.get("solution_id", "")
            if not all([request_id, solution_id]):
                raise Exception(req_missing_msg)

            log_message(log_config, {"method": request.url, "point": "Entry point",
                             "request_id": request_id,
                             "solution_id": solution_id,
                             "request_id": request_id
                             },
                request_data, method_name=request.url)

    @app.after_request
    def after_request(response):
        if request.data:
            if response.status_code == 200:
                try:
                    request_data = json.loads(request.data.decode("utf-8"))
                except:
                    request_data = {
                        "INVALID_JSON": request.data.decode("utf-8")
                        }
                request_id = request_data.get("request_id", "")
                solution_id = request_data.get("solution_id", "")
                response_data = json.loads(response.data.decode("utf-8"))
                log_message(log_config, {"method": request.url,
                                 "point": "Exit point",
                                 "request_id": request_id,
                                 "solution_id": solution_id
                                 },
                    response_data, method_name=request.url)

        return response

    @app.errorhandler(Exception)
    def handle_invalid_usage(error):
        try:
            request_data = json.loads(request.data.decode("utf-8"))
        except:
            request_data = {"INVALID_JSON_ERROR": request.data.decode("utf-8")}

        request_id = request_data.get("request_id", "ERR")
        solution_id = request_data.get("solution_id", "ERR")
        trace = traceback.format_exc()
        try:
            msg = trace.split("\n")[-3].strip()
            try:
                msg = msg.split("\",")[0].strip()
            except:
                pass
        except:
            msg = "Cant parsed"
        ppp.pprint(trace)
        url = request.url
        method = request.method
        error_response = {"trace": trace, "url": url,
                          "method": method,
                          "request_data": request_data}
        log_error(log_config, {"method": request.url,
                               "point": "Error",
                               "request_id": request_id,
                               "solution_id": solution_id
                               },
                  error_response, method_name=request.url)

        response = jsonify(msg)
        response.status_code = 400
        return response
