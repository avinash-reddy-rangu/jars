from xpms_common.cache_handler import CacheHandler
from xpms_common.storage_handler import StorageHandler
from xpms_common.db_handler import DBHandler

def fork_reset():
    CacheHandler.fork_reset()
    StorageHandler.fork_reset()
    DBHandler.fork_reset()

def reset():
    CacheHandler.reset()
    StorageHandler.reset()
    DBHandler.reset()

def thread_reset():
    CacheHandler.thread_reset()
    StorageHandler.thread_reset()
    DBHandler.thread_reset()


