import pika
import json
import os
import traceback
from pika.exceptions import ChannelClosed, ProbableAuthenticationError, AMQPConnectionError
from xpms_common.ls_logger import log_message
from xpms_common.errors import AuthenticationError, InvalidUsageError
from uuid import uuid4
from datetime import datetime
from xpms_common.ls_logger import LogConfig
import inspect
from xpms_common.errors import InvalidUsageError
from xpms_common.utils import get_env

class MQPublisher(object):
    """This is a generic asynchronous XPMS publisher that implements\
     a simple BlockingConnection
    to publish a message to an exchange with a routing_key

        """
    # get default values from environment variables
    EXCHANGE_HOST = os.environ["EX_HOST_QUEUE"]
    EXCHANGE_PORT = int(os.environ["EX_PORT_QUEUE"])
    EXCHANGE_USER = os.environ["EX_USERID_QUEUE"]
    EXCHANGE_PASSWORD = os.environ["EX_PASSWORD_QUEUE"]
    EXCHANGE = os.environ["MESSAGE_EXCHANGE"]
    EXCHANGE_TYPE = 'topic'
    CONNECTION_ATTEMPTS = 3
    HEARTBEAT_INTERVAL = 3600

    def __init__(self, amqp_url=None, service_name=None, class_name=""):
        """Create a new instance of the publisher class, passing in the AMQP
        URL used to connect to RabbitMQ.

        :param str aqmp_url: URL to connect to RabbitMQ. Default connection\
         URL will be constructed from environmental variables.
        :param str routing_key: The routing key to send messages (optional).
        Default is set to broadcast.

        """
        if not isinstance(service_name,str):
            raise InvalidUsageError("service name is a required property and needs to be a string field")
        self.log_config = LogConfig(service_name, class_name)
        try:
            if not amqp_url:
                amqp_url = 'amqp://{0}:{1}@{2}:{3}/%2F?connection_attempts\
                ={4}&heartbeat_interval={5}&socket_timeout={6}' \
                    .format(self.EXCHANGE_USER, self.EXCHANGE_PASSWORD,
                            self.EXCHANGE_HOST, self.EXCHANGE_PORT,
                            self.CONNECTION_ATTEMPTS, self.HEARTBEAT_INTERVAL, "300")
        except Exception as e:
            tb = traceback.format_exc()
            log_message(self.log_config, {"message": str(e), "traceback": tb}, {},
                                  str(inspect.stack()[0][3]))
            raise Exception("Error in formatting amqp_url")

        self._url = amqp_url
        self.routing_key = get_env("DEFAULT_ROUTING_KEY","all.data",False)
        self.service_name = service_name
        self.class_name = class_name
        self._connection = None
        self._channel = None
        self.log_config = LogConfig(self.service_name, self.class_name)

    def connect(self):
        """This method connects to RabbitMQ and opens the channel.
        """
        try:
            parameters = pika.URLParameters(self._url)
            self._connection = pika.BlockingConnection(parameters=parameters)
            # _log(log_level="info", payload={'message':"Connection Established"})
            log_message(self.log_config, {"message": "Connection Established"}, "Connection is on",
                        str(inspect.stack()[0][3]))

        except (ValueError, ProbableAuthenticationError, AMQPConnectionError):
            # _log(log_level="error", payload={"message": "Authentication Error",
            #                                  "amqp_url": self._url})
            log_message(self.log_config, {"message": "Authentication Error", "amqp_url": self._url},
                        "Authentication Error", str(inspect.stack()[0][3]))
            raise AuthenticationError("Failed to authenticate with params: ", payload=parameters)

        self._channel = self._connection.channel()
        self._channel.exchange_declare(exchange=self.EXCHANGE,
                                       type=self.EXCHANGE_TYPE, durable=True)
        # _log(log_level="info", payload={'message':"Channel Created"})
        log_message(self.log_config, {'message': "Channel Created"}, "Channel Created",
                    str(inspect.stack()[0][3]))

    def publish_message(self, payload, message_type="ping", routing_key=None):
        """Publish message to exchange with routing_key

                :param dict payload: The payload
                :param str routing_key: The routing key to send the message.
                This overrides the routing_key set during initialization.

        """
        if not isinstance(payload, dict):
            payload = {"text": str(payload)}
        properties = pika.BasicProperties(content_type='application/json',
                                          delivery_mode=1)
        if not routing_key:
            routing_key = self.routing_key

        header = {
            "msg_id": str(uuid4()),
            "msg_type": message_type,
            "from": self.service_name,
            "to": routing_key,
            "timestamp": datetime.now().isoformat()
        }
        msg = dict()
        msg['header'] = header
        msg['payload'] = payload
        # Turn on delivery confirmations
        self._channel.confirm_delivery()
        try:
            if "trigger" not in msg['payload']:
                raise InvalidUsageError("No trigger found")


            if "request_id" not in msg['payload']:
                raise InvalidUsageError("No request_id found")
            elif msg["payload"]["request_id"] == "":
                raise InvalidUsageError("request_id is empty")

            if "solution_id" not in msg["payload"]:
                raise InvalidUsageError("No solution_id found")
            elif msg["payload"]["solution_id"] == "":
                raise InvalidUsageError("solution id is empty")

            if "data" not in msg["payload"]:
                raise InvalidUsageError("No data found")

            # _log(log_level="info", payload={'message':msg['header']})
            log_message(self.log_config, {'message': msg['header']}, msg["payload"]["data"],
                        str(inspect.stack()[0][3]))

            if self._channel.basic_publish(exchange=self.EXCHANGE,
                                           routing_key=routing_key,
                                           body=json.dumps(msg),
                                           properties=properties,
                                           mandatory=True):

                ret = self.handle_confirm(msg['header']['msg_id'])
            else:
                ret = self.handle_no_confirm(msg['header']['msg_id'])
                # _log(log_level="debug", payload=payload)
                log_message(self.log_config, {'message': msg["payload"]}, msg["payload"]["data"],
                            str(inspect.stack()[0][3]))

        except InvalidUsageError as e:

            # print("---------------------------------9-------------------------------------------------------------")
            tb = traceback.format_exc()
            # print("Error = ", e.message)
            log_message(self.log_config, {"message": e.message, "traceback": tb}, msg,
                        str(inspect.stack()[0][3]))
            ret = self.handle_fail(msg['header']['msg_id'])

        except ChannelClosed:
            ret = self.handle_fail(msg['header']['msg_id'])
        return ret

    def handle_confirm(self, msg_id):
        """Actions to do when message is acked"""
        # _log(log_level="info", payload={"msg_id": msg_id, "status": "Ack"})
        log_message(self.log_config, {"msg_id": msg_id, "status": "Ack"}, "Message acked",
                    str(inspect.stack()[0][3]))
        return {"success": True, "msg_id": msg_id}

    def handle_no_confirm(self, msg_id):
        """Actions to do when message is rejected or nacked"""

        # _log(log_level="info", payload={"msg_id": msg_id,
        #                                 "status": "Nack/Reject"})
        log_message(self.log_config, {"msg_id": msg_id, "status": "Nack/Reject"},
                    "Message is rejected or nacked", str(inspect.stack()[0][3]))
        return {"success": False, "msg_id": msg_id}

    def handle_fail(self, msg_id, fail_message=""):
        """Actions to do when message push has failed"""
        # _log(log_level="debug", payload={"msg_id": msg_id,
        #                                  "status": "Nack/Reject",
        #                                  "text": fail_message})
        log_message(self.log_config, {"msg_id": msg_id, "status": "Nack/Reject", "text": fail_message},
                    "Message push has failed", str(inspect.stack()[0][3]))
        return {"success": False, "msg_id": msg_id}

    def stop(self):
        """Stop publishing and close connection"""
        # _log(log_level="info", payload={"message": "Connection closed"})
        log_message(self.log_config, {"message": "Connection closed"},
                    "Connection closed", str(inspect.stack()[0][3]))
        self._connection.close()
