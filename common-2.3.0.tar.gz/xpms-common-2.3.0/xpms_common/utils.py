import traceback
import os
from xpms_common.errors import XpmsError, InternalError

class Hasher():
    @staticmethod
    def hash_primary_key(json_key, prefix = ""):
        key = prefix
        if isinstance(json_key, str):
            return key + prefix
        if isinstance(json_key, dict):
            keys = list(json_key.keys())
            keys.sort()
            for k in keys:
                if isinstance(json_key[k], str):
                    key = key + json_key[k]
        return key


def source_decode(sourcecode):
    """Decode operator source and import operator class.
    Parameters
    ----------
    sourcecode: string
        a string of operator source (e.g 'sklearn.feature_selection.RFE')
    Returns
    -------
    import_str: string
        a string of operator class source (e.g. 'sklearn.feature_selection')
    op_str: string
        a string of operator class (e.g. 'RFE')
    op_obj: object
        operator class (e.g. RFE)
    """
    tmp_path = sourcecode.split('.')
    op_str = tmp_path.pop()
    import_str = '.'.join(tmp_path)
    try:
        exec('from {} import {}'.format(import_str, op_str))
        op_obj = eval(op_str)
    except ImportError:
        print('Warning: {} is not available and will not be used .'.format(sourcecode))
        op_obj = None

    return import_str, op_str, op_obj

def raise_exception(class_name,method_name,error,payload,log_type="error",get_traceback=False):
    if not isinstance(class_name,str):
        class_name = "unknown"
    if not isinstance(method_name,str):
        method_name = "unknown"

    if not isinstance(error,XpmsError):
        error = InternalError("unknown_error")
    if not isinstance(payload,dict):
        payload = dict()
    if traceback:
        tb = traceback.format_exc()
        error.traceback=tb
    else:
        tb=""
    if "PROJECT_NAME" in os.environ:
        microservice_name = os.environ["PROJECT_NAME"]
    else:
        microservice_name = "unknown, project name not found"

    # ls_logger.log_error(ls_logger.LogConfig(microservice_name,class_name),
    #                     {"error_message": error.message, "traceback": tb}, payload,
    #                     method_name=method_name)
    raise error
    #logs and raises exception with traceback and other messages

def get_env(env_key, default_value, mandatory):
    if env_key in os.environ:
        return os.environ[env_key]
    if mandatory:
        raise KeyError(env_key + ' - Environment variable is missing')
    else:
        return default_value