import redis
import os
import json
from xpms_common.cache_handler_base import CacheHandlerBase
import traceback
from xpms_common import ls_logger
import inspect
from xpms_common.errors import MissingEnvVar,InternalError
from xpms_common.utils import get_env

#Notes
# https://stackoverflow.com/questions/18022767/python-redis-connection-should-be-closed-on-every-request-flask
#https://groups.google.com/forum/#!msg/redis-db/m9k2DN7GX-M/5i5HtXkbeBYJ
#https://github.com/andymccurdy/redis-py/blob/master/CHANGES - connection pool is thread safe apparently
# Behind the scenes, if you don't explicitly pass a connection_pool to a Redis instance, one will be created for you based on the host, db, port, etc. parameters you do pass. Note that in this case the connection pool is only used for that specific client instance, meaning if you're creating Redis instances in various places throughout your code, each will create a separate connection pool. There's two ways to solve that (see next item):
# In general, I suggest you either:
#
# a. create a global redis client instance and have your code use that.
# b. create a global connection pool and pass that to various redis instances throughout your code.
#
# Both of these accomplish the same thing. Both are threadsafe.
#
# Note however that pipeline instances and pubsub instances are *not* threadsafe. Don't create those at a global/module level. Instead, create new pubsub/pipeline instances in each thread.
# For higher throughput connection pooling helps. Pipelines help a lot too. You should install hiredis too. redis-py will automatically use hiredis if it's available.
############ connection limit to redis server is ~ 10000, for changing pool would need to chagne

CACHE_SERVER = None
microservice_name = get_env("PROJECT_NAME","unknown",True)

class RedisHandler(CacheHandlerBase):

    @staticmethod
    def reset():
        RedisHandler.initialize()

    @staticmethod
    def thread_reset():

        # Redis client instances can safely be shared between threads. Internally, connection instances are only retrieved from the connection pool during command execution, and returned to the pool directly after. Command execution never modifies state on the client instance.
        # However, there is one caveat: the Redis SELECT command. The SELECT command allows you to switch the database currently in use by the connection. That database remains selected until another is selected or until the connection is closed. This creates an issue in that connections could be returned to the pool that are connected to a different database.
        # As a result, redis-py does not implement the SELECT command on client instances. If you use multiple Redis databases within the same application, you should create a separate client instance (and possibly a separate connection pool) for each database.
        # It is not safe to pass PubSub or Pipeline objects between threads
        # - https://pypi.python.org/pypi/redis
        return

    @staticmethod
    def fork_reset():
        #https://github.com/andymccurdy/redis-py/blob/master/CHANGES,  - connection pool is thread safe apparently
        return

    @staticmethod
    def initialize():
        global microservice_name
        try:
            global CACHE_SERVER
            host = get_env("REDIS_HOST", "localhost", False)
            port = int(get_env("REDIS_NOAUTH_PORT", "6379", False))
            max_connections = int(get_env("REDIS_MAX_CONNECTIONS", "20", False))

            pool = redis.ConnectionPool(host=host,
                               port=port,max_connections=max_connections)
            CACHE_SERVER = redis.Redis(connection_pool=pool)

        except KeyError as e:
            error_message = "key not found error: " + str(e)
            tb = traceback.format_exc()

            ls_logger.log_error(ls_logger.LogConfig(microservice_name, RedisHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise MissingEnvVar(error_message, traceback=tb)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            microservice_name = get_env("PROJECT_NAME","unknown",True)
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, RedisHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def get_json_value(key):
        value = CACHE_SERVER.get(key)
        if value is not None:
            value = json.loads(value.decode().replace("None", "\"\""))
        return value

    @staticmethod
    def set(key, value, timeout=200, set_timeout=True):
        if set_timeout:
            CACHE_SERVER.set(key, json.dumps(value), timeout)
        else:
            CACHE_SERVER.set(key, json.dumps(value))

    @staticmethod
    def get_raw_value(key):
        return CACHE_SERVER.get(key).decode()[1:-1]

    @staticmethod
    def set_raw_value(key, value, timeout=200, set_timeout=True):
        if set_timeout:
            CACHE_SERVER.set(key, json.dumps(value), timeout)
        else:
            CACHE_SERVER.set(key, json.dumps(value))

    @staticmethod
    def delete_keys(keys):
        CACHE_SERVER.delete(*keys)


if __name__ == "__main__":
    pass
