import os
import logging
from datetime import datetime
from logstash import handler_tcp ,TCPLogstashHandler # pip install python-logstash-0.4.6
import json
from enum import Enum
from xpms_common.configuration import Configuration
from logging.handlers import RotatingFileHandler,TimedRotatingFileHandler
from xpms_common.utils import get_env

#log config updated
class LogConfig():

    def __init__(self,microservice_name,class_name):
        self.microservice_name = microservice_name
        self.class_name = class_name
        #todo get module name automatically of the caller module
        # self.module_name = module_name


#todo discuss on format + logging
# module logging methods
#key can be solution +module_name, rightnow is just module name

log_handlers = dict()

def on_config_update(solution_id, updated_config):
    """
    handles log configuration changes upon configuration update, these are changes in the level of logging we want to do for each solution
    :param solution_id:
    :param updated_config:
    :return:
    """
    global log_handlers
    if solution_id != "default":
        return
    try:
        for module_name in updated_config["defaults"]["log_levels"]:
            if module_name in log_handlers:
                log_handlers[module_name].setLevel(updated_config["defaults"]["log_levels"][module_name])
    except:

        pass


#registering for on configuraiton update event
Configuration.register_update_config_event(on_config_update,"logger_on_config_update")


class LoggerType(Enum):
    """
    Different log types to be handled
    """
    LOGSTASH = "LOGSTASH"
    DEFAULT = "DEFAULT"


#default logger
default_log_level = get_env("LOG_LEVEL", "INFO", False)


def get_logger(name=None,log_level=default_log_level):
    #module name
    if name is None:
        name = "xpms_default_logger"

    #if logger is already present
    if name in log_handlers:
        return log_handlers[name]

    #getting logger type
    logger = LoggerType(get_env("LOGGER", "DEFAULT", False))

    #initializing logger

    ls_logger = logging.getLogger(name)

    #setting log level
    try:
        conf = Configuration.get_instance()["default"]
        if "log_levels" in conf["defaults"]:
            if name in conf["defaults"]["log_levels"]:
                log_level = conf["defaults"]["log_levels"][name]

    except:
        pass

    ls_logger.setLevel(log_level)


    #adding handler
    if logger == LoggerType.LOGSTASH:
        logstash_host =  get_env("LOGSTASH_HOST", "localhost", False)
        logstash_port =  int(get_env("LOGSTASH_PORT", "19000", False))
        ls_logger.addHandler(TCPLogstashHandler(
            logstash_host,
            logstash_port,
            version=1, message_type='json')
        )
    elif logger == LoggerType.DEFAULT:
        logger_path =   get_env("LOGGER_PATH", "\logs", False)
        logger_path = logger_path+name
        fh = RotatingFileHandler(logger_path,maxBytes=10*1024*1024,backupCount=2 )
        fh.setLevel(logging.INFO)
        ls_logger.addHandler(fh)
    log_handlers[name]=ls_logger
    return ls_logger






def log_message(log_config, message_payload,
        data, method_name=None, log_level="info", **kwargs):
    payload = {"service_name": log_config.microservice_name, "payload": message_payload, "data": data,
            "method_name": method_name, "class_name": log_config.class_name
            }

    for k in ["service_name","payload","data","method_name","class_name"]:
        kwargs.pop(k,None)

        payload.update(kwargs)

    ls_logger = get_logger(log_config.class_name)
    payload["time_stamp"] = datetime.utcnow().isoformat()
    if log_level == 'info':
        ls_logger.info(json.dumps(payload))
    elif log_level == 'error':
        ls_logger.error(json.dumps(payload))
    elif log_level == 'debug':
        ls_logger.debug(json.dumps(payload))
    elif log_level == 'critical':
        ls_logger.critical(json.dumps(payload))
    elif log_level == 'warning':
        ls_logger.warning(json.dumps(payload))

    else:
        raise Exception("Unexpected log level")


def _log_(microservice_name,class_name, message_payload,
        data, method_name=None, log_level="info", **kwargs):
    payload = {"service_name": microservice_name, "payload": message_payload, "data": data,
            "method_name": method_name, "class_name": class_name
            }

    for k in ["service_name","payload","data","method_name","class_name"]:
        kwargs.pop(k,None)

        payload.update(kwargs)

    ls_logger = get_logger(class_name)
    payload["time_stamp"] = datetime.utcnow().isoformat()
    if log_level == 'info':
        ls_logger.info(json.dumps(payload))
    elif log_level == 'error':
        ls_logger.error(json.dumps(payload))
    elif log_level == 'debug':
        ls_logger.debug(json.dumps(payload))
    elif log_level == 'critical':
        ls_logger.critical(json.dumps(payload))
    elif log_level == 'warning':
        ls_logger.warning(json.dumps(payload))

    else:
        raise Exception("Unexpected log level")

def log_error(log_config, message_payload, data, method_name=None, **kwargs ):

    log_message(log_config, message_payload,
        data, method_name=method_name,
        log_level="error",**kwargs)


if __name__ == '__main__':
    pass
