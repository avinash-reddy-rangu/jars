import os
import boto3, json
import traceback
import botocore
from botocore.client import Config
from botocore.exceptions import ClientError
from xpms_common import ValidationError

# S3_BUCKET_NAME = os.environ['AMAZON_AWS_BUCKET']

class Storage:

    def __init__(self, key, secret, region):

        self.S3 = boto3.resource(
            's3',
            region_name=region,
            # region_name="us-east-1",
            aws_access_key_id=key,
            # aws_access_key_id=os.environ["AMAZON_AWS_KEY"],
            aws_secret_access_key=secret,
            # aws_secret_access_key=os.environ['AMAZON_AWS_SECRET_KEY'],
            config=Config(signature_version='s3v4')
        )

    def create_bucket(self, bucket_name):
        self.S3.create_bucket(Bucket=bucket_name)

    def upload_to_s3(self,bucket_name, file_name=None, key_name=None):
        if key_name is None or file_name is None:
            raise ValidationError("S3 key_name/filename is missing")

        resp = dict()
        try:
            self.S3.Bucket(bucket_name).upload_file(key_name, file_name)
            resp['status'] = 'success'
            resp['msg'] = 'File uploaded'
        except:
            traceback.print_exc()
            resp['status'] = 'failure'
            resp['msg'] = "Error in File Upload"
        return resp

    def download_from_s3(self, bucket_name, filename=None, key_name=None):
        if key_name is None or filename is None:
            raise ValidationError("S3 key_name/filename is missing")

        resp = dict()
        try:
            self.S3.meta.client.download_file(bucket_name, key_name, filename)
            resp['status'] = 'success'
            resp['msg'] = 'File downloaded'
        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == "404":
                print("The object does not exist.")
            resp['status'] = 'failure'
            resp['msg'] = "Error in downloading file"
        return resp


    @staticmethod
    def get_file_url(bucket_name, file_name):
        file_url = "https://{0}.s3.amazonaws.com/{1}".format(bucket_name, file_name)
        return file_url

if __name__ == '__main__':

    try:
        aws = Storage(os.environ["AMAZON_AWS_KEY"], os.environ['AMAZON_AWS_SECRET_KEY'], "us-east-1")


        # FOR UPLOAD
        # file_name = "README.txt"
        # key_name =  os.getcwd() + "/" + file_name
        # print(key_name)
        # aws.upload_to_s3("xpmstestdata", file_name, key_name)


        # CREATE BUCKET
        # aws.create_bucket("helixanatora123")


        # GET FILE URL
        # print(aws.get_file_url("xpmstestdata", "ola_bangalore.pdf"))


        # FOR DOWNLOAD
        # aws.download_from_s3("xpmstestdata", "ola_bangalore.pdf", "ola_bangalore.pdf")


    except Exception as e:
        print(e)
