import os
import inspect
import traceback

import ftplib

from xpms_common import ls_logger
from xpms_common.errors import MissingEnvVar, InternalError, ValidationError

from xpms_common.base_storage_handler import BaseStorageHandler

FTPClient = None

class FTPHandler(BaseStorageHandler):

    @staticmethod
    def initialize():
        global FTPClient, microservice_name

        try:
            ftp_url = os.environ["FTP_URL"]
            ftp_username = os.environ["FTP_USERNAME"]
            ftp_password = os.environ["FTP_PASSWORD"]

            FTPClient = ftplib.FTP(ftp_url)
            FTPClient.login(ftp_username, ftp_password)

        except KeyError as e:
            error_message = "key not found error: " + str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise MissingEnvVar(error_message, traceback=tb)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def download_file(ftp_filename, local_filename, ftp_working_dir=None):

        if not ftp_filename or not local_filename:
            raise ValidationError("ftp/local filename is missing. ")

        try:
            if ftp_working_dir is not None:
                FTPClient.cwd(ftp_working_dir)
            with open(local_filename, "wb") as local_file:
                FTPClient.retrbinary("RETR " + ftp_filename, local_file.write)
            return True

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def upload_file(ftp_filename, local_filename, ftp_working_dir=None):

        if not ftp_filename or not local_filename:
            raise ValidationError("ftp/local filename is missing. ")

        try:
            if ftp_working_dir is not None:
                FTPClient.cwd(ftp_working_dir)
            local_file = open(local_filename, 'rb')
            FTPClient.storbinary("STOR " + ftp_filename, local_file)
            local_file.close()
            return True

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def upload_file(ftp_filename, object_upload, ftp_working_dir=None):

        if not ftp_filename or not object_upload:
            raise ValidationError("ftp/local filename is missing. ")

        try:
            if ftp_working_dir is not None:
                FTPClient.cwd(ftp_working_dir)
            FTPClient.storbinary("STOR " + ftp_filename, object_upload)
            return True

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def delete_file(ftp_filename, ftp_working_dir=None):

        try:
            if ftp_working_dir is not None:
                FTPClient.cwd(ftp_working_dir)
            FTPClient.delete(ftp_filename)
            return True

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def create_dir(dir_name, ftp_working_dir=None):

        if not dir_name:
            raise ValidationError("Directory name is missing. ")

        try:
            if ftp_working_dir is not None:
                FTPClient.cwd(ftp_working_dir)

            FTPClient.mkd(dir_name)
            return True

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def get_working_dir():

        try:
            dir_name = FTPClient.pwd()
            return dir_name

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, FTPHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)