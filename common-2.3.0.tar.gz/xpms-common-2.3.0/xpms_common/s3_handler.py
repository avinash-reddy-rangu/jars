import inspect
import os
import traceback
import botocore
import boto3
from botocore.exceptions import ClientError

#session isnt isnt thread safe, need to create new session with every thread
from xpms_common import ls_logger
from xpms_common.errors import MissingEnvVar, InternalError, ValidationError
from xpms_common.base_storage_handler import BaseStorageHandler
from xpms_common.utils import get_env

#no min connections in pool, http://botocore.readthedocs.io/en/latest/reference/config.html
#no max connections limit on server : https://stackoverflow.com/questions/37432285/maximum-no-of-connections-that-can-be-held-by-s3

S3 = None
microservice_name = get_env("PROJECT_NAME","unknown",True)

class S3Handler(BaseStorageHandler):

    @staticmethod
    def fork_reset():
        S3Handler.initialize()

    @staticmethod
    def thread_reset():
        S3Handler.initialize()

    @staticmethod
    def initialize():
        #initialize S3 client, maximum connections by default are 10, need to update to mode
        global S3, microservice_name
        # todo, to be replaced by xpms commons code
        try:
            max_pool_connections = int(get_env("S3_MAX_POOL", "30", False))
            try:
                amazon_aws_region = get_env("AMAZON_AWS_REGION", "unknown", True)
                amazon_aws_key = get_env("AMAZON_AWS_KEY", "unknown", True)
                amazon_aws_secret_key = get_env("AMAZON_AWS_SECRET_KEY", "unknown", True)


                S3 = boto3.client(
                    's3',
                    aws_access_key_id=amazon_aws_key,
                    aws_secret_access_key=amazon_aws_secret_key,config=botocore.client.Config(max_pool_connections=max_pool_connections)
                )
            except:
                S3 = boto3.client(
                    's3',
                    config=botocore.client.Config(max_pool_connections=max_pool_connections)
                )

        except KeyError as e:
            error_message = "key not found error: " + str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise MissingEnvVar(error_message, traceback=tb)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def create_bucket(bucket_name):
        global microservice_name
        try:
            S3.create_bucket(Bucket=bucket_name)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def delete_bucket(bucket_name):
        global microservice_name
        try:
            S3.delete_bucket(Bucket=bucket_name)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def download_object(bucket_name, key):
        global microservice_name
        try:
            object = S3.get_object(Bucket=bucket_name, Key=key)
            return object["Body"].read()

        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                return 'null'
            else:
                raise e

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def upload_object(bucket_name, key, object):
        global microservice_name
        try:
            S3.put_object(Bucket=bucket_name, Key=key, Body=object)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def get_files_as_objects(bucket_name, key_prefix=False):
        global microservice_name
        try:
            # suseptable to crash
            if key_prefix:
                obj_list = S3.list_objects(Bucket=bucket_name, Prefix=key_prefix)
            else:
                obj_list = S3.list_objects(Bucket=bucket_name)
            keys = [key["Key"] for key in obj_list["Contents"]]
            print()
            objects = dict()
            for key in keys:
                object = S3.get_object(Bucket=bucket_name, Key=key)
                objects[key] = object["Body"].read()
            return objects

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def upload_file(file_to_upload, bucket_name, key):
        global microservice_name
        if key is None or file_to_upload is None:
            raise ValidationError("S3 key_name/filename is missing")

        resp = dict()
        try:
            with open(file_to_upload, 'rb') as data:
                S3.upload_fileobj(data, bucket_name, key)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def download_file(upload_file_path ,bucket_name, key):
        global microservice_name
        if key is None or upload_file_path is None:
            raise ValidationError("S3 key_name/filename is missing")
        try:
            with open(upload_file_path, 'wb') as data:
                S3.download_fileobj(bucket_name, key, data)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def get_file_url(bucket_name, key):
        global microservice_name
        try:
            file_url = "https://{0}.s3.amazonaws.com/{1}".format(bucket_name, key)
            return file_url

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

            # return object["Body"].read()
            # conf = Configuration.get_instance()
            # conf = conf["test"]
            # #S3Reader.read_files(conf["defaults"]["s3_bucket_learning_dataset"])
            # objects = S3Reader.read_files(conf["defaults"]["s3_bucket_learning_dataset"],"f06b11e3-0600-4ce8-9b67-978b849db2c7")
            # print()

    @staticmethod
    def delete(bucket_name, key):
        global microservice_name
        try:
            S3.delete_object(Bucket=bucket_name, Key=key)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, S3Handler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)
