import os
import inspect
import traceback

import boto3

from xpms_common import ls_logger
from xpms_common.errors import MissingEnvVar, InternalError
from xpms_common.errors import MissingEnvVar, InternalError, ValidationError

from xpms_common.base_storage_handler import BaseStorageHandler

if "PROJECT_NAME" in os.environ:
    microservice_name = os.environ["PROJECT_NAME"]
else:
    microservice_name = "unknown, project name not found, xpmscommons"

storage_path = None

class EFSHandler(BaseStorageHandler):
    storage_path= None
    @staticmethod
    def initialize():
        global microservice_name, storage_path

        try:
            storage_path = os.environ["SHARED_VOLUME"]
            EFSHandler.storage_path = storage_path
        except KeyError as e:
            error_message = "key not found error: " + str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, EFSHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise MissingEnvVar(error_message, traceback=tb)

        except Exception as e:
            error_message = str(e)
            tb = traceback.format_exc()
            ls_logger.log_error(ls_logger.LogConfig(microservice_name, EFSHandler.__name__),
                                {"error_message": error_message, "traceback": tb}, {},
                                method_name=str(inspect.stack()[0][3]))
            raise InternalError(error_message, traceback=tb)

    @staticmethod
    def upload_object(server_file_path, server_file_name, upload_object):
        if not server_file_name or not server_file_path or not object:
            raise ValidationError("Filename/Filepath/Object is missing. ")

        with open(storage_path + server_file_path + server_file_name, "wb") as upload_file:
            upload_file.write(upload_object)

    @staticmethod
    def upload_file(local_file_path, server_file_path, server_file_name):
        if not server_file_name or not server_file_path or not object:
            raise ValidationError("Filename/Filepath/Object is missing. ")

        with open(local_file_path, "rb") as local_upload_file:
            with open(storage_path + server_file_path + server_file_name, "wb") as server_upload_file:
                server_upload_file.write(local_upload_file.read())
            local_upload_file.close()

    @staticmethod
    def download_object(server_file_path, server_file_name):
        if not server_file_name or not server_file_path or not object:
            raise ValidationError("Filename/Filepath/Object is missing. ")

        server_upload_obj = None
        with open(storage_path + server_file_path + server_file_name, "rb") as server_upload_file:
            server_upload_obj = server_upload_file.read()
        return server_upload_obj

    @staticmethod
    def download_file(download_file_path, server_file_path, server_file_name):
        if not server_file_name or not server_file_path or not object:
            raise ValidationError("Filename/Filepath/Object is missing. ")

        with open(download_file_path, "wb") as local_download_file:
            with open(storage_path + server_file_path + server_file_name, "rb") as server_upload_file:
                local_download_file.write(server_upload_file.read())
            local_download_file.close()
