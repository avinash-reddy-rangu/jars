import os
import traceback
# from xpms_common import ls_logger
from xpms_common.utils import get_env
from xpms_common.errors import  MissingEnvVar, InvalidUsageError


# todo need to discuss if we have multiple databases,
# todo what restrictions we need to set in usage....

DataBases = dict()
Clients = dict()
microservice_name  = get_env("PROJECT_NAME", "unkown", True)
database  = get_env("DATABASE", "unknown", False)
DBHandler = None

if database == "MONGODB":
    from xpms_common.mongo_dbconn import MongoDbConn as DBHandler

    DBHandler.initialize()
elif database == "CASSANDRA":
    from xpms_common.cassandra_dbconn import Cassandra as DBHandler

def get_instance(database_name, refresh = False):
    if database_name in DataBases and not refresh :
        return DataBases[database_name]
    if database_name == "MONGODB":
        from xpms_common.mongo_dbconn import MongoDbConn
        MongoDbConn.initialize()
        DataBases[database_name] = MongoDbConn
        return DataBases[database_name]
    elif database_name == "CASSANDRA":
        from xpms_common.cassandra_dbconn import Cassandra
        DataBases[database_name] = Cassandra
        return DataBases[database_name]
    else:
        error_message = "Invalid storage name in env vars"
        tb = traceback.format_exc()
        raise InvalidUsageError(error_message, traceback=tb)


def get_client(database_name, refresh=False):

    if database_name in Clients and not refresh:
        return DataBases[database_name]

    if database_name == "MONGODB":
        from xpms_common.mongo_dbconn import MongoDbConn
        MongoDbConn.initialize()
        from xpms_common.mongo_dbconn import MONGO_CLIENT
        Clients[database_name] = MONGO_CLIENT
        return MONGO_CLIENT

    elif database_name == "CASSANDRA":
        from xpms_common.cassandra_dbconn import Cassandra
        Clients[database_name] = Cassandra().session
        return Clients[database_name]

    else:
        error_message = "Invalid storage name in env vars"
        tb = traceback.format_exc()
        raise InvalidUsageError(error_message, traceback=tb)


if __name__ == "__main__":
    pass