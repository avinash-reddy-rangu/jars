from jsonschema import validate
from jsonschema import ValidationError, SchemaError
from xpms_common.errors import InvalidUsageError, InternalError

# TODO: Define custom validator function for timestamp format
TIMESTAMP_ISO8601_PATTERN = ""

UUID4_PATTERN = "^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}\Z"

REGISTERED_TRIGGERS = [
    "ping",
    "ack",
    "process_entity",
    "upsert_entity_data",
    "tick",
    "query_result",
    "upsert_entity_metadata",
    "delete_entity",
    "operation_failure",
    "user_request",
    "matching_query",
    "raw_insight",
    "active_users",
    "tick_context",
    "generated_insight",
    "user_request",
    "run_scenario",
    "test_scenario",
    "update_scenario"
]

MESSAGE_SCHEMA = {
    "$schema": "http://json-schema.org/schema#",
    "type": "object",
    "properties": {
        "header": {
            "type": "object"
        },
        "payload": {
            "type": "object"
        }
    },
    "required": ["header", "payload"]
}

HEADER_SCHEMA = {
    "$schema": "http://json-schema.org/schema#",
    "type": "object",
    "properties": {
            "msg_id": {
                "type": "string",
                "pattern": UUID4_PATTERN
                },
            "msg_type": {
                "enum": ["ping", "signal", "broadcast","api"]
            },
            "from": {"type": "string"},
            "to": {"type": "string"},
            "timestamp": {"type": "string"}
    },
    "required": [ "msg_id", "msg_type", "from", "to", "timestamp" ]
}

def is_valid_json(_json, schema):
    try:
        validate(_json, schema)
    except ValidationError as e:
        fail_message = str(e).split("\n")[0]
        # TODO log info
        raise InvalidUsageError(fail_message)
    except SchemaError as e:
        # TODO log error
        raise InternalError("Warning: Schema error. Cannot validate.")
    return True